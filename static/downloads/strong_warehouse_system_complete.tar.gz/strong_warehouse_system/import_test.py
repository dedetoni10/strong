#!/usr/bin/env python3
"""
Test script to import Excel data for testing
"""
import pandas as pd
import sys
import os
from app import app, db

# Read the Excel file
file_path = 'attached_assets/Daftar Pesanan.SPX Standard_51_1751951477534.xlsx'

def test_import():
    with app.app_context():
        from routes import process_order_data
        
        print("Reading Excel file...")
        df = pd.read_excel(file_path, engine='openpyxl')
        
        print(f'Read Excel file with {df.shape[0]} rows and {df.shape[1]} columns')
        print('Columns:', list(df.columns))
        
        # Convert to dict format that process_order_data expects
        data = df.to_dict('records')
        print(f'Converting to {len(data)} records')
        
        # Sample first record to see product_info format
        print('\nSample product_info content:')
        sample_product_info = data[0]['product_info']
        print(sample_product_info[:300] + '...')
        print('\nFull product_info for first record:')
        print(repr(sample_product_info))
        
        # Process the data
        try:
            imported_count = process_order_data(data)
            print(f'\nSuccessfully imported {imported_count} orders')
        except Exception as e:
            print(f'Error during import: {e}')
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    test_import()