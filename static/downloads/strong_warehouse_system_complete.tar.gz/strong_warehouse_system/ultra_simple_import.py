"""
Ultra Simple Import - No More Internal Server Errors
Simple, robust Excel import without complex database operations
"""

import pandas as pd
import logging
import re
from database_models import db, Order, OrderItem

def safe_text(text):
    """Safely convert text to string"""
    if text is None or pd.isna(text):
        return ""
    return str(text).strip()

def ultra_simple_import(file_path):
    """Ultra simple import - no fancy operations, just basic insert"""
    
    results = {
        'success': False,
        'imported_count': 0,
        'errors': [],
        'message': ''
    }
    
    try:
        # Read Excel file
        df = pd.read_excel(file_path)
        df = df.fillna("")
        
        logging.info(f"File loaded successfully: {len(df)} rows")
        
        # Simple counter
        imported = 0
        
        # Process each row very simply
        for index, row in df.iterrows():
            try:
                # Get basic info
                order_number = safe_text(row.get('order_sn', ''))
                if not order_number:
                    continue
                    
                # Skip if already exists (simple check)
                existing = db.session.execute(
                    db.text("SELECT id FROM orders WHERE order_number = :order_num"), 
                    {'order_num': order_number}
                ).first()
                
                if existing:
                    continue
                
                # Get customer name
                customer_name = safe_text(row.get('order_receiver_name', '')) or safe_text(row.get('buyer_user_name', '')) or 'Unknown'
                
                # Get tracking number
                tracking_number = safe_text(row.get('tracking_number', ''))
                if not tracking_number:
                    tracking_number = None
                
                # Simple insert using raw SQL (most reliable)
                db.session.execute(
                    db.text("""
                        INSERT INTO orders (order_number, tracking_number, customer_name, total_amount, status, created_at, updated_at)
                        VALUES (:order_number, :tracking_number, :customer_name, 0.0, 'pending', NOW(), NOW())
                    """),
                    {
                        'order_number': order_number,
                        'tracking_number': tracking_number,
                        'customer_name': customer_name
                    }
                )
                
                # Get the inserted order ID
                order_id = db.session.execute(
                    db.text("SELECT id FROM orders WHERE order_number = :order_num"),
                    {'order_num': order_number}
                ).scalar()
                
                # Process product info if exists
                product_info = safe_text(row.get('product_info', ''))
                if product_info and order_id:
                    # Simple product parsing
                    lines = product_info.split('\n')
                    item_count = 0
                    
                    for line in lines:
                        if 'Nama Produk:' in line:
                            # Extract product name
                            name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                            if name_match:
                                product_name = name_match.group(1).strip()
                                # Remove [BAYAR DI TEMPAT] prefix if exists
                                product_name = re.sub(r'^\[BAYAR DI TEMPAT\]\s*', '', product_name)
                                
                                # Extract quantity
                                qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                                quantity = int(qty_match.group(1)) if qty_match else 1
                                
                                # Extract price
                                price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                                price = 0.0
                                if price_match:
                                    try:
                                        price = float(price_match.group(1).replace(',', '').replace('.', ''))
                                    except:
                                        price = 0.0
                                
                                # Insert order item with all required fields
                                item_count += 1
                                db.session.execute(
                                    db.text("""
                                        INSERT INTO order_items (order_id, sku, product_name, quantity, price, picked_quantity, is_picked, created_at, updated_at)
                                        VALUES (:order_id, :sku, :product_name, :quantity, :price, 0, false, NOW(), NOW())
                                    """),
                                    {
                                        'order_id': order_id,
                                        'sku': f'SKU-{order_number}-{item_count}',
                                        'product_name': product_name,
                                        'quantity': quantity,
                                        'price': price
                                    }
                                )
                
                # Commit each order individually
                db.session.commit()
                imported += 1
                
                # Progress logging
                if imported % 5 == 0:
                    logging.info(f"Processed {imported} orders...")
                    
                # Break early if taking too long (prevent timeout)
                if imported >= 50:
                    logging.info("Reached batch limit of 50 orders, stopping to prevent timeout")
                    break
                    
            except Exception as e:
                # Rollback and continue with next order
                db.session.rollback()
                logging.error(f"Error processing order {order_number}: {str(e)}")
                results['errors'].append(f"Order {order_number}: {str(e)}")
                continue
        
        # Final result
        results['success'] = True
        results['imported_count'] = imported
        results['message'] = f"Successfully imported {imported} orders"
        
        return results
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Import failed: {str(e)}")
        results['errors'].append(str(e))
        results['message'] = f"Import failed: {str(e)}"
        return results