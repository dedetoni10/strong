#!/usr/bin/env python3
"""
Simple Shopee API test to debug signature generation
"""

import hmac
import hashlib
import time
import requests
import json

def test_shopee_api_simple():
    """Test basic Shopee API connection with manual signature generation"""
    
    # Your credentials
    partner_id = 1890343
    api_key = "5d2759796855750424d9f653d6d247f84d50569d7d4ba41462037961746647"
    shop_id = 1420428877
    
    # Generate timestamp
    timestamp = int(time.time())
    
    # Test 1: Simple auth_partner endpoint (no access token needed)
    path = "/api/v2/shop/auth_partner"
    base_string = f"{partner_id}{path}{timestamp}"
    
    signature = hmac.new(
        api_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    print(f"=== DEBUG INFO ===")
    print(f"Partner ID: {partner_id} (type: {type(partner_id)})")
    print(f"Path: {path}")
    print(f"Timestamp: {timestamp}")
    print(f"Base string: {base_string}")
    print(f"Signature: {signature}")
    print(f"=================")
    
    # Build URL
    url = f"https://partner.shopeemobile.com{path}"
    params = {
        'partner_id': partner_id,
        'timestamp': timestamp,
        'sign': signature,
        'redirect': 'https://strongdksai.site/shopee-callback'
    }
    
    print(f"URL: {url}")
    print(f"Params: {json.dumps(params, indent=2)}")
    
    try:
        response = requests.get(url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"JSON Response: {json.dumps(data, indent=2)}")
                return data
            except:
                print("Response is not JSON")
                return {"error": "not_json", "response": response.text}
        else:
            return {"error": f"http_{response.status_code}", "response": response.text}
            
    except Exception as e:
        print(f"Exception: {str(e)}")
        return {"error": "exception", "message": str(e)}

if __name__ == "__main__":
    result = test_shopee_api_simple()
    print(f"\nFinal Result: {json.dumps(result, indent=2)}")