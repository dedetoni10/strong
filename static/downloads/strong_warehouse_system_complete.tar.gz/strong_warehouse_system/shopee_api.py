import os
import requests
import logging
import time
import hmac
import hashlib
from typing import List, Dict, Optional

class ShopeeAPI:
    def __init__(self):
        # Use live credentials from approved Shopee app
        # Updated from latest screenshot - Jan 2025
        self.partner_id = int(os.environ.get("SHOPEE_PARTNER_ID", "2011911"))  # Live Partner ID 
        self.api_key = os.environ.get("SHOPEE_API_KEY", "shpk634a47494b726d41537068786c456c6c76637673416e6872517959705050")  # Live API Key
        self.shop_id = int(os.environ.get("SHOPEE_SHOP_ID", "1420428877"))  # Shop ID from user
        self.base_url = "https://partner.shopeemobile.com"
        self.access_token = os.environ.get("SHOPEE_ACCESS_TOKEN", "")
        
        # API endpoints based on Shopee API Test Tool
        self.endpoints = {
            'get_order_list': '/api/v2/order/get_order_list',
            'get_order_detail': '/api/v2/order/get_order_detail', 
            'get_shop_info': '/api/v2/shop/get_shop_info',
            'auth_partner': '/api/v2/shop/auth_partner',
            'cancel_order': '/api/v2/order/cancel_order',
            'get_order_list_note': '/api/v2/order/get_order_list_note',
            'handle_buyer_cancellation': '/api/v2/order/handle_buyer_cancellation',
            'split_order': '/api/v2/order/split_order'
        }
    
    def _generate_signature(self, url_path: str, timestamp: int, access_token: str = "", shop_id: int = 0) -> str:
        """Generate signature for Shopee API authentication"""
        # For auth_partner endpoint, don't include access_token and shop_id
        if 'auth_partner' in url_path:
            base_string = f"{self.partner_id}{url_path}{timestamp}"
        # For token/get endpoint, also don't include access_token and shop_id
        elif 'token/get' in url_path:
            base_string = f"{self.partner_id}{url_path}{timestamp}"
        else:
            base_string = f"{self.partner_id}{url_path}{timestamp}{access_token}{shop_id}"
        
        signature = hmac.new(
            self.api_key.encode('utf-8'),
            base_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def get_auth_url(self, redirect_url: str = "https://strongofficial.site/shopee-callback") -> str:
        """Generate authorization URL for getting access token"""
        if not self.api_key:
            logging.error("API Key tidak ditemukan dalam environment variables")
            return ""
            
        timestamp = int(time.time())
        path = self.endpoints['auth_partner']
        
        # Debug signature generation
        base_string = f"{self.partner_id}{path}{timestamp}"
        logging.info(f"Generating signature - Partner ID: {self.partner_id}, Path: {path}, Timestamp: {timestamp}")
        logging.info(f"Base string: {base_string}")
        logging.info(f"API Key length: {len(self.api_key)}")
        
        sign = self._generate_signature(path, timestamp)
        
        # Try different URL formats - some regions use different parameters
        import urllib.parse
        encoded_redirect = urllib.parse.quote(redirect_url)
        
        auth_url = (f"{self.base_url}{path}?"
                   f"partner_id={self.partner_id}&"
                   f"timestamp={timestamp}&"
                   f"sign={sign}&"
                   f"redirect={encoded_redirect}")
        
        logging.info(f"Generated auth URL: {auth_url}")
        return auth_url
    
    def get_access_token_from_code(self, code: str, shop_id: str) -> Dict:
        """Get access token using authorization code"""
        try:
            timestamp = int(time.time())
            path = "/api/v2/auth/token/get"
            signature = self._generate_signature(path, timestamp)
            
            url = f"{self.base_url}{path}"
            
            # Query parameters for authentication
            query_params = {
                "partner_id": self.partner_id,
                "timestamp": timestamp,
                "sign": signature
            }
            
            # Request body with authorization data
            body = {
                "code": code,
                "shop_id": int(shop_id),
                "partner_id": self.partner_id
            }
            
            logging.info(f"🔄 Token request - URL: {url}")
            logging.info(f"🔄 Query params: {query_params}")
            logging.info(f"🔄 Body: {body}")
            
            response = requests.post(url, params=query_params, json=body, timeout=10)
            logging.info(f"🔄 Response status: {response.status_code}")
            logging.info(f"🔄 Response headers: {dict(response.headers)}")
            logging.info(f"🔄 Response text: {response.text}")
            
            # Don't raise for status, handle manually
            if response.status_code != 200:
                error_data = response.json() if response.content else {}
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {error_data.get('message', error_data.get('error', 'Unknown error'))}"
                }
            
            try:
                data = response.json()
                if data.get("error") == "" or data.get("error") is None:
                    return {
                        "success": True,
                        "access_token": data.get("access_token"),
                        "refresh_token": data.get("refresh_token"),
                        "expires_in": data.get("expires_in")
                    }
                else:
                    return {
                        "success": False,
                        "error": data.get("message", data.get("error", "Unknown error"))
                    }
            except:
                return {
                    "success": False,
                    "error": f"Invalid JSON response: {response.text}"
                }
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Request failed: {str(e)}")
            return {
                "success": False,
                "error": f"Request failed: {str(e)}"
            }
        except Exception as e:
            logging.error(f"Unexpected error: {str(e)}")
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}"
            }
    
    def test_connection(self) -> Dict:
        """Test API connection and get shop info"""
        if not self.access_token or not self.shop_id:
            return {
                'success': False,
                'message': 'Access token atau Shop ID belum diset. Perlu authorization dulu.',
                'auth_url': self.get_auth_url()
            }
        
        try:
            timestamp = int(time.time())
            path = self.endpoints['get_shop_info']
            sign = self._generate_signature(path, timestamp, self.access_token, self.shop_id)
            
            params = {
                'partner_id': self.partner_id,
                'timestamp': timestamp,
                'access_token': self.access_token,
                'shop_id': self.shop_id,
                'sign': sign
            }
            
            response = requests.get(f"{self.base_url}{path}", params=params)
            data = response.json()
            
            if data.get('error') == '':
                return {
                    'success': True,
                    'message': 'Koneksi berhasil!',
                    'shop_info': data.get('response', {})
                }
            else:
                return {
                    'success': False,
                    'message': f"API Error: {data.get('message', 'Unknown error')}",
                    'error_code': data.get('error')
                }
                
        except Exception as e:
            return {
                'success': False,
                'message': f"Connection error: {str(e)}"
            }
        
    def get_orders(self, time_range_field: str = "create_time", 
                   time_from: int = None, time_to: int = None) -> List[Dict]:
        """
        Fetch orders from Shopee API using v2.order.get_order_list
        
        Args:
            time_range_field: Field to filter by time (create_time, update_time)
            time_from: Start timestamp
            time_to: End timestamp
            
        Returns:
            List of order dictionaries
        """
        if not self.access_token or not self.shop_id:
            logging.warning("Shopee API credentials not complete")
            return []
        
        try:
            url = f"{self.base_url}/order/get_order_list"
            params = {
                "partner_id": self.shop_id,
                "timestamp": int(time.time()),
                "access_token": self.access_token,
                "shop_id": self.shop_id,
                "time_range_field": time_range_field,
                "time_from": time_from or int(time.time()) - 86400 * 30,  # 30 days ago
                "time_to": time_to or int(time.time()),
                "page_size": 100
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            if data.get("error") == "":
                return data.get("response", {}).get("order_list", [])
            else:
                logging.error(f"Shopee API error: {data.get('message', 'Unknown error')}")
                return []
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to fetch orders from Shopee API: {str(e)}")
            return []
        except Exception as e:
            logging.error(f"Unexpected error in Shopee API: {str(e)}")
            return []
    
    def get_order_details(self, order_sn_list: List[str]) -> List[Dict]:
        """
        Get detailed information for specific orders
        
        Args:
            order_sn_list: List of order serial numbers
            
        Returns:
            List of detailed order dictionaries
        """
        if not self.api_key or not self.shop_id:
            logging.warning("Shopee API credentials not found in environment variables")
            return []
        
        try:
            url = f"{self.base_url}/order/get_order_detail"
            params = {
                "partner_id": self.shop_id,
                "timestamp": int(time.time()),
                "access_token": self.access_token,
                "shop_id": self.shop_id,
                "order_sn_list": ",".join(order_sn_list)
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            if data.get("error") == "":
                return data.get("response", {}).get("order_list", [])
            else:
                logging.error(f"Shopee API error: {data.get('message', 'Unknown error')}")
                return []
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to fetch order details from Shopee API: {str(e)}")
            return []
        except Exception as e:
            logging.error(f"Unexpected error in Shopee API: {str(e)}")
            return []
    
    def sync_orders_to_local(self) -> int:
        """
        Sync Shopee orders to local storage
        
        Returns:
            Number of orders synced
        """
        from models import create_order, shopee_orders
        
        orders_data = self.get_orders()
        synced_count = 0
        
        for order in orders_data:
            try:
                order_sn = order.get("order_sn", "")
                if order_sn not in shopee_orders:
                    # Get detailed order information
                    order_details = self.get_order_details([order_sn])
                    if order_details:
                        detail = order_details[0]
                        
                        # Extract order information
                        customer_name = detail.get("recipient_address", {}).get("name", "")
                        customer_phone = detail.get("recipient_address", {}).get("phone", "")
                        customer_address = self._format_address(detail.get("recipient_address", {}))
                        
                        items = []
                        total_amount = 0
                        
                        for item in detail.get("item_list", []):
                            item_data = {
                                "product_id": item.get("item_id", ""),
                                "name": item.get("item_name", ""),
                                "quantity": item.get("model_quantity_purchased", 0),
                                "price": float(item.get("model_discounted_price", 0))
                            }
                            items.append(item_data)
                            total_amount += item_data["price"] * item_data["quantity"]
                        
                        # Create local order
                        order_id = create_order(
                            order_sn, customer_name, customer_phone, 
                            customer_address, items, total_amount
                        )
                        
                        # Store reference to prevent duplicates
                        shopee_orders[order_sn] = order_id
                        synced_count += 1
                        
            except Exception as e:
                logging.error(f"Failed to sync order {order.get('order_sn', 'unknown')}: {str(e)}")
                continue
        
        return synced_count
    
    def _format_address(self, address_data: Dict) -> str:
        """Format address from Shopee API response"""
        parts = [
            address_data.get("full_address", ""),
            address_data.get("city", ""),
            address_data.get("state", ""),
            address_data.get("zipcode", "")
        ]
        return ", ".join(filter(None, parts))

# Global instance
shopee_api = ShopeeAPI()
