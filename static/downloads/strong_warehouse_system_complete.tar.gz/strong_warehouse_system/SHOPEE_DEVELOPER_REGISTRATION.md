# Shopee Developer Registration - Strong Order Management

## Informasi Lengkap untuk Form Registrasi

### 1. Basic Information
- **Company Name**: Strong Order Management
- **Website**: https://strongdksai.site
- **Application Name**: Strong Order Management System
- **Application Type**: Third-party Partner Platform

### 2. Technical Information
- **Programming Language**: Python
- **Framework**: Flask
- **Database**: PostgreSQL
- **Hosting**: Replit Cloud Platform

### 3. IP Address Whitelist
**Primary IP**: `35.197.78.132`
**Backup/Development**: `0.0.0.0/0`

**Format untuk form:**
```
35.197.78.132
0.0.0.0/0
```

### 4. Redirect URLs
- **Primary**: `https://strongdksai.site/shopee-callback`
- **Development**: `https://strongdksai.site/shopee-auth`

### 5. API Endpoints Yang Akan Digunakan
- Order Management API
- Product Management API
- Shop Information API
- Logistics API

### 6. Business Use Case
Strong Order Management adalah sistem terintegrasi untuk:
- Manajemen pesanan otomatis dari Shopee
- Kontrol inventory real-time
- Workflow picking dan packing
- Tracking dan fulfillment otomatis

### 7. Security & Compliance
- HTTPS encryption pada semua endpoint
- Secure session management
- Database security dengan PostgreSQL
- API key management yang aman

### 8. Contact Information
- **Technical Contact**: Admin Strong
- **Email**: admin@strongdksai.site
- **Phone**: +62-xxx-xxxx-xxxx

### 9. Expected Usage
- **Daily API Calls**: 1,000-5,000 calls
- **Peak Usage**: During business hours (9 AM - 6 PM WIB)
- **Primary Functions**: Order sync, inventory update, status tracking

### 10. Server Information
- **Server Location**: Google Cloud Platform (Oregon, US)
- **IP Address**: 35.197.78.132
- **Hostname**: strongdksai.site
- **SSL Certificate**: Valid HTTPS

## Langkah Registrasi

1. **Kunjungi**: https://open.shopee.com/
2. **Pilih**: "Apply to become a partner"
3. **Isi form** dengan informasi di atas
4. **Upload dokumen** bisnis yang diperlukan
5. **Tunggu approval** (biasanya 1-2 minggu)
6. **Dapatkan Partner ID dan API Key**

## Setelah Approval

1. Update environment variables:
   ```
   SHOPEE_API_KEY=your_api_key_here
   SHOPEE_PARTNER_ID=your_partner_id_here
   ```

2. Test koneksi melalui halaman /shopee-setup

3. Mulai sinkronisasi order otomatis

## Troubleshooting

- **IP Address berubah**: Update whitelist di developer console
- **SSL Certificate**: Pastikan HTTPS aktif
- **API Limits**: Monitor usage di developer dashboard