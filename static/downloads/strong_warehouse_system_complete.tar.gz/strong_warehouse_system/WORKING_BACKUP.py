"""
WORKING BACKUP - Import Route yang Sudah Bekerja
Tanggal: 9 Juli 2025
Status: Production Ready

Jika ada masalah, copy paste kode ini ke routes.py
"""

@app.route('/orders/import', methods=['GET', 'POST'])
def import_orders():
    """Import with progress interface - simplified version"""
    if request.method == 'POST':
        uploaded_files = request.files.getlist('order_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'Tidak ada file yang dipilih'})
        
        file = uploaded_files[0]
        
        if file.filename == '' or not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'success': False, 'message': 'Format file tidak valid'})
        
        try:
            import tempfile
            import os
            
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, file.filename)
            file.save(temp_file_path)
            
            from bulk_import_final import bulk_import_single_file
            result = bulk_import_single_file(temp_file_path)
            
            os.remove(temp_file_path)
            
            if result.get('success'):
                return jsonify({
                    'success': True,
                    'imported_count': result['imported_count'],
                    'skipped_count': result.get('skipped_count', 0),
                    'message': f'Import berhasil: {result["imported_count"]} pesanan'
                })
            else:
                return jsonify({
                    'success': False,
                    'imported_count': 0,
                    'message': 'Import gagal'
                })
                
        except Exception as e:
            return jsonify({
                'success': False,
                'imported_count': 0,
                'message': f'Error: {str(e)}'
            })
    
    return render_template('import_orders_progress.html')

# WORKING JAVASCRIPT SNIPPET untuk templates/import_orders_progress.html
# Line 178-190:
"""
const response = await fetch('/orders/import', {
    method: 'POST',
    body: formData
});

const responseText = await response.text();
let result;

try {
    result = JSON.parse(responseText);
} catch (parseError) {
    throw new Error(`Invalid JSON response: ${responseText}`);
}
"""