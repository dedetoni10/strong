# Panduan Lengkap Setup Shopee API untuk Strong Order Management

## Error "invalid_partner_id" - Solusi

Error ini terjadi karena:
1. Partner ID tidak valid untuk environment yang digunakan
2. Signature generation tidak sesuai dengan requirement Shopee API
3. Credentials belum sepenuhnya dikonfigurasi

## Solusi Langkah Demi Langkah

### 1. Verifikasi Partner ID dan API Key
- Partner ID: 1890343 (dari screenshot)
- API Key: 5d2759796855750424d9f653d6d247f84d50569d7d4ba41462037961746647

### 2. Mendapatkan Shop ID
1. Login ke [Shopee Seller Center](https://seller.shopee.co.id)
2. Lihat URL di browser: `seller.shopee.co.id/portal/shop/XXXXXXXXX`
3. Copy angka `XXXXXXXXX` sebagai Shop ID

### 3. Mendapatkan Access Token
**Metode 1: Manual Setup (Rekomendasi)**
1. Buka halaman "Setup Shopee API" di aplikasi Strong
2. Masukkan Shop ID yang sudah didapat
3. Masukkan Access Token dari developer console atau proses authorization
4. Klik "Simpan dan Test"

**Metode 2: Authorization Flow**
1. Klik link "Authorize App" di halaman setup
2. Login dengan akun Shopee seller
3. Approve aplikasi "Strong Order Management"
4. Copy authorization code yang didapat

### 4. Test Connection
Setelah input kredensial:
- Sistem akan otomatis test connection
- Jika berhasil, akan muncul info toko
- Jika gagal, akan muncul error message

### 5. Sync Orders
Setelah connection berhasil:
- Klik "Sync Orders Sekarang"
- Sistem akan mengambil orders terbaru dari Shopee
- Orders akan muncul di halaman "Orders"

## Troubleshooting

### Error "invalid_partner_id"
- Pastikan Partner ID benar: 1890343
- Pastikan API Key benar dari screenshot
- Periksa apakah aplikasi sudah di-approve di Shopee Developer Console

### Error "invalid_signature"
- Sistem sudah menggunakan signature generation yang benar
- Jika masih error, coba refresh halaman setup

### Error "access_denied"
- Pastikan Shop ID benar
- Pastikan Access Token valid dan tidak expired
- Coba authorize ulang aplikasi

### Error "shop_not_found"
- Double-check Shop ID dari URL Seller Center
- Pastikan menggunakan Shop ID yang benar

## Environment Variables (Opsional)
Untuk setup permanent, tambahkan ke environment:
```
SHOPEE_PARTNER_ID=1890343
SHOPEE_API_KEY=5d2759796855750424d9f653d6d247f84d50569d7d4ba41462037961746647
SHOPEE_SHOP_ID=[Your Shop ID]
SHOPEE_ACCESS_TOKEN=[Your Access Token]
```

## Catatan Penting
- Credentials dari screenshot sudah dikonfigurasi otomatis
- Hanya perlu menambahkan Shop ID dan Access Token
- Sistem akan otomatis handle signature generation
- Error "invalid_partner_id" biasanya menandakan perlu authorization ulang

## Testing Manual
Jika masih bermasalah, gunakan form "Setup Manual" di halaman setup:
1. Input Shop ID secara manual
2. Input Access Token secara manual
3. Sistem akan test dan simpan jika berhasil

---

**Untuk bantuan lebih lanjut, periksa logs di console atau hubungi support.**