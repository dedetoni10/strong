#!/usr/bin/env python3
"""
Direct import test for troubleshooting Excel import issues
"""

import os
import sys
import logging
import pandas as pd
from pathlib import Path

# Add the current directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_excel_import_direct():
    """Test Excel import directly without Flask"""
    
    # Import Flask app components
    from app import app, db
    from routes import process_order_data
    
    with app.app_context():
        # Test with smaller file first
        test_files = [
            "attached_assets/Daftar Pesanan.Hemat Kargo_42 (1)_1751900393119.xlsx",
            "attached_assets/Daftar Pesanan.SPX Standard_51_1751951477534.xlsx"
        ]
        
        for file_path in test_files:
            if not os.path.exists(file_path):
                logging.warning(f"File not found: {file_path}")
                continue
                
            try:
                logging.info(f"Testing import of: {file_path}")
                
                # Read Excel file
                df = pd.read_excel(file_path)
                logging.info(f"Successfully read Excel file with {len(df)} rows")
                logging.info(f"Columns: {list(df.columns)}")
                
                # Debug: Show sample data
                logging.info(f"Sample data from first 3 rows:")
                for i, row in df.head(3).iterrows():
                    logging.info(f"Row {i}: {dict(row)}")
                
                # Test process_order_data
                imported_count = process_order_data(df)
                logging.info(f"Successfully imported {imported_count} orders from {file_path}")
                
                # Test database query
                from database_models import Order
                total_orders = Order.query.count()
                logging.info(f"Total orders in database: {total_orders}")
                
                break  # Stop after first successful import
                
            except Exception as e:
                logging.error(f"Error testing {file_path}: {str(e)}")
                continue
        
        logging.info("Direct import test completed")

if __name__ == "__main__":
    test_excel_import_direct()