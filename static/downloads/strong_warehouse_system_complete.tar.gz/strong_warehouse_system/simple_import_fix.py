#!/usr/bin/env python3
"""
Simple and robust Excel import to fix the Internal Server Error
"""

from flask import Flask, request, flash, redirect, url_for
from app import app
from database_models import Order, OrderItem, db
import pandas as pd
import re
from collections import defaultdict
import logging
import time

def simple_excel_import(file_path):
    """Simple Excel import with robust error handling"""
    try:
        # Reset database connection
        db.session.close()
        db.engine.dispose()
        
        # Read Excel file
        df = pd.read_excel(file_path, engine='openpyxl')
        df = df.fillna('')
        records = df.to_dict('records')
        
        # Group by order_sn
        orders_dict = defaultdict(list)
        for row in records:
            order_sn = str(row.get('order_sn', '')).strip()
            if order_sn and order_sn != 'nan':
                orders_dict[order_sn].append(row)
        
        print(f"Found {len(orders_dict)} unique orders")
        
        # Get existing orders
        existing_orders = set()
        try:
            existing_orders = {order.order_number for order in Order.query.all()}
        except Exception as e:
            print(f"Error getting existing orders: {e}")
            existing_orders = set()
        
        # Process orders one by one
        imported_count = 0
        for order_number, order_rows in orders_dict.items():
            if order_number in existing_orders:
                continue
                
            try:
                if import_single_order(order_number, order_rows):
                    imported_count += 1
                    existing_orders.add(order_number)
                    
                    if imported_count % 10 == 0:
                        print(f"Imported {imported_count} orders...")
                        time.sleep(0.1)  # Small delay
                        
            except Exception as e:
                print(f"Error with order {order_number}: {str(e)}")
                continue
        
        print(f"Successfully imported {imported_count} orders")
        return imported_count
        
    except Exception as e:
        print(f"Error in simple_excel_import: {str(e)}")
        return 0

def import_single_order(order_number, order_rows):
    """Import a single order with individual transaction"""
    try:
        first_row = order_rows[0]
        
        # Extract customer info
        customer_name = str(first_row.get('order_receiver_name', '') or 
                          first_row.get('buyer_user_name', '') or 
                          'Unknown Customer').strip()
        
        tracking_number = str(first_row.get('tracking_number', '')).strip()
        if tracking_number == 'nan' or not tracking_number:
            tracking_number = None
        else:
            # Check for duplicate tracking number
            try:
                existing_tracking = Order.query.filter_by(tracking_number=tracking_number).first()
                if existing_tracking:
                    print(f"Duplicate tracking number {tracking_number} found, making unique...")
                    tracking_number = f"{tracking_number}_{order_number}"
            except:
                pass
        
        # Calculate total amount
        total_amount = 0.0
        product_info = str(first_row.get('product_info', ''))
        
        if product_info and product_info != 'nan':
            try:
                price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                
                for i, price_match in enumerate(price_matches):
                    try:
                        price_str = price_match.replace(',', '').replace('.', '')
                        price = float(price_str)
                        quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                        total_amount += price * quantity
                    except:
                        continue
            except:
                pass
        
        # Create order
        new_order = Order(
            order_number=order_number,
            tracking_number=tracking_number,
            customer_name=customer_name,
            customer_phone=None,
            customer_address=None,
            status='pending',
            total_amount=total_amount
        )
        
        db.session.add(new_order)
        db.session.flush()
        
        # Process items
        if product_info and product_info != 'nan':
            lines = product_info.replace('\r\n', '\n').split('\n')
            current_product = {}
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                if re.match(r'^\[\d+\]', line):
                    # Save previous product
                    if current_product.get('name'):
                        order_item = OrderItem(
                            order_id=new_order.id,
                            sku=current_product.get('sku', 'UNKNOWN'),
                            product_name=current_product.get('name', 'Unknown Product'),
                            quantity=current_product.get('quantity', 1),
                            price=current_product.get('price', 0.0)
                        )
                        db.session.add(order_item)
                    
                    # Start new product
                    current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                    
                    # Extract product name
                    if 'Nama Produk:' in line:
                        name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                        if name_match:
                            product_name = name_match.group(1).strip()
                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                            current_product['name'] = product_name
                    
                    # Extract price
                    price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                    if price_match:
                        try:
                            price_str = price_match.group(1).replace(',', '').replace('.', '')
                            current_product['price'] = float(price_str)
                        except:
                            pass
                    
                    # Extract quantity
                    qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                    if qty_match:
                        try:
                            current_product['quantity'] = int(qty_match.group(1))
                        except:
                            pass
            
            # Save last product
            if current_product.get('name'):
                order_item = OrderItem(
                    order_id=new_order.id,
                    sku=current_product.get('sku', 'UNKNOWN'),
                    product_name=current_product.get('name', 'Unknown Product'),
                    quantity=current_product.get('quantity', 1),
                    price=current_product.get('price', 0.0)
                )
                db.session.add(order_item)
        
        # Commit individual order
        db.session.commit()
        return True
        
    except Exception as e:
        db.session.rollback()
        print(f"Error processing order {order_number}: {str(e)}")
        return False

if __name__ == "__main__":
    with app.app_context():
        # Test with attached file
        result = simple_excel_import('attached_assets/Daftar Pesanan.Reguler_201.xlsx')
        print(f"Import completed: {result} orders imported")