#!/usr/bin/env python3
"""
Debug script untuk Shopee API authorization
"""
import requests
import logging
from shopee_api import ShopeeAPI

def test_shopee_endpoints():
    """Test berbagai endpoint dan format Shopee API"""
    print("=== Shopee API Debug Information ===")
    
    # Get current IP
    try:
        response = requests.get('https://api.ipify.org', timeout=5)
        current_ip = response.text
        print(f"Current IP Address: {current_ip}")
    except:
        print("Could not get current IP address")
    
    # Test auth URL generation
    shopee_api = ShopeeAPI()
    auth_url = shopee_api.get_auth_url()
    print(f"Authorization URL: {auth_url}")
    
    # Test auth URL response
    try:
        response = requests.get(auth_url, timeout=10, allow_redirects=False)
        print(f"Auth URL Status: {response.status_code}")
        if response.status_code == 302:
            print(f"Redirect to: {response.headers.get('Location')}")
            print("✅ Authorization URL is working correctly")
        else:
            print(f"❌ Auth URL failed: {response.text}")
    except Exception as e:
        print(f"❌ Auth URL error: {e}")
    
    print("\n=== IP Whitelist Issue ===")
    print("Error: Request Source IP is undeclared")
    print("Solution: Add IP address to Shopee Developer Console")
    print("Steps:")
    print("1. Login to Shopee Open Platform Console")
    print("2. Go to App list > Your App > IP Address Whitelist")
    print(f"3. Add IP: 35.197.78.132")
    print("4. Save and try authorization again")
    
    print("\n=== Alternative Solution ===")
    print("Use Mock API for development:")
    print("- Mock API doesn't require IP whitelist")
    print("- Provides realistic test data")
    print("- Good for development and testing")

if __name__ == "__main__":
    test_shopee_endpoints()