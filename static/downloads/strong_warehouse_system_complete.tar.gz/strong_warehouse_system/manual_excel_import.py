#!/usr/bin/env python3
"""
Manual Excel import script with enhanced error handling
"""

import pandas as pd
import logging
from app import app
from database_models import Order, OrderItem, Product, db
from datetime import datetime
import re
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_text(text):
    """Clean and validate text fields to prevent encoding issues"""
    if not text or str(text) == 'nan':
        return None
    try:
        text_str = str(text)
        cleaned = ''.join(char for char in text_str if char.isprintable() or char.isspace())
        return cleaned.strip()[:500]
    except Exception as e:
        logger.warning(f"Text cleaning error: {str(e)}")
        return "Invalid Text"

def import_excel_file(file_path):
    """Import Excel file with comprehensive error handling"""
    try:
        # Try multiple methods to read Excel file
        df = None
        error_messages = []
        
        # Method 1: Try with openpyxl (for .xlsx files)
        try:
            df = pd.read_excel(file_path, engine='openpyxl')
            logger.info(f"Successfully read {file_path} with openpyxl")
        except Exception as e1:
            error_messages.append(f"openpyxl: {str(e1)}")
            
            # Method 2: Try with xlrd (for .xls files)
            try:
                df = pd.read_excel(file_path, engine='xlrd')
                logger.info(f"Successfully read {file_path} with xlrd")
            except Exception as e2:
                error_messages.append(f"xlrd: {str(e2)}")
                
                # Method 3: Try without specifying engine
                try:
                    df = pd.read_excel(file_path)
                    logger.info(f"Successfully read {file_path} with default engine")
                except Exception as e3:
                    error_messages.append(f"default: {str(e3)}")
                    logger.error(f"All Excel reading methods failed: {'; '.join(error_messages)}")
                    return False
        
        if df is None:
            logger.error("Failed to read Excel file")
            return False
        
        # Log column names for debugging
        logger.info(f"Excel columns: {list(df.columns)}")
        
        # Clean DataFrame
        df = df.dropna(how='all').dropna(axis=1, how='all')
        df = df.fillna('')
        
        if df.empty:
            logger.warning("File is empty or has no valid data")
            return False
        
        # Convert to records
        records = df.to_dict('records')
        logger.info(f"Processing {len(records)} records")
        
        # Process records
        return process_order_data(records)
        
    except Exception as e:
        logger.error(f"Error importing Excel file: {str(e)}")
        return False

def process_order_data(data):
    """Process order data with enhanced error handling"""
    try:
        # Group rows by order_sn
        orders_dict = defaultdict(list)
        
        for row in data:
            if not isinstance(row, dict):
                continue
                
            # Try different column names for order number
            order_sn = None
            for col_name in ['order_sn', 'No. Pesanan', 'Order Number', 'Nomor Pesanan']:
                if col_name in row and row[col_name]:
                    order_sn = str(row[col_name]).strip()
                    break
            
            if order_sn and order_sn != 'nan':
                orders_dict[order_sn].append(row)
        
        logger.info(f"Found {len(orders_dict)} unique orders")
        
        # Process each order
        imported_count = 0
        batch_size = 10
        
        for i, (order_number, order_rows) in enumerate(orders_dict.items()):
            try:
                if process_single_order(order_number, order_rows):
                    imported_count += 1
                
                # Commit in batches
                if (i + 1) % batch_size == 0:
                    db.session.commit()
                    logger.info(f"Committed batch {(i + 1) // batch_size}")
                    
            except Exception as e:
                logger.error(f"Error processing order {order_number}: {str(e)}")
                db.session.rollback()
                continue
        
        # Final commit
        db.session.commit()
        logger.info(f"Successfully imported {imported_count} orders")
        return imported_count
        
    except Exception as e:
        logger.error(f"Error in process_order_data: {str(e)}")
        db.session.rollback()
        return 0

def process_single_order(order_number, order_rows):
    """Process a single order with all its items"""
    try:
        # Check if order already exists
        existing_order = Order.query.filter_by(order_number=order_number).first()
        if existing_order:
            logger.warning(f"Order {order_number} already exists, skipping")
            return False
        
        first_row = order_rows[0]
        
        # Extract order information
        customer_name = clean_text(
            first_row.get('order_receiver_name') or 
            first_row.get('buyer_user_name') or 
            first_row.get('Username Pembeli') or 
            first_row.get('Nama Penerima') or 
            'Unknown Customer'
        )
        
        tracking_number = clean_text(
            first_row.get('tracking_number') or 
            first_row.get('No. Resi') or 
            None
        )
        
        customer_phone = clean_text(
            first_row.get('phone') or 
            first_row.get('No. Telepon') or 
            None
        )
        
        customer_address = clean_text(
            first_row.get('address') or 
            first_row.get('Alamat Pengiriman') or 
            None
        )
        
        # Calculate total amount
        total_amount = 0.0
        for row in order_rows:
            product_info = str(row.get('product_info', '') or row.get('Info Produk', '') or '')
            if product_info and product_info != 'nan':
                try:
                    price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                    qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                    
                    for i, price_match in enumerate(price_matches):
                        try:
                            price_str = price_match.replace(',', '').replace('.', '')
                            price = float(price_str)
                            quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                            total_amount += price * quantity
                        except (ValueError, IndexError):
                            continue
                except Exception:
                    continue
        
        # Create order
        new_order = Order(
            order_number=order_number,
            tracking_number=tracking_number,
            customer_name=customer_name,
            customer_phone=customer_phone,
            customer_address=customer_address,
            status='pending',
            total_amount=total_amount
        )
        
        db.session.add(new_order)
        db.session.flush()
        
        # Process order items
        item_count = 0
        product_info = str(order_rows[0].get('product_info', '') or order_rows[0].get('Info Produk', '') or '')
        
        if product_info and product_info != 'nan':
            lines = product_info.replace('\r\n', '\n').split('\n')
            current_product = {}
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                # Check if this is start of new product
                if re.match(r'^\[\d+\]', line):
                    # Save previous product
                    if current_product.get('name'):
                        try:
                            order_item = OrderItem(
                                order_id=new_order.id,
                                sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                                product_name=clean_text(current_product.get('name', 'Unknown Product')),
                                quantity=current_product.get('quantity', 1),
                                price=current_product.get('price', 0.0)
                            )
                            db.session.add(order_item)
                            item_count += 1
                        except Exception as e:
                            logger.error(f"Error creating order item: {str(e)}")
                    
                    # Start new product
                    current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                    
                    # Extract product name
                    if 'Nama Produk:' in line:
                        name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                        if name_match:
                            product_name = name_match.group(1).strip()
                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                            current_product['name'] = product_name
                    
                    # Extract price
                    price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                    if price_match:
                        try:
                            price_str = price_match.group(1).replace(',', '').replace('.', '')
                            current_product['price'] = float(price_str)
                        except ValueError:
                            pass
                    
                    # Extract quantity
                    qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                    if qty_match:
                        try:
                            current_product['quantity'] = int(qty_match.group(1))
                        except ValueError:
                            pass
            
            # Save last product
            if current_product.get('name'):
                try:
                    order_item = OrderItem(
                        order_id=new_order.id,
                        sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                        product_name=clean_text(current_product.get('name', 'Unknown Product')),
                        quantity=current_product.get('quantity', 1),
                        price=current_product.get('price', 0.0)
                    )
                    db.session.add(order_item)
                    item_count += 1
                except Exception as e:
                    logger.error(f"Error creating last order item: {str(e)}")
        
        logger.info(f"Created order {order_number} with {item_count} items")
        return True
        
    except Exception as e:
        logger.error(f"Error processing single order {order_number}: {str(e)}")
        return False

if __name__ == "__main__":
    with app.app_context():
        file_path = "attached_assets/Daftar Pesanan.Reguler_201_1752031646009.xlsx"
        result = import_excel_file(file_path)
        
        if result:
            print(f"✅ Successfully imported {result} orders")
        else:
            print("❌ Import failed")