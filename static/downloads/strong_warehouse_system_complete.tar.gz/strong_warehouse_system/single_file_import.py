#!/usr/bin/env python3
"""
Single file import with duplicate tracking number handling
"""

import pandas as pd
import logging
from app import app
from database_models import Order, OrderItem, db
import re
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_text(text):
    if not text or str(text) == 'nan':
        return None
    try:
        text_str = str(text)
        cleaned = ''.join(char for char in text_str if char.isprintable() or char.isspace())
        return cleaned.strip()[:500]
    except:
        return "Invalid Text"

def import_all_orders():
    """Import all orders from the file"""
    try:
        with app.app_context():
            # Read the Excel file
            df = pd.read_excel("attached_assets/Daftar Pesanan.Reguler_201_1752031646009.xlsx", engine='openpyxl')
            df = df.fillna('')
            records = df.to_dict('records')
            
            # Group by order_sn
            orders_dict = defaultdict(list)
            for row in records:
                order_sn = str(row.get('order_sn', '')).strip()
                if order_sn and order_sn != 'nan':
                    orders_dict[order_sn].append(row)
            
            logger.info(f"Total orders in file: {len(orders_dict)}")
            
            # Check which orders are already imported
            existing_orders = set()
            existing_order_numbers = [order.order_number for order in Order.query.all()]
            existing_orders.update(existing_order_numbers)
            
            logger.info(f"Already imported: {len(existing_orders)} orders")
            
            # Import remaining orders
            remaining_orders = {k: v for k, v in orders_dict.items() if k not in existing_orders}
            logger.info(f"Remaining to import: {len(remaining_orders)} orders")
            
            # Track duplicate tracking numbers
            existing_tracking = set()
            existing_tracking_numbers = [order.tracking_number for order in Order.query.all() if order.tracking_number]
            existing_tracking.update(existing_tracking_numbers)
            
            # Import one by one
            imported_count = 0
            for order_number, order_rows in remaining_orders.items():
                try:
                    first_row = order_rows[0]
                    
                    # Extract order information
                    customer_name = clean_text(
                        first_row.get('order_receiver_name') or 
                        first_row.get('buyer_user_name') or 
                        'Unknown Customer'
                    )
                    
                    tracking_number = clean_text(first_row.get('tracking_number'))
                    
                    # Handle duplicate tracking numbers
                    if tracking_number and tracking_number in existing_tracking:
                        logger.warning(f"Duplicate tracking number {tracking_number} for order {order_number}, setting to None")
                        tracking_number = None
                    elif tracking_number:
                        existing_tracking.add(tracking_number)
                    
                    # Calculate total amount
                    total_amount = 0.0
                    product_info = str(first_row.get('product_info', ''))
                    
                    if product_info and product_info != 'nan':
                        try:
                            price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                            qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                            
                            for i, price_match in enumerate(price_matches):
                                try:
                                    price_str = price_match.replace(',', '').replace('.', '')
                                    price = float(price_str)
                                    quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                                    total_amount += price * quantity
                                except (ValueError, IndexError):
                                    continue
                        except:
                            pass
                    
                    # Create order
                    new_order = Order(
                        order_number=order_number,
                        tracking_number=tracking_number,
                        customer_name=customer_name,
                        customer_phone=None,
                        customer_address=None,
                        status='pending',
                        total_amount=total_amount
                    )
                    
                    db.session.add(new_order)
                    db.session.flush()
                    
                    # Process order items
                    if product_info and product_info != 'nan':
                        lines = product_info.replace('\r\n', '\n').split('\n')
                        current_product = {}
                        
                        for line in lines:
                            line = line.strip()
                            if not line:
                                continue
                            
                            # Check if this is start of new product
                            if re.match(r'^\[\d+\]', line):
                                # Save previous product
                                if current_product.get('name'):
                                    try:
                                        order_item = OrderItem(
                                            order_id=new_order.id,
                                            sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                                            product_name=clean_text(current_product.get('name', 'Unknown Product')),
                                            quantity=current_product.get('quantity', 1),
                                            price=current_product.get('price', 0.0)
                                        )
                                        db.session.add(order_item)
                                    except Exception as e:
                                        logger.error(f"Error creating order item: {str(e)}")
                                
                                # Start new product
                                current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                                
                                # Extract product name
                                if 'Nama Produk:' in line:
                                    name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                                    if name_match:
                                        product_name = name_match.group(1).strip()
                                        product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                                        current_product['name'] = product_name
                                
                                # Extract price
                                price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                                if price_match:
                                    try:
                                        price_str = price_match.group(1).replace(',', '').replace('.', '')
                                        current_product['price'] = float(price_str)
                                    except ValueError:
                                        pass
                                
                                # Extract quantity
                                qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                                if qty_match:
                                    try:
                                        current_product['quantity'] = int(qty_match.group(1))
                                    except ValueError:
                                        pass
                        
                        # Save last product
                        if current_product.get('name'):
                            try:
                                order_item = OrderItem(
                                    order_id=new_order.id,
                                    sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                                    product_name=clean_text(current_product.get('name', 'Unknown Product')),
                                    quantity=current_product.get('quantity', 1),
                                    price=current_product.get('price', 0.0)
                                )
                                db.session.add(order_item)
                            except Exception as e:
                                logger.error(f"Error creating last order item: {str(e)}")
                    
                    # Commit each order individually
                    db.session.commit()
                    imported_count += 1
                    logger.info(f"Imported order {order_number} ({imported_count}/{len(remaining_orders)})")
                    
                except Exception as e:
                    logger.error(f"Error processing order {order_number}: {str(e)}")
                    db.session.rollback()
                    continue
            
            logger.info(f"Successfully imported {imported_count} orders")
            return imported_count
            
    except Exception as e:
        logger.error(f"Error in import_all_orders: {str(e)}")
        return 0

if __name__ == "__main__":
    result = import_all_orders()
    print(f"✅ Successfully imported {result} orders")