# Panduan Pemulihan Sistem Excel Import

## Status Sistem yang Berhasil (9 Juli 2025)

### Komponen Utama yang Sudah Bekerja:
1. **Interface Import Excel** - `/orders/import` dengan progress bar real-time
2. **Bulk Import Engine** - `bulk_import_final.py` dengan batch processing
3. **Database Models** - PostgreSQL dengan models yang stabil
4. **Frontend JavaScript** - Error handling dan JSON parsing yang robust

### File Kunci yang Harus Dijaga:

#### 1. `templates/import_orders_progress.html`
- **Line 178**: `fetch('/orders/import', {` (HARUS /orders/import, BUKAN /import_orders)
- **Line 183-190**: JSON parsing dengan error handling
```javascript
const responseText = await response.text();
let result;
try {
    result = JSON.parse(responseText);
} catch (parseError) {
    throw new Error(`Invalid JSON response: ${responseText}`);
}
```

#### 2. `routes.py`
- **Function**: `import_orders()` di line 863
- **Route**: `@app.route('/orders/import', methods=['GET', 'POST'])`
- **Import**: `from bulk_import_final import bulk_import_single_file`

#### 3. `bulk_import_final.py`
- **Function**: `bulk_import_single_file(file_path)`
- **Batch size**: 50 orders per batch
- **Error handling**: Individual order commits
- **Return format**: `{'success': True, 'imported_count': X, 'skipped_count': Y}`

### Konfigurasi Database:
```sql
-- Tables yang diperlukan:
- orders (dengan tracking_number UNIQUE)
- order_items (dengan foreign key ke orders)
- products (untuk inventory)
- picking_sessions, stock_movements, scan_history
```

## Cara Mengembalikan ke Kondisi Ini:

### 1. Jika Ada Error JavaScript "Unexpected token '<'":
```javascript
// Pastikan URL di templates/import_orders_progress.html line 178:
const response = await fetch('/orders/import', {
    method: 'POST',
    body: formData
});
```

### 2. Jika Import Tidak Jalan:
- Cek route di `routes.py` harus ada `@app.route('/orders/import')`
- Pastikan import `bulk_import_final` tidak error
- Cek database connection di `bulk_import_final.py`

### 3. Jika Timeout Error:
- Batch size di `bulk_import_final.py` harus 50 (tidak lebih)
- Pastikan individual commit per order
- Cek connection pool database

### 4. Jika JSON Error:
- Pastikan response format di routes.py:
```python
return jsonify({
    'success': True,
    'imported_count': result['imported_count'],
    'skipped_count': result.get('skipped_count', 0),
    'message': f'Import berhasil: {result["imported_count"]} pesanan'
})
```

## Backup Files (Simpan Sebagai Referensi):

### Working Route Function:
```python
@app.route('/orders/import', methods=['GET', 'POST'])
def import_orders():
    if request.method == 'POST':
        uploaded_files = request.files.getlist('order_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'Tidak ada file yang dipilih'})
        
        file = uploaded_files[0]
        
        if file.filename == '' or not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'success': False, 'message': 'Format file tidak valid'})
        
        try:
            import tempfile
            import os
            
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, file.filename)
            file.save(temp_file_path)
            
            from bulk_import_final import bulk_import_single_file
            result = bulk_import_single_file(temp_file_path)
            
            os.remove(temp_file_path)
            
            if result.get('success'):
                return jsonify({
                    'success': True,
                    'imported_count': result['imported_count'],
                    'skipped_count': result.get('skipped_count', 0),
                    'message': f'Import berhasil: {result["imported_count"]} pesanan'
                })
            else:
                return jsonify({
                    'success': False,
                    'imported_count': 0,
                    'message': 'Import gagal'
                })
                
        except Exception as e:
            return jsonify({
                'success': False,
                'imported_count': 0,
                'message': f'Error: {str(e)}'
            })
    
    return render_template('import_orders_progress.html')
```

## Testing Checklist:

### 1. Test Interface:
- [ ] Buka `/orders/import`
- [ ] Upload file Excel
- [ ] Progress bar muncul
- [ ] Statistics update real-time
- [ ] Log menunjukkan proses import

### 2. Test Database:
- [ ] Data tersimpan di table orders
- [ ] Order items tersimpan dengan benar
- [ ] Duplicate detection bekerja
- [ ] Batch processing tidak timeout

### 3. Test Error Handling:
- [ ] File format salah ditolak
- [ ] Network error ditangani
- [ ] JSON parsing error ditangani
- [ ] Database error ditangani

## Perintah Darurat:

### Reset Database:
```sql
DELETE FROM scan_history; 
DELETE FROM stock_movements; 
DELETE FROM picking_sessions; 
DELETE FROM order_items; 
DELETE FROM orders;
```

### Restart Server:
```bash
pkill -f gunicorn
# Server akan auto-restart
```

### Check Database Status:
```sql
SELECT COUNT(*) FROM orders;
SELECT COUNT(*) FROM order_items;
```

## Catatan Penting:

1. **JANGAN UBAH** URL `/orders/import` di JavaScript
2. **JANGAN UBAH** batch size di `bulk_import_final.py`
3. **SELALU TEST** dengan file kecil dulu sebelum file besar
4. **BACKUP** file working sebelum modifikasi
5. **MONITOR** log database untuk timeout issues

## Kondisi Sukses Terakhir:
- **Tanggal**: 9 Juli 2025
- **Total Import**: 2,245 orders berhasil
- **Files Tested**: Multiple Excel files (50-200 orders each)
- **Status**: Production ready dengan error handling lengkap