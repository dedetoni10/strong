#!/usr/bin/env python3
"""
Fix SKU Import - Update existing orders with correct SKU from product_info
"""

import pandas as pd
import psycopg2
from psycopg2.extras import execute_batch
import re
import os

def get_db_connection():
    """Get direct database connection"""
    database_url = os.environ.get('DATABASE_URL')
    return psycopg2.connect(database_url)

def clean_text(text):
    """Clean text to prevent encoding issues"""
    if not text:
        return ""
    
    text = str(text)
    text = re.sub(r'[^\x00-\x7F]+', '', text)  # Remove non-ASCII
    text = re.sub(r'\s+', ' ', text)  # Normalize whitespace
    
    return text[:500]  # Limit length

def extract_sku_from_product_info(product_info):
    """Extract SKU from product_info string"""
    
    skus = []
    lines = product_info.split('\n')
    
    for line in lines:
        if 'Nama Produk:' in line:
            # Extract SKU from Nomor Referensi SKU
            sku_match = re.search(r'Nomor Referensi SKU:\s*([^;]+)', line)
            if sku_match:
                sku = sku_match.group(1).strip()
                sku = clean_text(sku)
                skus.append(sku)
    
    return skus

def fix_sku_for_orders():
    """Fix SKU for all orders"""
    
    try:
        # Read Excel files
        files = [
            "attached_assets/Daftar Pesanan.Hemat Kargo_200_1752036301406.xlsx",
            "attached_assets/Daftar Pesanan.Reguler_162_1752037023912.xlsx"
        ]
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        updates_made = 0
        
        for file_path in files:
            try:
                df = pd.read_excel(file_path)
                df = df.fillna("")
                
                print(f"Processing {file_path}...")
                
                for index, row in df.iterrows():
                    try:
                        order_number = str(row.get('order_sn', ''))
                        product_info = str(row.get('product_info', ''))
                        
                        if not order_number or not product_info:
                            continue
                        
                        # Extract SKUs from product_info
                        correct_skus = extract_sku_from_product_info(product_info)
                        
                        if not correct_skus:
                            continue
                        
                        # Get order ID
                        cursor.execute("SELECT id FROM orders WHERE order_number = %s", (order_number,))
                        order_result = cursor.fetchone()
                        
                        if not order_result:
                            continue
                        
                        order_id = order_result[0]
                        
                        # Get existing order items
                        cursor.execute("""
                            SELECT id, sku FROM order_items 
                            WHERE order_id = %s 
                            ORDER BY id
                        """, (order_id,))
                        
                        existing_items = cursor.fetchall()
                        
                        # Update SKUs
                        for i, (item_id, old_sku) in enumerate(existing_items):
                            if i < len(correct_skus) and correct_skus[i]:
                                new_sku = correct_skus[i]
                                
                                # Update SKU
                                cursor.execute("""
                                    UPDATE order_items 
                                    SET sku = %s 
                                    WHERE id = %s
                                """, (new_sku, item_id))
                                
                                updates_made += 1
                                print(f"Updated {order_number} item {i+1}: {old_sku} -> {new_sku}")
                        
                        # Commit every 10 orders
                        if updates_made % 10 == 0:
                            conn.commit()
                            
                    except Exception as e:
                        print(f"Error processing order {order_number}: {str(e)}")
                        continue
                        
            except Exception as e:
                print(f"Error processing file {file_path}: {str(e)}")
                continue
        
        # Final commit
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"\n=== SKU FIX COMPLETE ===")
        print(f"Total SKU updates made: {updates_made}")
        
        return {'success': True, 'updates_made': updates_made}
        
    except Exception as e:
        print(f"SKU fix failed: {str(e)}")
        return {'success': False, 'message': str(e)}

if __name__ == "__main__":
    result = fix_sku_for_orders()
    print(f"Final result: {result}")