#!/usr/bin/env python3
"""
Raw SQL Import - No ORM, No Complexity
Direct SQL import to avoid all framework issues
"""

import pandas as pd
import psycopg2
import os
import re
from datetime import datetime

def get_db_connection():
    """Get direct database connection"""
    database_url = os.environ.get('DATABASE_URL')
    return psycopg2.connect(database_url)

def safe_str(value):
    """Convert to safe string"""
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()

def import_all_orders():
    """Import all orders using raw SQL"""
    
    # File path
    file_path = "attached_assets/Daftar Pesanan.Hemat Kargo_200_1752036301406.xlsx"
    
    try:
        # Read Excel
        df = pd.read_excel(file_path)
        print(f"Loaded {len(df)} rows from Excel file")
        
        # Fill NaN
        df = df.fillna("")
        
        # Get database connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        imported_count = 0
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Get order number
                order_number = safe_str(row.get('order_sn', ''))
                if not order_number:
                    continue
                
                # Check if exists
                cursor.execute("SELECT COUNT(*) FROM orders WHERE order_number = %s", (order_number,))
                if cursor.fetchone()[0] > 0:
                    print(f"Order {order_number} already exists, skipping")
                    continue
                
                # Get basic info
                customer_name = safe_str(row.get('order_receiver_name', '')) or safe_str(row.get('buyer_user_name', '')) or 'Unknown'
                tracking_number = safe_str(row.get('tracking_number', ''))
                if not tracking_number:
                    tracking_number = None
                
                # Insert order
                cursor.execute("""
                    INSERT INTO orders (order_number, tracking_number, customer_name, total_amount, status, created_at, updated_at)
                    VALUES (%s, %s, %s, 0.0, 'pending', NOW(), NOW())
                    RETURNING id
                """, (order_number, tracking_number, customer_name))
                
                order_id = cursor.fetchone()[0]
                
                # Process products
                product_info = safe_str(row.get('product_info', ''))
                if product_info:
                    lines = product_info.split('\n')
                    item_num = 0
                    
                    for line in lines:
                        if 'Nama Produk:' in line:
                            item_num += 1
                            
                            # Extract product name
                            name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                            product_name = name_match.group(1).strip() if name_match else f'Product {item_num}'
                            
                            # Clean product name
                            product_name = re.sub(r'^\[BAYAR DI TEMPAT\]\s*', '', product_name)
                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                            
                            # Extract quantity
                            qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                            quantity = int(qty_match.group(1)) if qty_match else 1
                            
                            # Extract price
                            price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                            price = 0.0
                            if price_match:
                                try:
                                    price = float(price_match.group(1).replace(',', '').replace('.', ''))
                                except:
                                    price = 0.0
                            
                            # Insert order item
                            cursor.execute("""
                                INSERT INTO order_items (order_id, sku, product_name, quantity, price, picked_quantity, is_picked, created_at, updated_at)
                                VALUES (%s, %s, %s, %s, %s, 0, false, NOW(), NOW())
                            """, (order_id, f'SKU-{order_number}-{item_num}', product_name, quantity, price))
                
                # Commit each order
                conn.commit()
                imported_count += 1
                
                # Progress
                if imported_count % 10 == 0:
                    print(f"Imported {imported_count} orders...")
                
            except Exception as e:
                conn.rollback()
                print(f"Error importing order {order_number}: {str(e)}")
                continue
        
        # Close connection
        cursor.close()
        conn.close()
        
        print(f"Successfully imported {imported_count} orders")
        return {'success': True, 'imported': imported_count}
        
    except Exception as e:
        print(f"Import failed: {str(e)}")
        return {'success': False, 'imported': 0}

if __name__ == "__main__":
    result = import_all_orders()
    print(f"Final result: {result}")