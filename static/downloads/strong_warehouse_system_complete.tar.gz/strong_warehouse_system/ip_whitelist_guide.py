#!/usr/bin/env python3
"""
IP Whitelist Guide untuk Shopee API
"""

def show_ip_guide():
    print("="*60)
    print("PANDUAN IP WHITELIST SHOPEE API")
    print("="*60)
    print()
    print("MASALAH:")
    print("- Server menggunakan multiple IP addresses")
    print("- Setiap request bisa menggunakan IP yang berbeda")
    print("- Shopee API memerlukan semua IP terdaftar di whitelist")
    print()
    print("IP ADDRESSES YANG PERLU DITAMBAHKAN:")
    print("1. 34.96.44.144  (terbaru dari error)")
    print("2. 34.96.44.178  (dari error sebelumnya)")
    print("3. 34.83.54.207  (dari sistem detection)")
    print("4. 35.197.78.132 (yang sudah ditambahkan)")
    print()
    print("SOLUSI SEMENTARA:")
    print("- Gunakan Mock API untuk development")
    print("- Mock API memberikan data realistis")
    print("- Tidak memerlukan IP whitelist")
    print()
    print("SOLUSI PERMANEN:")
    print("1. Login ke https://open.shopee.com")
    print("2. Masuk ke App List > Your App > IP Address Whitelist")
    print("3. Tambahkan SEMUA IP di atas")
    print("4. Save dan test authorization lagi")
    print()
    print("="*60)

if __name__ == "__main__":
    show_ip_guide()