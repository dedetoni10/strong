"""
STRONG VERSI 02 - CODE BACKUP
Tanggal: 9 Juli 2025
Status: Production Ready dengan Barcode Scanner Working

Backup kode penting untuk restore jika diperlukan
"""

# ===== BARCODE SCANNER CODE (picking_interface.html) =====
BARCODE_SCANNER_CODE = '''
function detectBarcode(video) {
    const scanResult = document.getElementById('scan-result');
    let isScanning = true;
    
    scanResult.textContent = 'Memuat ZXing scanner...';
    scanResult.style.background = 'rgba(0,123,255,0.7)';
    scanResult.style.color = 'white';
    scanResult.style.padding = '10px';
    scanResult.style.borderRadius = '5px';
    scanResult.style.textAlign = 'center';
    scanResult.style.marginTop = '10px';
    
    // Load ZXing library (most reliable)
    const zxingScript = document.createElement('script');
    zxingScript.src = 'https://unpkg.com/@zxing/library@0.20.0/umd/index.min.js';
    zxingScript.onload = function() {
        scanResult.textContent = 'Menginisialisasi ZXing scanner...';
        
        try {
            const codeReader = new ZXing.BrowserQRCodeReader();
            
            scanResult.textContent = 'Scanner siap - Arahkan kamera ke barcode/QR';
            
            // Start continuous decode
            codeReader.decodeFromVideoDevice(null, video, (result, error) => {
                if (result && isScanning) {
                    const detectedCode = result.getText();
                    console.log('ZXing detected:', detectedCode);
                    
                    scanResult.textContent = `Kode terdeteksi: ${detectedCode}`;
                    scanResult.style.background = 'rgba(40, 167, 69, 0.8)';
                    
                    // Fill input field
                    if (currentItemId) {
                        const input = document.querySelector(`input[data-item-id="${currentItemId}"]`);
                        if (input) {
                            input.value = detectedCode;
                            validateInput(input);
                            isScanning = false;
                            codeReader.reset();
                            setTimeout(closeCamera, 1500);
                        }
                    }
                }
                
                if (error && error.name !== 'NotFoundException') {
                    console.log('ZXing error:', error);
                }
            });
            
        } catch (err) {
            console.log('ZXing initialization error:', err);
            fallbackToManual();
        }
    };
    
    zxingScript.onerror = function() {
        console.log('Failed to load ZXing, using manual input');
        fallbackToManual();
    };
    
    function fallbackToManual() {
        scanResult.textContent = 'Klik kamera untuk input manual';
        scanResult.style.background = 'rgba(255, 193, 7, 0.8)';
        
        video.addEventListener('click', handleManualInput);
    }
    
    function handleManualInput() {
        isScanning = false;
        const userInput = prompt('Masukkan kode barcode/QR yang terlihat di kamera:');
        if (userInput && currentItemId) {
            const input = document.querySelector(`input[data-item-id="${currentItemId}"]`);
            if (input) {
                input.value = userInput.trim();
                validateInput(input);
                closeCamera();
            }
        } else {
            isScanning = true;
        }
    }
    
    // Add manual input option
    video.addEventListener('click', handleManualInput);
    
    // Add script to document
    document.head.appendChild(zxingScript);
}
'''

# ===== BULK IMPORT WORKING CODE =====
BULK_IMPORT_CODE = '''
def bulk_import_single_file(file_path):
    """Bulk import from single file"""
    
    try:
        # Database connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Read Excel file
        df = pd.read_excel(file_path)
        
        # Process orders
        processed_count = 0
        for index, row in df.iterrows():
            try:
                # Process single order
                order_number = safe_str(row.get('No. Pesanan', ''))
                if order_number:
                    # Prepare order data
                    order_data = prepare_order_data(order_number, row)
                    
                    # Insert order and items
                    cursor.execute("""
                        INSERT INTO orders (order_number, tracking_number, customer_name, 
                                          customer_phone, customer_address, total_amount, 
                                          order_date, status, created_at, updated_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (order_number) DO NOTHING
                    """, order_data)
                    
                    # Commit individual order
                    conn.commit()
                    processed_count += 1
                    
            except Exception as e:
                print(f"Error processing order {order_number}: {e}")
                conn.rollback()
                continue
        
        cursor.close()
        conn.close()
        
        return processed_count
        
    except Exception as e:
        print(f"Error in bulk_import_single_file: {e}")
        return 0
'''

# ===== DATABASE MODELS KEY PARTS =====
DATABASE_MODELS_KEY = '''
class Order(db.Model):
    __tablename__ = 'orders'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_number: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    tracking_number: Mapped[Optional[str]] = mapped_column(String(100), unique=True)
    customer_name: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_phone: Mapped[Optional[str]] = mapped_column(String(50))
    customer_address: Mapped[Optional[str]] = mapped_column(Text)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    order_date: Mapped[Optional[datetime]] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(50), default='pending')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(Integer, db.ForeignKey('orders.id'), nullable=False)
    sku: Mapped[str] = mapped_column(String(100), nullable=False)
    product_name: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    price: Mapped[float] = mapped_column(Float, default=0.0)
    picked_quantity: Mapped[int] = mapped_column(Integer, default=0)
    is_picked: Mapped[bool] = mapped_column(Boolean, default=False)
    picked_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
'''

# ===== RECOVERY INSTRUCTIONS =====
RECOVERY_INSTRUCTIONS = '''
CARA RESTORE STRONG VERSI 02:

1. Restore Barcode Scanner:
   - Buka templates/picking_interface.html
   - Ganti function detectBarcode() dengan BARCODE_SCANNER_CODE di atas
   - Pastikan menggunakan ZXing library 0.20.0

2. Restore Database:
   - Pastikan database_models.py sesuai dengan DATABASE_MODELS_KEY
   - Jalankan: python -c "from app import app, db; app.app_context().push(); db.create_all()"

3. Restore Import System:
   - Pastikan bulk_import_final.py berfungsi dengan baik
   - Test dengan file Excel kecil dulu

4. Verification:
   - Test barcode scanner di /picking/[ORDER_ID]
   - Test Excel import di Orders page
   - Test semua fitur utama

5. Rollback jika diperlukan:
   - Gunakan git atau backup manual
   - Restore dari STRONG_VERSI_01_BACKUP.md jika perlu
'''

print("STRONG VERSI 02 - CODE BACKUP CREATED")
print("Tanggal: 9 Juli 2025")
print("Status: Production Ready dengan Barcode Scanner")
print("Fitur: ZXing Scanner + Manual Fallback + Excel Import")