#!/usr/bin/env python3
"""
Test IP whitelist issue dengan berbagai pendekatan
"""
import requests
import json

def test_ip_detection():
    """Test berbagai service untuk deteksi IP"""
    print("=== IP Detection Test ===")
    
    services = [
        ('ipify.org', 'https://api.ipify.org'),
        ('httpbin.org', 'https://httpbin.org/ip'),
        ('ipinfo.io', 'https://ipinfo.io/ip'),
        ('ifconfig.me', 'https://ifconfig.me/ip')
    ]
    
    for name, url in services:
        try:
            response = requests.get(url, timeout=5)
            if name == 'httpbin.org':
                data = response.json()
                ip = data.get('origin', '').split(',')[0].strip()
            else:
                ip = response.text.strip()
            print(f"{name}: {ip}")
        except Exception as e:
            print(f"{name}: Error - {e}")

def test_shopee_token_manually():
    """Test token endpoint dengan manual request"""
    print("\n=== Manual Token Test ===")
    
    import time
    import hmac
    import hashlib
    
    # Credentials
    partner_id = 2011911
    api_key = "shpk634a47494b726d41537068786c456c6c76637673416e6872517959705050"
    
    # Generate signature
    timestamp = int(time.time())
    path = "/api/v2/auth/token/get"
    base_string = f"{partner_id}{path}{timestamp}"
    
    signature = hmac.new(
        api_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    print(f"Timestamp: {timestamp}")
    print(f"Base string: {base_string}")
    print(f"Signature: {signature}")
    
    # Test request
    url = f"https://partner.shopeemobile.com{path}"
    query_params = {
        "partner_id": partner_id,
        "timestamp": timestamp,
        "sign": signature
    }
    
    body = {
        "code": "test_code",
        "shop_id": 1420428877,
        "partner_id": partner_id
    }
    
    try:
        response = requests.post(url, params=query_params, json=body, timeout=10)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 403:
            error_data = response.json()
            if "source_ip_undeclared" in error_data.get("error", ""):
                print("❌ IP masih belum terdaftar di whitelist")
            else:
                print("✅ IP sudah terdaftar, error lain")
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_ip_detection()
    test_shopee_token_manually()