from flask import render_template, request, redirect, url_for, flash, jsonify, Response, session, make_response
from app import app, db
import models
from shopee_api import shopee_api
import logging
# Import database models after app context to avoid circular import
from database_models import Order, OrderItem, Product, PickingSession, StockMovement, ScanHistory
from datetime import datetime, timedelta
import csv
import io
from sqlalchemy import func, text
import json

# Simple user accounts for demo
DEMO_USERS = {
    'admin_strong': 'StrongDemo2025!',
    'demo_user': 'demo123',
    'shopee_test': 'shopee2025'
}

def login_required(f):
    """Decorator to require login for protected routes"""
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username in DEMO_USERS and DEMO_USERS[username] == password:
            session['logged_in'] = True
            session['username'] = username
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Username atau password salah', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout and clear session"""
    session.clear()
    flash('Anda telah logout', 'info')
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    """Dashboard with overview statistics"""
    total_orders = Order.query.count()
    total_products = Product.query.count()
    pending_orders = Order.query.filter_by(status='pending').count()
    low_stock_products = Product.query.filter(Product.quantity <= Product.minimum_stock).count()
    
    stats = {
        'total_orders': total_orders,
        'total_products': total_products,
        'pending_orders': pending_orders,
        'low_stock_products': low_stock_products
    }
    
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    low_stock_items = Product.query.filter(Product.quantity <= Product.minimum_stock).all()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_orders=recent_orders,
                         low_stock_items=low_stock_items)

@app.route('/orders')
@login_required
def orders():
    """Orders management page with pagination"""
    search_query = request.args.get('search', '')
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    per_page = 50  # 50 orders per page
    
    query = Order.query
    
    # Apply filters
    if search_query:
        query = query.filter(
            (Order.customer_name.ilike(f'%{search_query}%')) |
            (Order.order_number.ilike(f'%{search_query}%')) |
            (Order.tracking_number.ilike(f'%{search_query}%'))
        )
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    # Sort by creation date (newest first) and paginate
    pagination = query.order_by(Order.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    orders = pagination.items
    
    # Get status counts for tab badges
    pending_count = Order.query.filter(Order.status == 'pending').count()
    processing_count = Order.query.filter(Order.status == 'processing').count()
    shipped_count = Order.query.filter(Order.status == 'shipped').count()
    delivered_count = Order.query.filter(Order.status == 'delivered').count()
    cancelled_count = Order.query.filter(Order.status == 'cancelled').count()
    
    statuses = ['pending', 'picking', 'picked', 'packing', 'packed', 'ready_for_pickup']
    
    return render_template('orders.html', 
                         orders=orders,
                         pagination=pagination,
                         search_query=search_query,
                         status_filter=status_filter,
                         statuses=statuses,
                         pending_count=pending_count,
                         processing_count=processing_count,
                         shipped_count=shipped_count,
                         delivered_count=delivered_count,
                         cancelled_count=cancelled_count)

@app.route('/orders/<int:order_id>')
def order_detail(order_id):
    """Order detail page"""
    order = Order.query.get_or_404(order_id)
    items = OrderItem.query.filter_by(order_id=order_id).all()
    
    # Status color mapping for template
    status_colors = {
        'pending': 'warning',
        'processing': 'info', 
        'picking': 'info',
        'picked': 'primary',
        'packing': 'primary',
        'ready_pickup': 'success',
        'shipped': 'success',
        'delivered': 'primary',
        'cancelled': 'danger'
    }
    
    return render_template('order_detail.html', 
                         order=order, 
                         items=items,
                         status_colors=status_colors)

@app.route('/orders/<int:order_id>/update_status', methods=['POST'])
def update_order_status(order_id):
    """Update order status"""
    new_status = request.form.get('status')
    
    if not new_status:
        flash('Status is required', 'error')
        return redirect(url_for('order_detail', order_id=order_id))
    
    order = Order.query.get_or_404(order_id)
    order.status = new_status
    order.updated_at = datetime.utcnow()
    
    try:
        db.session.commit()
        flash('Order status updated successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Failed to update order status', 'error')
        logging.error(f"Error updating order status: {str(e)}")
    
    return redirect(url_for('order_detail', order_id=order_id))

@app.route('/shopee-setup')
@login_required
def shopee_setup():
    """Shopee API setup and configuration page"""
    # Try real API first, fallback to mock if needed
    api_mode = "real"
    try:
        from shopee_api import ShopeeAPI
        shopee_api = ShopeeAPI()
        connection_test = shopee_api.test_connection()
        auth_url = shopee_api.get_auth_url()
        
        # Check if real API has access token - if not, show as needing authorization
        if not connection_test.get('success') and 'Access token' in connection_test.get('message', ''):
            # Real API is valid but needs authorization
            connection_test['needs_auth'] = True
            
    except Exception as e:
        logging.warning(f"Real Shopee API failed: {str(e)}. Using mock API for development.")
        # Fallback to mock API
        try:
            from mock_shopee_api import MockShopeeAPI
            shopee_api = MockShopeeAPI()
            connection_test = shopee_api.test_connection()
            auth_url = shopee_api.get_auth_url()
            api_mode = "mock"
        except Exception as mock_e:
            logging.error(f"Even mock API failed: {str(mock_e)}")
            connection_test = {'success': False, 'message': f'API initialization failed: {str(mock_e)}'}
            auth_url = "#"
            api_mode = "error"
    
    return render_template('shopee_setup.html', 
                         connection_test=connection_test,
                         partner_id=shopee_api.partner_id,
                         has_api_key=bool(shopee_api.api_key),
                         shop_id=shopee_api.shop_id,
                         access_token=shopee_api.access_token,
                         auth_url=auth_url,
                         api_mode=api_mode)

@app.route('/shopee-setup', methods=['POST'])
def shopee_setup_save():
    """Save Shopee API credentials manually"""
    shop_id = request.form.get('shop_id', '').strip()
    access_token = request.form.get('access_token', '').strip()
    
    if not shop_id or not access_token:
        flash('Shop ID dan Access Token diperlukan', 'error')
        return redirect(url_for('shopee_setup'))
    
    # Test with provided credentials
    from shopee_api import ShopeeAPI
    shopee_api = ShopeeAPI()
    
    # Temporarily set credentials for testing
    original_shop_id = shopee_api.shop_id
    original_access_token = shopee_api.access_token
    
    shopee_api.shop_id = shop_id
    shopee_api.access_token = access_token
    
    # Test connection
    test_result = shopee_api.test_connection()
    
    if test_result.get('success'):
        flash('Kredensial berhasil disimpan dan ditest!', 'success')
        # Note: In real app, save to environment or database
        flash('Untuk produksi, simpan SHOPEE_SHOP_ID dan SHOPEE_ACCESS_TOKEN sebagai environment variables', 'info')
    else:
        flash(f'Test gagal: {test_result.get("message")}', 'error')
        # Restore original values
        shopee_api.shop_id = original_shop_id
        shopee_api.access_token = original_access_token
    
    return redirect(url_for('shopee_setup'))

@app.route('/shopee-callback')
def shopee_callback():
    """Handle Shopee authorization callback"""
    # Log all callback parameters for debugging
    all_params = dict(request.args)
    logging.info(f"🔍 Shopee callback received all parameters: {all_params}")
    
    code = request.args.get('code')
    shop_id = request.args.get('shop_id')
    partner_id = request.args.get('partner_id')
    error = request.args.get('error')
    
    # Handle error case
    if error:
        logging.error(f"❌ Authorization error from Shopee: {error}")
        flash(f'Authorization gagal: {error}', 'error')
        return redirect(url_for('shopee_setup'))
    
    # Check required parameters
    if not code:
        logging.error("❌ No authorization code received from Shopee")
        flash('Authorization gagal: kode authorization tidak ditemukan', 'error')
        return redirect(url_for('shopee_setup'))
    
    # Use partner_id from callback or default to configured partner_id
    if not partner_id:
        from shopee_api import ShopeeAPI
        shopee_api = ShopeeAPI()
        partner_id = shopee_api.partner_id
        logging.info(f"✅ Using configured partner_id: {partner_id}")
    
    # Use shop_id from callback or default to configured shop_id
    if not shop_id:
        from shopee_api import ShopeeAPI
        shopee_api = ShopeeAPI()
        shop_id = shopee_api.shop_id
        logging.info(f"✅ Using configured shop_id: {shop_id}")
    
    from shopee_api import ShopeeAPI
    shopee_api = ShopeeAPI()
    
    logging.info(f"🔄 Attempting to get access token with code: {code[:10]}... and shop_id: {shop_id}")
    
    # Get access token using authorization code
    result = shopee_api.get_access_token_from_code(code, shop_id)
    
    if result.get('success'):
        access_token = result.get('access_token')
        logging.info(f"✅ Authorization successful! Access token: {access_token[:20]}...")
        flash(f'Authorization berhasil! Access token: {access_token[:20]}...', 'success')
        flash('Silakan simpan access token ini sebagai SHOPEE_ACCESS_TOKEN environment variable', 'info')
        
        # Save access token to environment for this session
        shopee_api.access_token = access_token
        
    else:
        error_msg = result.get("error", "Unknown error")
        logging.error(f"❌ Authorization failed: {error_msg}")
        
        # Handle IP whitelist error specifically
        if "source_ip_undeclared" in error_msg or "IP Address" in error_msg:
            flash('IP address belum terdaftar di Shopee Developer Console. Server menggunakan multiple IP addresses yang berubah-ubah.', 'error')
            flash('Silakan gunakan Mock API untuk sementara - klik tombol "Use Mock API" di bawah', 'warning')
        else:
            flash(f'Authorization gagal: {error_msg}', 'error')
    
    return redirect(url_for('shopee_setup'))

@app.route('/shopee-auth')
@login_required
def shopee_auth():
    """Generate authorization URL for Shopee"""
    try:
        from shopee_api import ShopeeAPI
        shopee_api = ShopeeAPI()
        auth_url = shopee_api.get_auth_url()
        return redirect(auth_url)
    except Exception as e:
        flash(f'Failed to generate authorization URL: {str(e)}', 'error')
        return redirect(url_for('shopee_setup'))

@app.route('/shopee-simulate-auth', methods=['POST'])
@login_required
def shopee_simulate_auth():
    """Simulate authorization process for development"""
    try:
        from shopee_auth_helper import simulate_authorization_process
        result = simulate_authorization_process()
        
        if result.get('success'):
            flash('Authorization simulasi berhasil! Sistem siap untuk sync orders.', 'success')
            flash('Mode: Development - menggunakan sample data untuk testing', 'info')
        else:
            flash(f'Authorization simulasi gagal: {result.get("message")}', 'error')
            
    except Exception as e:
        logging.error(f"Error in simulate auth: {str(e)}")
        flash(f'Error dalam simulasi authorization: {str(e)}', 'error')
        
    return redirect(url_for('shopee_setup'))

@app.route('/shopee-test-connection', methods=['POST'])
@login_required
def shopee_test_connection():
    """Test Shopee API connection"""
    try:
        # Try real API first, fallback to mock for development
        try:
            from shopee_api import ShopeeAPI
            shopee_api = ShopeeAPI()
            connection_test = shopee_api.test_connection()
            
            # If real API doesn't have access token, use mock for demo
            if not connection_test.get('success') and 'Access token' in connection_test.get('message', ''):
                raise Exception("Real API needs authorization, using mock for demo")
                
            api_mode = "real"
            
        except Exception as e:
            logging.warning(f"Real Shopee API failed: {str(e)}. Using mock API for demo.")
            from mock_shopee_api import MockShopeeAPI
            shopee_api = MockShopeeAPI()
            connection_test = shopee_api.test_connection()
            api_mode = "mock"
        
        return jsonify({
            'success': connection_test.get('success', False),
            'shop_id': connection_test.get('shop_id'),
            'message': connection_test.get('message', 'Unknown error'),
            'error': connection_test.get('error'),
            'api_mode': api_mode
        })
        
    except Exception as e:
        logging.error(f"Failed to test connection: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/sync_shopee_orders', methods=['POST'])
def sync_shopee_orders():
    """Redirect to orders page - no sync needed"""
    flash('Sistem menggunakan data yang sudah ada. Tidak perlu sync.', 'info')
    return redirect(url_for('orders'))

@app.route('/warehouse')
@login_required
def warehouse():
    """Warehouse inventory management page"""
    search_query = request.args.get('search', '')
    low_stock_only = request.args.get('low_stock') == 'true'
    
    query = Product.query
    
    # Apply filters
    if search_query:
        query = query.filter(
            (Product.name.ilike(f'%{search_query}%')) |
            (Product.sku.ilike(f'%{search_query}%'))
        )
    
    if low_stock_only:
        query = query.filter(Product.quantity <= Product.minimum_stock)
    
    # Sort by name
    all_inventory = query.order_by(Product.name).all()
    
    return render_template('warehouse.html', 
                         inventory=all_inventory,
                         search_query=search_query,
                         low_stock_only=low_stock_only)

@app.route('/warehouse/add', methods=['GET', 'POST'])
def add_inventory():
    """Add new inventory item"""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        sku = request.form.get('sku', '').strip()
        quantity = request.form.get('quantity', type=int)
        price = request.form.get('price', type=float)
        minimum_stock = request.form.get('minimum_stock', type=int, default=10)
        image_url = request.form.get('image_url', '').strip()
        
        # Handle image upload - both file upload and data URL
        if image_url and image_url.startswith('data:image'):
            # If it's a data URL (base64), keep it as is
            pass
        elif 'image_upload' in request.files:
            file = request.files['image_upload']
            if file and file.filename != '':
                # Save uploaded file
                import os
                import uuid
                
                # Create uploads directory if it doesn't exist
                upload_dir = os.path.join('static', 'uploads')
                if not os.path.exists(upload_dir):
                    os.makedirs(upload_dir)
                
                # Generate unique filename
                file_extension = os.path.splitext(file.filename)[1].lower()
                unique_filename = f"{uuid.uuid4()}{file_extension}"
                file_path = os.path.join(upload_dir, unique_filename)
                
                # Save file
                file.save(file_path)
                
                # Update image_url to point to saved file
                image_url = f"/static/uploads/{unique_filename}"
        
        # Validation
        if not name or not sku:
            flash('Name and SKU are required', 'error')
            return render_template('inventory_form.html', 
                                 form_data=request.form,
                                 action='Add')
        
        if quantity is None or quantity < 0:
            flash('Valid quantity is required', 'error')
            return render_template('inventory_form.html', 
                                 form_data=request.form,
                                 action='Add')
        
        if price is None or price < 0:
            flash('Valid price is required', 'error')
            return render_template('inventory_form.html', 
                                 form_data=request.form,
                                 action='Add')
        
        try:
            # Check if SKU already exists
            existing_product = Product.query.filter_by(sku=sku).first()
            if existing_product:
                flash('SKU already exists', 'error')
                return render_template('inventory_form.html', 
                                     form_data=request.form,
                                     action='Add')
            
            # Create new product
            new_product = Product(
                name=name,
                sku=sku,
                quantity=quantity,
                price=price,
                minimum_stock=minimum_stock,
                image_url=image_url if image_url else None
            )
            db.session.add(new_product)
            db.session.commit()
            
            flash('Inventory item added successfully', 'success')
            return redirect(url_for('warehouse'))
        except Exception as e:
            db.session.rollback()
            logging.error(f"Failed to add inventory item: {str(e)}")
            flash('Failed to add inventory item', 'error')
    
    return render_template('inventory_form.html', action='Add')

@app.route('/warehouse/import', methods=['GET', 'POST'])
def import_inventory():
    """Import inventory from CSV file with JSON response for progress tracking"""
    if request.method == 'POST':
        uploaded_files = request.files.getlist('inventory_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'No files selected'})
        
        # Process single file for progress tracking
        file = uploaded_files[0]
        
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No file selected'})
            
        if not file.filename.lower().endswith(('.csv', '.xlsx', '.xls')):
            return jsonify({'success': False, 'message': f'Invalid file format: {file.filename}. Please use CSV or Excel files.'})
        
        try:
            # Read file based on extension
            if file.filename.lower().endswith('.csv'):
                stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
                csv_input = csv.DictReader(stream)
            else:
                # Handle Excel files
                try:
                    import pandas as pd
                    df = pd.read_excel(file)
                    csv_input = df.to_dict('records')
                except ImportError:
                    return jsonify({'success': False, 'message': 'Excel support not available. Please use CSV files.'})
            
            success_count = 0
            skipped_count = 0
            error_count = 0
            errors = []
            
            # Process each row
            for row_num, row in enumerate(csv_input, start=2):
                try:
                    # Clean and validate data
                    name = str(row.get('name', '')).strip()
                    sku = str(row.get('sku', '')).strip()
                    quantity = int(row.get('quantity', 0))
                    price = float(row.get('price', 0))
                    minimum_stock = int(row.get('minimum_stock', 10))
                    image_url = str(row.get('image_url', '')).strip()
                    
                    # Validate required fields
                    if not name or not sku:
                        raise ValueError('Name and SKU are required')
                    
                    if quantity < 0:
                        raise ValueError('Quantity cannot be negative')
                    
                    if price < 0:
                        raise ValueError('Price cannot be negative')
                    
                    # Price conversion for large values (compatibility with old data)
                    if price > 1000000:
                        price = price / 1000
                    
                    # Check for duplicate SKU
                    existing_product = Product.query.filter_by(sku=sku).first()
                    if existing_product:
                        # Update existing product
                        existing_product.name = name
                        existing_product.quantity = quantity
                        existing_product.price = price
                        existing_product.minimum_stock = minimum_stock
                        existing_product.image_url = image_url if image_url else None
                        existing_product.updated_at = datetime.utcnow()
                        skipped_count += 1
                    else:
                        # Create new product
                        new_product = Product(
                            sku=sku,
                            name=name,
                            quantity=quantity,
                            price=price,
                            minimum_stock=minimum_stock,
                            image_url=image_url if image_url else None
                        )
                        db.session.add(new_product)
                        db.session.flush()  # Check for unique constraint before commit
                        success_count += 1
                    
                    # Commit in batches to avoid timeout
                    if (success_count + skipped_count) % 5 == 0:
                        try:
                            db.session.commit()
                            logging.info(f"Successfully committed batch for {file.filename}")
                        except Exception as e:
                            logging.error(f"Error committing batch: {str(e)}")
                            db.session.rollback()
                            raise e
                    
                except ValueError as e:
                    errors.append(f'Row {row_num}: Invalid data format - {str(e)}')
                    error_count += 1
                except Exception as e:
                    errors.append(f'Row {row_num}: {str(e)}')
                    error_count += 1
            
            # Final commit for remaining items
            try:
                db.session.commit()
                logging.info(f"Final commit completed for {file.filename}")
            except Exception as e:
                logging.error(f"Error in final commit: {str(e)}")
                db.session.rollback()
                return jsonify({'success': False, 'message': f'Error saving final batch: {str(e)}'})
            
            # Return JSON response for progress tracking
            return jsonify({
                'success': True,
                'imported_count': success_count,
                'skipped_count': skipped_count,
                'error_count': error_count,
                'message': f'Successfully processed {file.filename}: {success_count} imported, {skipped_count} updated, {error_count} errors',
                'errors': errors[:5]  # Return first 5 errors only
            })
            
        except Exception as e:
            logging.error(f"Failed to process file {file.filename}: {str(e)}")
            return jsonify({'success': False, 'message': f'Failed to process {file.filename}: {str(e)}'})
    
    return render_template('mass_upload_inventory.html')

@app.route('/warehouse/mass_upload', methods=['GET', 'POST'])
def mass_upload_inventory():
    """Mass upload inventory items from CSV file"""
    if request.method == 'POST':
        if 'csv_file' not in request.files:
            flash('No file selected', 'error')
            return redirect(url_for('mass_upload_inventory'))
        
        file = request.files['csv_file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(url_for('mass_upload_inventory'))
        
        if not file.filename.lower().endswith('.csv'):
            flash('Please upload a CSV file', 'error')
            return redirect(url_for('mass_upload_inventory'))
        
        try:
            import csv
            import io
            
            # Read CSV file
            stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
            csv_reader = csv.DictReader(stream)
            
            # Validate required columns
            required_columns = ['name', 'sku', 'quantity', 'price']
            if not all(col in csv_reader.fieldnames for col in required_columns):
                flash(f'CSV must contain columns: {", ".join(required_columns)}', 'error')
                return redirect(url_for('mass_upload_inventory'))
            
            # Process rows
            success_count = 0
            error_count = 0
            errors = []
            
            for row_num, row in enumerate(csv_reader, start=2):  # Start from 2 (accounting for header)
                try:
                    name = row['name'].strip()
                    sku = row['sku'].strip()
                    quantity = int(row['quantity'])
                    price = float(row['price'])
                    minimum_stock = int(row.get('minimum_stock', 10))
                    
                    # Handle large prices (divide by 1000 if > 1000000)
                    if price > 1000000:
                        price = price / 1000
                    
                    # Validation
                    if not name or not sku:
                        errors.append(f'Row {row_num}: Name and SKU are required')
                        error_count += 1
                        continue
                    
                    if quantity < 0:
                        errors.append(f'Row {row_num}: Quantity cannot be negative')
                        error_count += 1
                        continue
                    
                    if price < 0:
                        errors.append(f'Row {row_num}: Price cannot be negative')
                        error_count += 1
                        continue
                    
                    # Create new product with unique SKU handling
                    try:
                        new_product = Product(
                            sku=sku,
                            name=name,
                            quantity=quantity,
                            price=price,
                            minimum_stock=minimum_stock
                        )
                        db.session.add(new_product)
                        db.session.flush()  # Check for unique constraint before commit
                    except Exception as e:
                        try:
                            db.session.rollback()
                        except:
                            pass
                        # Skip duplicate SKUs
                        logging.warning(f"Skipping duplicate SKU {sku}: {str(e)}")
                        continue
                    
                    success_count += 1
                    
                    # Commit in smaller batches for concurrent uploads
                    if success_count % 5 == 0:
                        try:
                            db.session.commit()
                            logging.info(f"Successfully committed batch of {success_count} products")
                        except Exception as e:
                            logging.error(f"Error committing batch: {str(e)}")
                            try:
                                db.session.rollback()
                                db.session.close()
                                db.session = db.scoped_session()
                            except:
                                pass
                    
                except ValueError as e:
                    errors.append(f'Row {row_num}: Invalid data format - {str(e)}')
                    error_count += 1
                except Exception as e:
                    errors.append(f'Row {row_num}: {str(e)}')
                    error_count += 1
            
            # Final commit for remaining items
            try:
                db.session.commit()
                logging.info(f"Final commit completed for inventory import")
            except Exception as e:
                logging.error(f"Error in final commit: {str(e)}")
                try:
                    db.session.rollback()
                    db.session.close()
                except:
                    pass
                flash(f'Error saving final batch: {str(e)}', 'error')
            
            # Show results
            if success_count > 0:
                flash(f'Successfully uploaded {success_count} items', 'success')
            
            if error_count > 0:
                flash(f'Failed to upload {error_count} items', 'error')
                # Show first 5 errors
                for error in errors[:5]:
                    flash(error, 'error')
                if len(errors) > 5:
                    flash(f'... and {len(errors) - 5} more errors', 'error')
            
            if success_count > 0:
                return redirect(url_for('warehouse'))
            
        except Exception as e:
            logging.error(f"Failed to process CSV file: {str(e)}")
            flash('Failed to process CSV file', 'error')
    
    return render_template('mass_upload_form.html')

@app.route('/warehouse/download_csv_template')
def download_csv_template():
    """Download CSV template for mass upload"""
    from flask import Response
    import csv
    import io
    
    # Create CSV template
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['name', 'sku', 'quantity', 'price', 'minimum_stock', 'image_url'])
    
    # Write example rows
    writer.writerow(['iPhone 14 Pro', 'IPH14PRO128', '50', '15000000', '5', 'https://example.com/iphone14pro.jpg'])
    writer.writerow(['Samsung Galaxy S23', 'SAM-S23-256', '30', '12000000', '3', 'https://example.com/galaxy-s23.jpg'])
    writer.writerow(['MacBook Air M2', 'MBA-M2-256', '10', '18000000', '2', 'https://example.com/macbook-air-m2.jpg'])
    
    # Create response
    response = Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=inventory_template.csv'}
    )
    
    return response

@app.route('/warehouse/<product_id>/edit', methods=['GET', 'POST'])
def edit_inventory(product_id):
    """Edit inventory item"""
    item = models.get_inventory_item(product_id)
    if not item:
        flash('Inventory item not found', 'error')
        return redirect(url_for('warehouse'))
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        sku = request.form.get('sku', '').strip()
        quantity = request.form.get('quantity', type=int)
        price = request.form.get('price', type=float)
        minimum_stock = request.form.get('minimum_stock', type=int, default=10)
        
        # Validation
        if not name or not sku:
            flash('Name and SKU are required', 'error')
            return render_template('inventory_form.html', 
                                 item=item,
                                 form_data=request.form,
                                 action='Edit')
        
        if quantity is None or quantity < 0:
            flash('Valid quantity is required', 'error')
            return render_template('inventory_form.html', 
                                 item=item,
                                 form_data=request.form,
                                 action='Edit')
        
        if price is None or price < 0:
            flash('Valid price is required', 'error')
            return render_template('inventory_form.html', 
                                 item=item,
                                 form_data=request.form,
                                 action='Edit')
        
        try:
            # Update item
            models.inventory[product_id].update({
                'name': name,
                'sku': sku,
                'quantity': quantity,
                'price': price,
                'minimum_stock': minimum_stock,
                'is_low_stock': quantity <= minimum_stock,
                'updated_at': models.datetime.now().isoformat()
            })
            flash('Inventory item updated successfully', 'success')
            return redirect(url_for('warehouse'))
        except Exception as e:
            logging.error(f"Failed to update inventory item: {str(e)}")
            flash('Failed to update inventory item', 'error')
    
    return render_template('inventory_form.html', item=item, action='Edit')

@app.route('/warehouse/<product_id>/delete', methods=['POST'])
def delete_inventory(product_id):
    """Delete inventory item"""
    try:
        product = Product.query.get(product_id)
        if product:
            db.session.delete(product)
            db.session.commit()
            flash('Inventory item deleted successfully', 'success')
        else:
            flash('Product not found', 'error')
    except Exception as e:
        db.session.rollback()
        logging.error(f"Failed to delete product {product_id}: {str(e)}")
        flash('Failed to delete inventory item', 'error')
    
    return redirect(url_for('warehouse'))

@app.route('/warehouse/delete_multiple', methods=['POST'])
def delete_multiple_inventory():
    """Delete multiple inventory items"""
    selected_products = request.form.getlist('selected_products[]')
    
    if not selected_products:
        flash('No products selected for deletion', 'error')
        return redirect(url_for('warehouse'))
    
    success_count = 0
    error_count = 0
    
    for product_id in selected_products:
        try:
            product = Product.query.get(product_id)
            if product:
                db.session.delete(product)
                db.session.commit()
                success_count += 1
            else:
                error_count += 1
        except Exception as e:
            db.session.rollback()
            logging.error(f"Failed to delete product {product_id}: {str(e)}")
            error_count += 1
    
    if success_count > 0:
        flash(f'{success_count} produk berhasil dihapus', 'success')
    
    if error_count > 0:
        flash(f'{error_count} produk gagal dihapus', 'error')
    
    return redirect(url_for('warehouse'))

@app.route('/warehouse/<product_id>/adjust_quantity', methods=['POST'])
def adjust_inventory_quantity(product_id):
    """Adjust inventory quantity"""
    new_quantity = request.form.get('quantity', type=int)
    
    if new_quantity is None or new_quantity < 0:
        flash('Valid quantity is required', 'error')
        return redirect(url_for('warehouse'))
    
    if models.update_inventory_quantity(product_id, new_quantity):
        flash('Inventory quantity updated successfully', 'success')
    else:
        flash('Failed to update inventory quantity', 'error')
    
    return redirect(url_for('warehouse'))

@app.route('/clear-all-data', methods=['POST'])
@login_required
def clear_all_data():
    """Clear all order data for fresh import"""
    try:
        # Clear in correct order due to foreign key constraints
        ScanHistory.query.delete()
        StockMovement.query.delete()
        PickingSession.query.delete()
        OrderItem.query.delete()
        Order.query.delete()
        
        db.session.commit()
        
        logging.info("All order data cleared successfully")
        return jsonify({'success': True, 'message': 'Semua data pesanan berhasil dihapus'})
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error clearing data: {str(e)}")
        return jsonify({'success': False, 'message': f'Gagal menghapus data: {str(e)}'})

# Order Import Routes
@app.route('/orders/import_old', methods=['GET', 'POST'])
def import_orders_old():
    """Import with progress interface"""
    if request.method == 'POST':
        # Handle AJAX file upload
        uploaded_files = request.files.getlist('order_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'Tidak ada file yang dipilih'})
        
        # Process all uploaded files
        total_imported = 0
        total_skipped = 0
        total_errors = 0
        results = []
        
        for file in uploaded_files:
            if file.filename == '':
                continue
            
        # Check file extension
        if not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'success': False, 'message': 'Format file tidak valid. Gunakan .xlsx atau .xls'})
        
        try:
            # Save file temporarily
            import tempfile
            import os
            
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, file.filename)
            file.save(temp_file_path)
            
            # Import using bulk import function that works
            from bulk_import_final import bulk_import_single_file
            logging.info(f"Starting bulk import for file: {file.filename}")
            result = bulk_import_single_file(temp_file_path)
            logging.info(f"Bulk import result: {result}")
            
            # Clean up temp file
            os.remove(temp_file_path)
            
            if isinstance(result, dict) and result.get('success'):
                return jsonify({
                    'success': True,
                    'imported_count': result['imported_count'],
                    'skipped_count': result.get('skipped_count', 0),
                    'message': f'Berhasil import {result["imported_count"]} pesanan dari {file.filename}'
                })
            else:
                error_msg = result.get('message', 'unknown error') if isinstance(result, dict) else str(result)
                return jsonify({
                    'success': False,
                    'imported_count': 0,
                    'message': f'Error: {error_msg}'
                })
                
        except Exception as e:
            logging.error(f"Error processing file {file.filename}: {str(e)}")
            import traceback
            error_details = traceback.format_exc()
            logging.error(f"Full traceback: {error_details}")
            return jsonify({
                'success': False,
                'imported_count': 0,
                'message': f'Error processing file: {str(e)}',
                'error_details': error_details
            })
    
    return render_template('import_orders_progress.html')

@app.route('/orders/import', methods=['GET', 'POST'])
def import_orders():
    """Import with progress interface - simplified version"""
    if request.method == 'POST':
        uploaded_files = request.files.getlist('order_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'Tidak ada file yang dipilih'})
        
        file = uploaded_files[0]
        
        if file.filename == '' or not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'success': False, 'message': 'Format file tidak valid'})
        
        try:
            import tempfile
            import os
            
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, file.filename)
            file.save(temp_file_path)
            
            from bulk_import_final import bulk_import_single_file
            result = bulk_import_single_file(temp_file_path)
            
            os.remove(temp_file_path)
            
            if result.get('success'):
                return jsonify({
                    'success': True,
                    'imported_count': result['imported_count'],
                    'skipped_count': result.get('skipped_count', 0),
                    'message': f'Import berhasil: {result["imported_count"]} pesanan'
                })
            else:
                return jsonify({
                    'success': False,
                    'imported_count': 0,
                    'message': 'Import gagal'
                })
                
        except Exception as e:
            return jsonify({
                'success': False,
                'imported_count': 0,
                'message': f'Error: {str(e)}'
            })
    
    return render_template('import_orders_progress.html')

def process_order_data(data):
    """Process imported order data from Shopee format - handles multiple products per order"""
    import re
    import time
    from collections import defaultdict
    
    imported_count = 0
    
    # Check if data is empty
    if data is None or (hasattr(data, 'empty') and data.empty) or (hasattr(data, '__len__') and len(data) == 0):
        logging.warning("No data provided to process_order_data")
        return 0
        
    logging.info(f"Starting to process order data")
    
    # Ensure database connection is fresh for large imports
    try:
        # Refresh database connection to avoid timeout issues
        db.session.close()
        db.engine.dispose()
        
        logging.info("Database connection refreshed for large import")
    except Exception as db_init_error:
        logging.error(f"Error refreshing database connection: {str(db_init_error)}")
        # Continue anyway, don't stop the process
        pass
    
    # Use direct import approach
    try:
        # Convert pandas DataFrame to list of dicts if needed
        if hasattr(data, 'to_dict'):
            data = data.to_dict('records')
        
        # Group records by order_sn
        orders_dict = defaultdict(list)
        for record in data:
            order_sn = str(record.get('order_sn', '')).strip()
            if order_sn and order_sn != 'nan' and order_sn.lower() != 'none':
                orders_dict[order_sn].append(record)
        
        logging.info(f"Processing {len(orders_dict)} unique orders from {len(data)} records")
        
        # Get existing orders once
        existing_orders = set()
        try:
            existing_orders = {order.order_number for order in Order.query.all()}
        except Exception as e:
            logging.error(f"Error getting existing orders: {e}")
            existing_orders = set()
        
        # Process orders one by one with individual commits
        imported_count = 0
        for order_number, order_rows in orders_dict.items():
            if order_number in existing_orders:
                logging.info(f"Order {order_number} already exists, skipping")
                continue
                
            try:
                # Process single order using enhanced approach
                if import_single_order_safe(order_number, order_rows):
                    imported_count += 1
                    existing_orders.add(order_number)
                    
                    if imported_count % 10 == 0:
                        logging.info(f"Imported {imported_count} orders so far...")
                        
            except Exception as e:
                logging.error(f"Error processing order {order_number}: {str(e)}")
                continue
        
        logging.info(f"Total imported: {imported_count} orders")
        return imported_count
        
    except Exception as e:
        logging.error(f"Error in process_order_data: {str(e)}")
        return 0

def import_single_order_safe(order_number, order_rows):
    """Import a single order with individual transaction - enhanced version"""
    import re
    try:
        first_row = order_rows[0]
        
        # Extract customer info
        customer_name = str(first_row.get('order_receiver_name', '') or 
                          first_row.get('buyer_user_name', '') or 
                          'Unknown Customer').strip()
        
        tracking_number = str(first_row.get('tracking_number', '')).strip()
        if tracking_number == 'nan' or not tracking_number:
            tracking_number = None
        else:
            # Check for duplicate tracking number
            try:
                existing_tracking = Order.query.filter_by(tracking_number=tracking_number).first()
                if existing_tracking:
                    logging.warning(f"Duplicate tracking number {tracking_number} found, making unique...")
                    tracking_number = f"{tracking_number}_{order_number}"
            except:
                pass
        
        # Calculate total amount
        total_amount = 0.0
        product_info = str(first_row.get('product_info', ''))
        
        if product_info and product_info != 'nan':
            try:
                price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                
                for i, price_match in enumerate(price_matches):
                    try:
                        price_str = price_match.replace(',', '').replace('.', '')
                        price = float(price_str)
                        quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                        total_amount += price * quantity
                    except:
                        continue
            except:
                pass
        
        # Create order
        new_order = Order(
            order_number=order_number,
            tracking_number=tracking_number,
            customer_name=customer_name,
            customer_phone=None,
            customer_address=None,
            status='pending',
            total_amount=total_amount
        )
        
        db.session.add(new_order)
        db.session.flush()
        
        # Process items
        if product_info and product_info != 'nan':
            lines = product_info.replace('\r\n', '\n').split('\n')
            current_product = {}
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                if re.match(r'^\[\d+\]', line):
                    # Save previous product
                    if current_product.get('name'):
                        order_item = OrderItem(
                            order_id=new_order.id,
                            sku=current_product.get('sku', 'UNKNOWN'),
                            product_name=current_product.get('name', 'Unknown Product'),
                            quantity=current_product.get('quantity', 1),
                            price=current_product.get('price', 0.0)
                        )
                        db.session.add(order_item)
                    
                    # Start new product
                    current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                    
                    # Extract product name
                    if 'Nama Produk:' in line:
                        name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                        if name_match:
                            product_name = name_match.group(1).strip()
                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                            current_product['name'] = product_name
                    
                    # Extract price
                    price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                    if price_match:
                        try:
                            price_str = price_match.group(1).replace(',', '').replace('.', '')
                            current_product['price'] = float(price_str)
                        except:
                            pass
                    
                    # Extract quantity
                    qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                    if qty_match:
                        try:
                            current_product['quantity'] = int(qty_match.group(1))
                        except:
                            pass
            
            # Save last product
            if current_product.get('name'):
                order_item = OrderItem(
                    order_id=new_order.id,
                    sku=current_product.get('sku', 'UNKNOWN'),
                    product_name=current_product.get('name', 'Unknown Product'),
                    quantity=current_product.get('quantity', 1),
                    price=current_product.get('price', 0.0)
                )
                db.session.add(order_item)
        
        # Commit individual order
        db.session.commit()
        return True
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error processing order {order_number}: {str(e)}")
        return False
    
    # Convert DataFrame to list of dictionaries if needed
    if hasattr(data, 'iterrows'):  # DataFrame
        data = [row.to_dict() for _, row in data.iterrows()]
    elif hasattr(data, '__iter__') and not isinstance(data, (list, tuple)):
        data = list(data)
    
    # Group rows by order_sn to handle multiple products per order
    orders_dict = defaultdict(list)
    row_count = 0
    for row in data:
        row_count += 1
        if not isinstance(row, dict):
            continue
        # Check both original column name and mapped column name
        order_sn = str(row.get('order_sn', '') or row.get('No. Pesanan', '') or '').strip()
        if order_sn and order_sn != 'nan' and order_sn != '':
            orders_dict[order_sn].append(row)
        else:
            # Debug: log what keys are available
            logging.debug(f"Row keys: {list(row.keys())}, values: {[str(v)[:20] for v in row.values()]}")
    
    logging.info(f"Found {len(orders_dict)} unique orders from {row_count} rows")
    
    # Process each unique order with batch commit for efficiency
    batch_size = 5  # Smaller batch for better stability
    processed_in_batch = 0
    
    for order_number, order_rows in orders_dict.items():
        try:
            # Use the first row for order-level information (they should be the same for all rows of same order)
            first_row = order_rows[0]
            
            # Extract order information from first row
            tracking_number = str(first_row.get('tracking_number', '') or first_row.get('No. Resi', '') or '').strip()
            if tracking_number == 'nan' or not tracking_number:
                tracking_number = None
            
            # Check if order already exists (skip duplicates) with connection retry
            try:
                existing_order = Order.query.filter_by(order_number=order_number).first()
                if existing_order:
                    logging.warning(f"Order with order number {order_number} already exists, skipping...")
                    continue
            except Exception as db_error:
                # Database connection issue, try to refresh and retry
                logging.error(f"Database error checking existing order: {str(db_error)}")
                try:
                    db.session.rollback()
                    db.session.close()
                    db.engine.dispose()
                    existing_order = Order.query.filter_by(order_number=order_number).first()
                    if existing_order:
                        logging.warning(f"Order with order number {order_number} already exists, skipping...")
                        continue
                except Exception as retry_error:
                    logging.error(f"Failed to retry database connection: {str(retry_error)}")
                    # Skip this order and continue
                    continue
                
            customer_name = str(first_row.get('order_receiver_name', '') or first_row.get('buyer_user_name', '') or first_row.get('Username Pembeli', '') or first_row.get('Nama Penerima', '') or '').strip()
            if not customer_name or customer_name == 'nan':
                customer_name = 'Unknown Customer'
                
            customer_phone = str(first_row.get('phone', '') or first_row.get('No. Telepon', '') or '').strip()
            if customer_phone == 'nan' or not customer_phone:
                customer_phone = None
                
            customer_address = str(first_row.get('address', '') or first_row.get('Alamat Pengiriman', '') or '').strip()
            if customer_address == 'nan' or not customer_address:
                customer_address = None
            
            # Calculate total amount from all products in this order
            total_amount = 0.0
            for row in order_rows:
                product_info = str(row.get('product_info', '') or row.get('Info Produk', '') or '').strip()
                if product_info and product_info != 'nan':
                    try:
                        # Extract price and quantity for each product
                        # Look for pattern like "Harga: Rp 35,000" or "Harga: Rp 35.000"
                        price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                        qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                        
                        logging.debug(f"Order {order_number}: Found {len(price_matches)} prices, {len(qty_matches)} quantities")
                        
                        for i, price_match in enumerate(price_matches):
                            try:
                                # Handle both comma and dot as thousand separators
                                price_str = price_match.replace(',', '').replace('.', '')
                                # If price is less than 1000, it might be in hundreds
                                if len(price_str) <= 3:
                                    price = float(price_str) * 1000  # Convert hundreds to full amount
                                else:
                                    price = float(price_str)
                                
                                quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                                item_total = price * quantity
                                total_amount += item_total
                                logging.debug(f"Item {i+1}: Rp {price} x {quantity} = Rp {item_total}")
                            except (ValueError, IndexError) as ve:
                                logging.warning(f"Error parsing price/qty {i}: {str(ve)}")
                                continue
                    except Exception as item_e:
                        logging.warning(f"Error processing product info for order {order_number}: {str(item_e)}")
            
            # Create new order with error handling
            try:
                # Validate required fields
                if not order_number or not customer_name:
                    logging.warning(f"Missing required fields for order: {order_number}")
                    continue
                    
                # Clean and validate text fields to prevent encoding issues
                def clean_text(text):
                    if not text or text == 'nan':
                        return None
                    try:
                        # Convert to string and handle encoding
                        text_str = str(text)
                        # Remove non-printable characters and ensure UTF-8 compatibility
                        text_str = ''.join(char for char in text_str if char.isprintable() or char.isspace())
                        # Truncate if too long
                        if len(text_str) > 500:
                            text_str = text_str[:500]
                        return text_str.strip()
                    except Exception as e:
                        logging.warning(f"Error cleaning text '{text}': {str(e)}")
                        return None
                
                # Clean all text fields
                customer_name = clean_text(customer_name) or 'Unknown Customer'
                customer_phone = clean_text(customer_phone)
                customer_address = clean_text(customer_address)
                tracking_number = clean_text(tracking_number)
                
                new_order = Order(
                    order_number=order_number,
                    tracking_number=tracking_number,
                    customer_name=customer_name,
                    customer_phone=customer_phone,
                    customer_address=customer_address,
                    total_amount=total_amount,
                    status='pending'
                )
                
                db.session.add(new_order)
                db.session.flush()  # Get the order ID
                
                # Add order items
                for row in order_rows:
                    product_info = str(row.get('product_info', '') or row.get('Info Produk', '') or '').strip()
                    if product_info and product_info != 'nan':
                        try:
                            # Parse product info for individual products
                            # Split by lines to handle multiple products
                            lines = product_info.replace('\r\n', '\n').split('\n')
                            current_product = {}
                            
                            for line in lines:
                                line = line.strip()
                                if not line:
                                    continue
                                
                                # Check if this is a product line (starts with [number])
                                if re.match(r'^\[\d+\]', line):
                                    # Save previous product if exists
                                    if current_product.get('name'):
                                        order_item = OrderItem(
                                            order_id=new_order.id,
                                            sku=current_product.get('sku', 'UNKNOWN'),
                                            product_name=current_product.get('name', 'Unknown Product'),
                                            quantity=current_product.get('quantity', 1),
                                            price=current_product.get('price', 0.0)
                                        )
                                        db.session.add(order_item)
                                        imported_count += 1
                                    
                                    # Start new product
                                    current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                                    
                                    # Extract product name from the line
                                    # Look for pattern like "Nama Produk: Product Name;"
                                    if 'Nama Produk:' in line:
                                        name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                                        if name_match:
                                            product_name = name_match.group(1).strip()
                                            # Clean product name
                                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                                            current_product['name'] = clean_text(product_name)
                                    
                                    # Extract price
                                    price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                                    if price_match:
                                        try:
                                            price_str = price_match.group(1).replace(',', '').replace('.', '')
                                            if len(price_str) <= 3:
                                                current_product['price'] = float(price_str) * 1000
                                            else:
                                                current_product['price'] = float(price_str)
                                        except:
                                            pass
                                    
                                    # Extract quantity
                                    qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                                    if qty_match:
                                        try:
                                            current_product['quantity'] = int(qty_match.group(1))
                                        except:
                                            pass
                                    
                                    # Extract SKU if available
                                    sku_match = re.search(r'SKU Induk:\s*([^;]+)', line)
                                    if sku_match:
                                        current_product['sku'] = clean_text(sku_match.group(1))
                            
                            # Save the last product
                            if current_product.get('name'):
                                order_item = OrderItem(
                                    order_id=new_order.id,
                                    sku=current_product.get('sku', 'UNKNOWN'),
                                    product_name=current_product.get('name', 'Unknown Product'),
                                    quantity=current_product.get('quantity', 1),
                                    price=current_product.get('price', 0.0)
                                )
                                db.session.add(order_item)
                                imported_count += 1
                                
                        except Exception as product_error:
                            logging.warning(f"Error processing product info for order {order_number}: {str(product_error)}")
                            continue
                
                # Commit individual order
                db.session.commit()
                imported_count += 1
                processed_in_batch += 1
                logging.info(f"Successfully imported order {order_number}: {customer_name}")
                
                # Check if we should commit batch
                if processed_in_batch >= batch_size:
                    logging.info(f"Batch of {processed_in_batch} orders committed")
                    processed_in_batch = 0
                    
            except Exception as commit_error:
                logging.error(f"Error committing order {order_number}: {str(commit_error)}")
                db.session.rollback()
                continue
                
        except Exception as order_error:
            logging.error(f"Error processing order {order_number}: {str(order_error)}")
            db.session.rollback()
            continue
    
    logging.info(f"Import completed. Total orders processed: {imported_count}")
    return imported_count
    
    # Convert DataFrame to list of dictionaries if needed
    if hasattr(data, 'iterrows'):  # DataFrame
        data = [row.to_dict() for _, row in data.iterrows()]
    elif hasattr(data, '__iter__') and not isinstance(data, (list, tuple)):
        data = list(data)
    
    # Group rows by order_sn to handle multiple products per order
    orders_dict = defaultdict(list)
    row_count = 0
    for row in data:
        row_count += 1
        if not isinstance(row, dict):
            continue
        # Check both original column name and mapped column name
        order_sn = str(row.get('order_sn', '') or row.get('No. Pesanan', '') or '').strip()
        if order_sn and order_sn != 'nan' and order_sn != '':
            orders_dict[order_sn].append(row)
        else:
            # Debug: log what keys are available
            logging.debug(f"Row keys: {list(row.keys())}, values: {[str(v)[:20] for v in row.values()]}")
    
    logging.info(f"Found {len(orders_dict)} unique orders from {row_count} rows")
    
    # Process each unique order with batch commit for efficiency
    batch_size = 5  # Smaller batch for better stability
    processed_in_batch = 0
    
    for order_number, order_rows in orders_dict.items():
        try:
            # Use the first row for order-level information (they should be the same for all rows of same order)
            first_row = order_rows[0]
            
            # Extract order information from first row
            tracking_number = str(first_row.get('tracking_number', '') or first_row.get('No. Resi', '') or '').strip()
            if tracking_number == 'nan' or not tracking_number:
                tracking_number = None
            
            # Check if order already exists (skip duplicates) with connection retry
            try:
                existing_order = Order.query.filter_by(order_number=order_number).first()
                if existing_order:
                    logging.warning(f"Order with order number {order_number} already exists, skipping...")
                    continue
            except Exception as db_error:
                # Database connection issue, try to refresh and retry
                logging.error(f"Database error checking existing order: {str(db_error)}")
                try:
                    db.session.rollback()
                    db.session.close()
                    db.engine.dispose()
                    existing_order = Order.query.filter_by(order_number=order_number).first()
                    if existing_order:
                        logging.warning(f"Order with order number {order_number} already exists, skipping...")
                        continue
                except Exception as retry_error:
                    logging.error(f"Failed to retry database connection: {str(retry_error)}")
                    # Skip this order and continue
                    continue
                
            customer_name = str(first_row.get('order_receiver_name', '') or first_row.get('buyer_user_name', '') or first_row.get('Username Pembeli', '') or first_row.get('Nama Penerima', '') or '').strip()
            if not customer_name or customer_name == 'nan':
                customer_name = 'Unknown Customer'
                
            customer_phone = str(first_row.get('phone', '') or first_row.get('No. Telepon', '') or '').strip()
            if customer_phone == 'nan' or not customer_phone:
                customer_phone = None
                
            customer_address = str(first_row.get('address', '') or first_row.get('Alamat Pengiriman', '') or '').strip()
            if customer_address == 'nan' or not customer_address:
                customer_address = None
            
            # Calculate total amount from all products in this order
            total_amount = 0.0
            for row in order_rows:
                product_info = str(row.get('product_info', '') or row.get('Info Produk', '') or '').strip()
                if product_info and product_info != 'nan':
                    try:
                        # Extract price and quantity for each product
                        # Look for pattern like "Harga: Rp 35,000" or "Harga: Rp 35.000"
                        price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                        qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                        
                        logging.debug(f"Order {order_number}: Found {len(price_matches)} prices, {len(qty_matches)} quantities")
                        
                        for i, price_match in enumerate(price_matches):
                            try:
                                # Handle both comma and dot as thousand separators
                                price_str = price_match.replace(',', '').replace('.', '')
                                # If price is less than 1000, it might be in hundreds
                                if len(price_str) <= 3:
                                    price = float(price_str) * 1000  # Convert hundreds to full amount
                                else:
                                    price = float(price_str)
                                
                                quantity = int(qty_matches[i]) if i < len(qty_matches) else 1
                                item_total = price * quantity
                                total_amount += item_total
                                logging.debug(f"Item {i+1}: Rp {price} x {quantity} = Rp {item_total}")
                            except (ValueError, IndexError) as ve:
                                logging.warning(f"Error parsing price/qty {i}: {str(ve)}")
                                continue
                    except Exception as item_e:
                        logging.warning(f"Error processing product info for order {order_number}: {str(item_e)}")
            
            # Create new order with error handling
            try:
                # Validate required fields
                if not order_number or not customer_name:
                    logging.warning(f"Missing required fields for order: {order_number}")
                    continue
                    
                # Clean and validate text fields to prevent encoding issues
                def clean_text(text):
                    if not text or text == 'nan':
                        return None
                    try:
                        # Convert to string and handle encoding
                        text_str = str(text)
                        # Remove non-printable characters and ensure UTF-8 compatibility
                        cleaned = ''.join(char for char in text_str if char.isprintable() or char.isspace())
                        return cleaned.strip()[:500]  # Limit length
                    except Exception as e:
                        logging.warning(f"Text cleaning error: {str(e)}")
                        return "Invalid Text"
                
                new_order = Order(
                    order_number=clean_text(order_number),
                    tracking_number=clean_text(tracking_number),
                    customer_name=clean_text(customer_name),
                    customer_phone=clean_text(customer_phone),
                    customer_address=clean_text(customer_address),
                    status='pending',
                    total_amount=total_amount
                )
                
                db.session.add(new_order)
                db.session.flush()  # Get the order ID without committing
                
                # Process individual products for this order - each product is on separate line
                product_info = str(order_rows[0].get('product_info', '') or order_rows[0].get('Info Produk', '') or '').strip()
                if product_info and product_info != 'nan':
                    # Split product info by line breaks and process each product separately
                    lines = product_info.replace('\r\n', '\n').split('\n')
                    current_product = {}
                    
                    for line in lines:
                        line = line.strip()
                        if not line:
                            continue
                            
                        # Check if this is start of new product (contains [number])
                        if re.match(r'^\[\d+\]', line):
                            # Save previous product if exists
                            if current_product.get('name'):
                                try:
                                    order_item = OrderItem(
                                        order_id=new_order.id,
                                        sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                                        product_name=clean_text(current_product.get('name', 'Unknown Product')),
                                        quantity=current_product.get('quantity', 1),
                                        price=current_product.get('price', 0.0)
                                    )
                                    db.session.add(order_item)
                                    logging.debug(f"Added product: {current_product.get('name')} (SKU: {current_product.get('sku')}) - Qty: {current_product.get('quantity')} - Price: Rp {current_product.get('price')}")
                                except Exception as item_error:
                                    logging.error(f"Error creating order item: {str(item_error)}")
                            
                            # Start new product
                            current_product = {'name': '', 'sku': 'UNKNOWN', 'price': 0.0, 'quantity': 1}
                            
                            # Extract product name from this line
                            if 'Nama Produk:' in line:
                                name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                                if name_match:
                                    product_name = name_match.group(1).strip()
                                    # Remove [BAYAR DITEMPAT] prefix if present
                                    product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                                    current_product['name'] = product_name
                            
                            # Extract price from this line
                            price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                            if price_match:
                                try:
                                    price_str = price_match.group(1).replace(',', '').replace('.', '')
                                    if len(price_str) <= 3:
                                        current_product['price'] = float(price_str) * 1000
                                    else:
                                        current_product['price'] = float(price_str)
                                except ValueError:
                                    current_product['price'] = 0.0
                            
                            # Extract quantity from this line
                            qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                            if qty_match:
                                try:
                                    current_product['quantity'] = int(qty_match.group(1))
                                except ValueError:
                                    current_product['quantity'] = 1
                            
                            # Extract SKU from this line if present
                            if 'SKU Induk:' in line:
                                sku_match = re.search(r'SKU Induk:\s*(.+?)(?:;|$)', line)
                                if sku_match:
                                    current_product['sku'] = sku_match.group(1).strip()
                            elif 'Nomor Referensi SKU:' in line:
                                sku_match = re.search(r'Nomor Referensi SKU:\s*(.+?)(?:;|$)', line)
                                if sku_match:
                                    current_product['sku'] = sku_match.group(1).strip()
                    
                    # Don't forget to save the last product
                    if current_product.get('name'):
                        try:
                            order_item = OrderItem(
                                order_id=new_order.id,
                                sku=clean_text(current_product.get('sku', 'UNKNOWN')),
                                product_name=clean_text(current_product.get('name', 'Unknown Product')),
                                quantity=current_product.get('quantity', 1),
                                price=current_product.get('price', 0.0)
                            )
                            db.session.add(order_item)
                            logging.debug(f"Added product: {current_product.get('name')} (SKU: {current_product.get('sku')}) - Qty: {current_product.get('quantity')} - Price: Rp {current_product.get('price')}")
                        except Exception as item_error:
                            logging.error(f"Error creating final order item: {str(item_error)}")
                
                # Add to session but don't commit yet (batch processing)
                imported_count += 1
                processed_in_batch += 1
                logging.info(f"Added order to batch: {order_number} with {len(order_rows)} product rows, total: Rp {total_amount}")
                
                # Commit in batches for efficiency
                if processed_in_batch >= batch_size:
                    try:
                        db.session.commit()
                        logging.info(f"Successfully committed batch of {processed_in_batch} orders")
                        processed_in_batch = 0
                        
                    except Exception as batch_error:
                        db.session.rollback()
                        logging.error(f"Batch commit error: {str(batch_error)}")
                        # Try to recover connection and continue
                        try:
                            db.session.close()
                            db.engine.dispose()
                        except:
                            pass
                
            except Exception as db_error:
                db.session.rollback()
                error_msg = str(db_error)
                logging.error(f"Database error for order {order_number}: {error_msg}")
                # Continue processing other orders even if one fails
                continue
                
        except Exception as e:
            logging.error(f"Error processing order {order_number}: {str(e)}")
            # Try to recover from error
            try:
                db.session.rollback()
            except:
                pass
            continue
    
    # Final commit for remaining orders in last batch
    if processed_in_batch > 0:
        try:
            db.session.commit()
            logging.info(f"Successfully committed final batch of {processed_in_batch} orders")
        except Exception as final_error:
            db.session.rollback()
            logging.error(f"Final batch commit error: {str(final_error)}")
            # Try to recover and commit individual orders
            try:
                db.session.close()
                db.engine.dispose()
            except:
                pass
    
    logging.info(f"Import completed. Total orders processed: {imported_count}")
    return imported_count



# Fulfillment Dashboard
@app.route('/fulfillment')
def fulfillment_dashboard():
    """Fulfillment dashboard with order status overview"""
    pending_orders = Order.query.filter_by(status='pending').count()
    picking_orders = Order.query.filter_by(status='picking').count()
    packing_orders = Order.query.filter_by(status='packing').count()
    ready_orders = Order.query.filter_by(status='ready_for_pickup').count()
    
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    stats = {
        'pending': pending_orders,
        'picking': picking_orders,
        'packing': packing_orders,
        'ready': ready_orders,
        'total': pending_orders + picking_orders + packing_orders + ready_orders
    }
    
    return render_template('fulfillment_dashboard.html', stats=stats, recent_orders=recent_orders)

# Barcode Scanning Routes
@app.route('/scan')
def scan_center():
    """Main scanning center"""
    return render_template('scan_center.html')

@app.route('/compact-scanner')
@login_required
def compact_scanner():
    """Compact scanner interface with exact 260x180 camera preview"""
    return render_template('compact_scanner.html')

@app.route('/parsing-data')
@login_required
def parsing_data():
    """Parsing Data Tools page"""
    return render_template('parsing_data.html')

@app.route('/api/get-order-data')
@login_required
def get_order_data():
    """API endpoint to get raw order data for parsing"""
    try:
        # Get all orders with their items
        orders = db.session.query(Order).join(OrderItem).all()
        
        # Extract raw data from orders
        raw_data = []
        for order in orders:
            for item in order.items:
                # Try to find original product_info from the order
                # This would be the raw string data before parsing
                if hasattr(item, 'original_product_info'):
                    raw_data.append(item.original_product_info)
        
        return jsonify({
            'success': True,
            'raw_data': raw_data,
            'total_orders': len(orders)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/get-all-orders-raw')
@login_required
def get_all_orders_raw():
    """Get all orders with raw product info data"""
    try:
        # Query to get orders with their items using proper join
        orders_query = db.session.query(Order, OrderItem).join(OrderItem, Order.id == OrderItem.order_id).all()
        
        orders_data = []
        item_counter = 1
        
        for order, item in orders_query:
            # Create raw product info format similar to the original Excel format
            # Format: [1] Nama Produk:PRODUCT_NAME; Nama Variasi:; Harga: Rp PRICE; Jumlah: QUANTITY; Nomor Referensi SKU: SKU_VALUE; SKU Induk: SKU_VALUE;
            
            # Clean price format
            price_formatted = f"{item.price:,.0f}".replace(',', '.')
            
            # Create realistic raw product info string
            raw_product_info = f"[{item_counter}] Nama Produk:{item.product_name}; Nama Variasi:; Harga: Rp {price_formatted}; Jumlah: {item.quantity}; Nomor Referensi SKU: {item.sku}; SKU Induk: {item.sku};"
            
            orders_data.append({
                'order_id': order.id,
                'order_number': order.order_number,
                'customer_name': order.customer_name,
                'raw_product_info': raw_product_info,
                'product_name': item.product_name,
                'sku': item.sku,
                'price': item.price,
                'quantity': item.quantity
            })
            
            item_counter += 1
        
        return jsonify({
            'success': True,
            'orders_data': orders_data,
            'total_items': len(orders_data)
        })
        
    except Exception as e:
        logging.error(f"Error in get_all_orders_raw: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/scan/picking')
def scan_picking():
    """Picking mode scanning page"""
    return render_template('scan_picking.html')

@app.route('/scan/ready-pickup')
def scan_ready_pickup_page():
    """Ready pickup mode scanning page"""
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Items per page
    
    # Get scan history for ready pickup with pagination
    scan_history = ScanHistory.query.filter_by(scan_type='ready_pickup')\
        .order_by(ScanHistory.scanned_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('scan_ready_pickup.html', 
                         scan_history=scan_history)

@app.route('/scan/order', methods=['POST'])
def scan_order():
    """Scan order barcode to start picking"""
    barcode = request.form.get('barcode', '').strip()
    
    if not barcode:
        return jsonify({'error': 'Barcode is required'}), 400
    
    # Find order by order number or tracking number
    order = Order.query.filter(
        (Order.order_number == barcode) | (Order.tracking_number == barcode)
    ).first()
    
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    if order.status not in ['pending', 'picking']:
        return jsonify({'error': f'Order is already {order.status}'}), 400
    
    # Start picking session
    if order.status == 'pending':
        order.status = 'picking'
        order.picking_started_at = datetime.utcnow()
        
        # Create or get picking session
        session = PickingSession.query.filter_by(order_id=order.id).first()
        if not session:
            session = PickingSession(order_id=order.id, current_item_index=0)
            db.session.add(session)
        
        db.session.commit()
    
    return jsonify({
        'success': True,
        'order_id': order.id,
        'order_number': order.order_number,
        'customer_name': order.customer_name
    })

@app.route('/picking/<int:order_id>')
def picking_interface(order_id):
    """Picking interface for specific order - shows all items at once"""
    order = Order.query.get_or_404(order_id)
    
    # Get or create picking session
    session = PickingSession.query.filter_by(order_id=order_id).first()
    if not session:
        session = PickingSession(order_id=order_id)
        db.session.add(session)
        db.session.commit()
    
    # Get all items for this order
    items = OrderItem.query.filter_by(order_id=order_id).all()
    
    # Calculate progress
    total_items = len(items)
    picked_items = len([item for item in items if item.is_picked])
    
    return render_template('picking_interface.html', 
                         order=order, 
                         items=items,
                         picked_items=picked_items,
                         total_items=total_items,
                         session=session)

@app.route('/scan/product', methods=['POST'])
def scan_product():
    """Scan product barcode during picking - new approach for multiple items"""
    data = request.get_json()
    order_id = data.get('order_id')
    scanned_sku = data.get('barcode', '').strip()
    item_id = data.get('item_id')  # Specific item to pick
    picked_quantity = data.get('quantity', 0)
    
    if not all([order_id, scanned_sku, item_id]) or picked_quantity <= 0:
        return jsonify({'error': 'Missing required data or invalid quantity'}), 400
    
    order = Order.query.get(order_id)
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    # Get specific item
    item = OrderItem.query.get(item_id)
    if not item or item.order_id != order_id:
        return jsonify({'error': 'Item not found or does not belong to this order'}), 404
    
    # Smart SKU matching - check if scanned code contains numbers and is part of expected SKU
    def is_valid_product_code(scanned_code, expected_sku):
        # Check if scanned code contains numbers (valid product code indicator)
        has_numbers = any(char.isdigit() for char in scanned_code)
        if not has_numbers:
            return False
        
        # Check if scanned code is part of expected SKU
        scanned_upper = scanned_code.upper()
        expected_upper = expected_sku.upper()
        
        # Direct match
        if scanned_upper == expected_upper:
            return True
            
        # Check if scanned code is a part of the SKU (between | separators)
        if '|' in expected_upper:
            sku_parts = [part.strip() for part in expected_upper.split('|')]
            return scanned_upper in sku_parts
        
        # Check if scanned code is contained in expected SKU
        return scanned_upper in expected_upper
    
    # Enhanced SKU matching - first check if scanned code matches expected, then search inventory
    matched_sku = None
    
    # First, check direct match with expected SKU
    if is_valid_product_code(scanned_sku, item.sku):
        matched_sku = item.sku
    else:
        # Search for any product in inventory that contains this scanned code
        matching_products = Product.query.filter(
            Product.sku.ilike(f'%{scanned_sku}%')
        ).all()
        
        # Find the best match
        for product in matching_products:
            if is_valid_product_code(scanned_sku, product.sku):
                matched_sku = product.sku
                break
        
        if not matched_sku:
            return jsonify({
                'error': f'Produk tidak ditemukan di inventory! Kode scan: {scanned_sku}. Pastikan kode produk mengandung angka dan terdaftar di sistem.'
            }), 400
    
    # Update scanned_sku to the matched full SKU
    scanned_sku = matched_sku
    
    # Validate quantity - must match exactly
    if picked_quantity != item.quantity:
        return jsonify({
            'error': f'Jumlah tidak sesuai! Harus tepat {item.quantity} item, tapi Anda memasukkan {picked_quantity}.'
        }), 400
    
    # Mark item as picked
    item.is_picked = True
    item.picked_quantity = picked_quantity
    item.picked_at = datetime.utcnow()
    
    # Update product stock
    product = Product.query.filter_by(sku=scanned_sku).first()
    if product:
        product.quantity -= picked_quantity
        
        # Log stock movement
        movement = StockMovement(
            product_id=product.id,
            order_id=order_id,
            movement_type='out',
            quantity=picked_quantity,
            notes=f'Picked for order {order.order_number}'
        )
        db.session.add(movement)
    
    # Check if all items are picked
    all_items = OrderItem.query.filter_by(order_id=order_id).all()
    all_picked = all(item.is_picked for item in all_items)
    
    if all_picked:
        order.status = 'picked'
        order.picking_completed_at = datetime.utcnow()
        
        # Complete the session
        session = PickingSession.query.filter_by(order_id=order_id).first()
        if session:
            session.completed_at = datetime.utcnow()
    
    db.session.commit()
    
    # Calculate progress
    picked_count = len([item for item in all_items if item.is_picked])
    total_count = len(all_items)
    
    return jsonify({
        'success': True,
        'all_picked': all_picked,
        'message': 'Item picked successfully!' if not all_picked else 'All items picked! Order ready for packing.',
        'progress': {
            'picked': picked_count,
            'total': total_count
        }
    })

@app.route('/packing/<int:order_id>')
def packing_interface(order_id):
    """Packing interface"""
    order = Order.query.get_or_404(order_id)
    
    if order.status not in ['picked', 'packing']:
        flash('Order is not ready for packing', 'error')
        return redirect(url_for('fulfillment_dashboard'))
    
    if order.status == 'picked':
        order.status = 'packing'
        order.packing_started_at = datetime.utcnow()
        db.session.commit()
    
    items = OrderItem.query.filter_by(order_id=order_id).all()
    
    return render_template('packing_interface.html', order=order, items=items)

@app.route('/complete_packing/<int:order_id>', methods=['POST'])
def complete_packing(order_id):
    """Complete packing process"""
    order = Order.query.get_or_404(order_id)
    
    order.status = 'packed'
    order.packing_completed_at = datetime.utcnow()
    db.session.commit()
    
    if request.is_json:
        return jsonify({'success': True, 'message': 'Packing completed successfully!'})
    else:
        flash('Packing completed successfully!', 'success')
        return redirect(url_for('fulfillment_dashboard'))

@app.route('/packing_validation/<int:order_id>')
@login_required
def packing_validation_interface(order_id):
    """Interface untuk validasi packing dengan tampilan sesuai mockup"""
    order = Order.query.get_or_404(order_id)
    
    # Ensure order is ready for packing validation
    if order.status not in ['picked', 'picking_completed', 'packing']:
        flash(f'Order belum siap untuk validasi packing. Status: {order.status}', 'error')
        return redirect(url_for('scan_center'))
    
    # Get all order items that are picked with their product info
    picked_items = OrderItem.query.filter_by(order_id=order_id, is_picked=True).all()
    
    # Attach product info to each item
    for item in picked_items:
        item.product = Product.query.filter_by(sku=item.sku).first()
    
    # Check if all items are picked
    unpicked_items = OrderItem.query.filter_by(order_id=order_id, is_picked=False).all()
    if unpicked_items:
        flash(f'Masih ada {len(unpicked_items)} item yang belum dipick', 'error')
        return redirect(url_for('scan_center'))
    
    # Update packing started time if not set
    if not order.packing_started_at:
        order.packing_started_at = datetime.utcnow()
        order.status = 'packing'
        db.session.commit()
    
    return render_template('packing_validation_interface.html', order=order, picked_items=picked_items)




@app.route('/scan/packing_validation', methods=['POST'])
def scan_packing_validation():
    """Scan untuk validasi packing - redirect ke interface validasi"""
    try:
        # Handle both JSON and form data
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form
            
        order_identifier = data.get('barcode', '').strip()
        
        if not order_identifier:
            return jsonify({'error': 'Order number or tracking number is required'}), 400
        
        # Find order by order number or tracking number
        order = Order.query.filter(
            (Order.order_number == order_identifier) | 
            (Order.tracking_number == order_identifier)
        ).first()
        
        if not order:
            return jsonify({'error': f'Order {order_identifier} not found'}), 404
        
        # Check if order is ready for packing validation
        if order.status not in ['picked', 'picking_completed', 'packing']:
            return jsonify({'error': f'Order not ready for packing validation. Status: {order.status}'}), 400
        
        # Check if all items are picked
        unpicked_items = OrderItem.query.filter_by(order_id=order.id, is_picked=False).count()
        if unpicked_items > 0:
            return jsonify({'error': f'Order has {unpicked_items} unpicked items. Complete picking first.'}), 400
        
        # Return success with redirect URL
        return jsonify({
            'success': True,
            'message': f'Order {order.order_number} ready for packing validation',
            'redirect': url_for('packing_validation_interface', order_id=order.id)
        })
        
    except Exception as e:
        app.logger.error(f"Error in scan_packing_validation: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/scan/ready_pickup', methods=['POST'])
def scan_ready_pickup():
    """Scan tracking number to mark as ready for pickup"""
    barcode = request.form.get('barcode', '').strip()
    
    if not barcode:
        return jsonify({'error': 'Barcode is required'}), 400
    
    order = Order.query.filter(
        (Order.tracking_number == barcode) | (Order.order_number == barcode)
    ).first()
    
    if not order:
        # Save failed scan to history
        scan_history = ScanHistory(
            barcode=barcode,
            order_id=0,  # No order found
            scan_type='ready_pickup',
            success=False,
            message=f'Order not found for barcode: {barcode}',
            order_number='N/A',
            customer_name='N/A'
        )
        db.session.add(scan_history)
        db.session.commit()
        
        return jsonify({'error': 'Order not found'}), 404
    
    if order.status != 'packed':
        # Save failed scan to history
        scan_history = ScanHistory(
            barcode=barcode,
            order_id=order.id,
            scan_type='ready_pickup',
            success=False,
            message=f'Order must be packed first. Current status: {order.status}',
            order_number=order.order_number,
            customer_name=order.customer_name
        )
        db.session.add(scan_history)
        db.session.commit()
        
        return jsonify({'error': f'Order must be packed first. Current status: {order.status}'}), 400
    
    # Update order status
    order.status = 'ready_for_pickup'
    order.ready_for_pickup_at = datetime.utcnow()
    
    # Save successful scan to history
    scan_history = ScanHistory(
        barcode=barcode,
        order_id=order.id,
        scan_type='ready_pickup',
        success=True,
        message=f'Order {order.order_number} is ready for pickup!',
        order_number=order.order_number,
        customer_name=order.customer_name
    )
    db.session.add(scan_history)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'Order {order.order_number} is ready for pickup!',
        'order_number': order.order_number,
        'customer_name': order.customer_name
    })

# PWA Routes

@app.route('/manifest.json')
def manifest():
    """Serve PWA manifest"""
    from flask import send_from_directory
    return send_from_directory('static', 'manifest.json', mimetype='application/json')

@app.route('/sw.js')
def service_worker():
    """Serve service worker"""
    from flask import send_from_directory
    return send_from_directory('static', 'sw.js', mimetype='application/javascript')

@app.route('/logo-settings')
@login_required
def logo_settings():
    """Logo settings page"""
    return render_template('logo_settings.html')

@app.route('/update-logo', methods=['POST'])
@login_required
def update_logo():
    """Handle logo upload and update"""
    import os
    from werkzeug.utils import secure_filename
    
    if 'logo_file' not in request.files:
        flash('Tidak ada file yang dipilih', 'error')
        return redirect(url_for('logo_settings'))
    
    file = request.files['logo_file']
    if file.filename == '':
        flash('Tidak ada file yang dipilih', 'error')
        return redirect(url_for('logo_settings'))
    
    # Validate file type
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'svg'}
    file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    
    if file_extension not in allowed_extensions:
        flash('Format file tidak didukung. Gunakan PNG, JPG, JPEG, GIF, atau SVG', 'error')
        return redirect(url_for('logo_settings'))
    
    # Validate file size (5MB limit)
    file.seek(0, os.SEEK_END)
    file_size = file.tell()
    file.seek(0)
    
    if file_size > 5 * 1024 * 1024:  # 5MB
        flash('Ukuran file terlalu besar. Maksimal 5MB', 'error')
        return redirect(url_for('logo_settings'))
    
    try:
        # Create images directory if it doesn't exist
        images_dir = os.path.join(app.static_folder, 'images')
        if not os.path.exists(images_dir):
            os.makedirs(images_dir)
        
        # Backup current logo
        logo_path = os.path.join(images_dir, 'strong_logo.png')
        backup_path = os.path.join(images_dir, 'strong_logo_backup.png')
        
        if os.path.exists(logo_path):
            if os.path.exists(backup_path):
                os.remove(backup_path)
            os.rename(logo_path, backup_path)
        
        # Save new logo
        if file_extension == 'svg':
            # For SVG files, save as is but rename to .png for consistency
            new_logo_path = os.path.join(images_dir, 'strong_logo.svg')
            file.save(new_logo_path)
            # Also copy to .png name for template compatibility
            import shutil
            shutil.copy2(new_logo_path, logo_path)
        else:
            # For other formats, save directly
            file.save(logo_path)
        
        flash('Logo berhasil diperbarui!', 'success')
        
    except Exception as e:
        flash(f'Gagal mengupload logo: {str(e)}', 'error')
        logging.error(f"Logo upload error: {e}")
    
    return redirect(url_for('logo_settings'))

@app.route('/analytics')
@login_required
def analytics():
    """Analytics and reporting dashboard"""
    # Get date range from request
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    period = request.args.get('period', 'week')
    
    # Default to last 7 days if no dates provided
    if not date_from or not date_to:
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=7)
        date_from = start_date.strftime('%Y-%m-%d')
        date_to = end_date.strftime('%Y-%m-%d')
    
    # Convert to datetime objects
    start_datetime = datetime.strptime(date_from, '%Y-%m-%d')
    end_datetime = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
    
    # Calculate analytics data
    analytics_data = calculate_analytics(start_datetime, end_datetime)
    chart_data = generate_chart_data(start_datetime, end_datetime)
    
    return render_template('analytics.html', 
                         analytics=analytics_data,
                         chart_data=chart_data,
                         date_from=date_from,
                         date_to=date_to,
                         period=period)

@app.route('/monitoring')
@login_required
def monitoring():
    """Real-time order monitoring dashboard"""
    return render_template('monitoring.html')

@app.route('/api/monitoring/stats')
@login_required
def monitoring_stats():
    """API endpoint for real-time monitoring statistics"""
    try:
        # Get current order statistics
        total_orders = Order.query.count()
        imported_orders = Order.query.count()  # All orders are imported
        picking_orders = Order.query.filter_by(status='picking').count()
        packing_orders = Order.query.filter_by(status='packing').count()
        ready_pickup_orders = Order.query.filter_by(status='ready_for_pickup').count()
        completed_orders = Order.query.filter_by(status='completed').count()
        
        # Get pending orders (not yet processed)
        pending_orders = Order.query.filter_by(status='pending').count()
        
        # Calculate processing statistics
        processing_orders = picking_orders + packing_orders
        
        # Get recent activity (last 10 orders)
        recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
        recent_activity = []
        for order in recent_orders:
            recent_activity.append({
                'order_number': order.order_number,
                'customer_name': order.customer_name,
                'status': order.status,
                'created_at': order.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'total_amount': order.total_amount
            })
        
        # Get hourly statistics for today
        from datetime import datetime, timedelta
        today = datetime.now().date()
        hourly_stats = []
        for hour in range(24):
            hour_start = datetime.combine(today, datetime.min.time()) + timedelta(hours=hour)
            hour_end = hour_start + timedelta(hours=1)
            
            hour_orders = Order.query.filter(
                Order.created_at >= hour_start,
                Order.created_at < hour_end
            ).count()
            
            hourly_stats.append({
                'hour': f"{hour:02d}:00",
                'orders': hour_orders
            })
        
        return jsonify({
            'success': True,
            'stats': {
                'total_orders': total_orders,
                'imported_orders': imported_orders,
                'pending_orders': pending_orders,
                'picking_orders': picking_orders,
                'packing_orders': packing_orders,
                'ready_pickup_orders': ready_pickup_orders,
                'completed_orders': completed_orders,
                'processing_orders': processing_orders
            },
            'recent_activity': recent_activity,
            'hourly_stats': hourly_stats,
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
    except Exception as e:
        logging.error(f"Error getting monitoring stats: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/product_display/<int:order_id>')
@login_required
def product_display(order_id):
    """Display products in order with Shopee-like format"""
    order = Order.query.get_or_404(order_id)
    
    # Get all order items with their product info
    order_items = OrderItem.query.filter_by(order_id=order_id).all()
    
    # Attach product info to each item
    for item in order_items:
        item.product = Product.query.filter_by(sku=item.sku).first()
    
    return render_template('product_display.html', order=order, order_items=order_items)


@app.route('/analytics/export')
@login_required
def export_analytics():
    """Export analytics data to PDF or Excel"""
    format_type = request.args.get('format', 'excel')
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    if not date_from or not date_to:
        flash('Date range is required for export', 'error')
        return redirect(url_for('analytics'))
    
    start_datetime = datetime.strptime(date_from, '%Y-%m-%d')
    end_datetime = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
    
    analytics_data = calculate_analytics(start_datetime, end_datetime)
    
    if format_type == 'excel':
        return export_to_excel(analytics_data, date_from, date_to)
    elif format_type == 'pdf':
        return export_to_pdf(analytics_data, date_from, date_to)
    
    flash('Invalid export format', 'error')
    return redirect(url_for('analytics'))

def calculate_analytics(start_date, end_date):
    """Calculate analytics data for the given date range"""
    # Basic metrics
    total_orders = db.session.query(Order).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).count()
    
    total_revenue = db.session.query(func.sum(Order.total_amount)).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).scalar() or 0
    
    # Items sold
    total_items = db.session.query(func.sum(OrderItem.quantity)).select_from(OrderItem).join(Order, OrderItem.order_id == Order.id).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).scalar() or 0
    
    # Average fulfillment time (mock calculation)
    avg_fulfillment = 24  # hours - could be calculated from picking/packing timestamps
    
    # Top products
    top_products = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity).label('quantity_sold'),
        func.sum(OrderItem.quantity * OrderItem.price).label('revenue')
    ).select_from(Product).join(OrderItem, Product.sku == OrderItem.sku).join(Order, OrderItem.order_id == Order.id).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).group_by(Product.id, Product.name).order_by(func.sum(OrderItem.quantity).desc()).limit(5).all()
    
    # High value orders
    high_value_orders = db.session.query(Order).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date,
        Order.total_amount >= 200000  # Orders above 200k
    ).order_by(Order.total_amount.desc()).limit(5).all()
    
    # Calculate growth percentages (based on previous period comparison)
    prev_start = start_date - (end_date - start_date)
    prev_orders = db.session.query(Order).filter(
        Order.created_at >= prev_start,
        Order.created_at < start_date
    ).count()
    
    prev_revenue = db.session.query(func.sum(Order.total_amount)).filter(
        Order.created_at >= prev_start,
        Order.created_at < start_date
    ).scalar() or 0
    
    orders_growth = ((total_orders - prev_orders) / max(prev_orders, 1)) * 100
    revenue_growth = ((total_revenue - prev_revenue) / max(prev_revenue, 1)) * 100
    
    return {
        'total_orders': total_orders,
        'total_revenue': total_revenue,
        'avg_fulfillment_time': avg_fulfillment,
        'total_items_sold': total_items,
        'orders_growth': round(orders_growth, 1),
        'revenue_growth': round(revenue_growth, 1),
        'fulfillment_improvement': 12.5,
        'items_growth': 18.7,
        'top_products': [{'name': p.name, 'quantity_sold': p.quantity_sold, 'revenue': p.revenue} for p in top_products],
        'high_value_orders': high_value_orders
    }

def generate_chart_data(start_date, end_date):
    """Generate chart data for visualization"""
    # Daily sales trend
    days_diff = max((end_date - start_date).days, 1)
    sales_trend_labels = []
    sales_trend_revenue = []
    sales_trend_orders = []
    
    for i in range(days_diff):
        current_date = start_date + timedelta(days=i)
        next_date = current_date + timedelta(days=1)
        
        daily_revenue = db.session.query(func.sum(Order.total_amount)).filter(
            Order.created_at >= current_date,
            Order.created_at < next_date
        ).scalar() or 0
        
        daily_orders = db.session.query(Order).filter(
            Order.created_at >= current_date,
            Order.created_at < next_date
        ).count()
        
        sales_trend_labels.append(current_date.strftime('%m/%d'))
        sales_trend_revenue.append(float(daily_revenue))
        sales_trend_orders.append(daily_orders)
    
    # Order status distribution
    status_counts = db.session.query(
        Order.status,
        func.count(Order.id)
    ).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).group_by(Order.status).all()
    
    order_status_labels = [s[0].title() for s in status_counts]
    order_status_data = [s[1] for s in status_counts]
    
    # Top products for chart
    top_products_chart = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity)
    ).select_from(Product).join(OrderItem, Product.sku == OrderItem.sku).join(Order, OrderItem.order_id == Order.id).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).group_by(Product.id, Product.name).order_by(func.sum(OrderItem.quantity).desc()).limit(5).all()
    
    top_products_labels = [p[0][:15] + '...' if len(p[0]) > 15 else p[0] for p in top_products_chart]
    top_products_data = [int(p[1]) for p in top_products_chart]
    
    # Get total revenue for hourly distribution
    total_revenue = db.session.query(func.sum(Order.total_amount)).filter(
        Order.created_at >= start_date,
        Order.created_at < end_date
    ).scalar() or 0
    
    # Hourly revenue (realistic distribution based on business hours)
    hourly_labels = [f"{i:02d}:00" for i in range(24)]
    hourly_data = []
    
    for hour in range(24):
        # Simulate realistic business hour patterns
        if 9 <= hour <= 21:  # Business hours
            base_revenue = float(total_revenue) * 0.06  # 6% per business hour
            # Peak hours: 11-13, 19-21
            if hour in [11, 12, 19, 20]:
                hourly_revenue = base_revenue * 1.5
            else:
                hourly_revenue = base_revenue * 0.8
        else:
            hourly_revenue = float(total_revenue) * 0.005  # 0.5% for off hours
        
        hourly_data.append(hourly_revenue)
    
    return {
        'sales_trend': {
            'labels': sales_trend_labels,
            'revenue': sales_trend_revenue,
            'orders': sales_trend_orders
        },
        'order_status': {
            'labels': order_status_labels,
            'data': order_status_data
        },
        'top_products': {
            'labels': top_products_labels,
            'data': top_products_data
        },
        'hourly_revenue': {
            'labels': hourly_labels,
            'data': hourly_data
        }
    }

def export_to_excel(analytics_data, date_from, date_to):
    """Export analytics data to Excel format"""
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['Strong Order Management - Analytics Report'])
    writer.writerow([f'Period: {date_from} to {date_to}'])
    writer.writerow([])
    
    # KPI Summary
    writer.writerow(['KPI Summary'])
    writer.writerow(['Metric', 'Value'])
    writer.writerow(['Total Orders', analytics_data['total_orders']])
    writer.writerow(['Total Revenue', f"Rp {analytics_data['total_revenue']:,.0f}"])
    writer.writerow(['Average Fulfillment Time', f"{analytics_data['avg_fulfillment_time']} hours"])
    writer.writerow(['Total Items Sold', analytics_data['total_items_sold']])
    writer.writerow([])
    
    # Top Products
    writer.writerow(['Top Products'])
    writer.writerow(['Product Name', 'Quantity Sold', 'Revenue'])
    for product in analytics_data['top_products']:
        writer.writerow([product['name'], product['quantity_sold'], f"Rp {product['revenue']:,.0f}"])
    writer.writerow([])
    
    # High Value Orders
    writer.writerow(['High Value Orders'])
    writer.writerow(['Order Number', 'Customer', 'Amount'])
    for order in analytics_data['high_value_orders']:
        writer.writerow([order.order_number, order.customer_name, f"Rp {order.total_amount:,.0f}"])
    
    # Create response
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = f'attachment; filename=analytics_report_{date_from}_to_{date_to}.csv'
    
    return response

def export_to_pdf(analytics_data, date_from, date_to):
    """Export analytics data to PDF format (simplified as HTML for now)"""
    html_content = f"""
    <html>
    <head>
        <title>Analytics Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            .header {{ text-align: center; margin-bottom: 30px; }}
            .kpi {{ display: flex; justify-content: space-around; margin: 20px 0; }}
            .kpi-item {{ text-align: center; padding: 20px; border: 1px solid #ddd; }}
            table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #f4f4f4; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Strong Order Management</h1>
            <h2>Analytics Report</h2>
            <p>Period: {date_from} to {date_to}</p>
        </div>
        
        <div class="kpi">
            <div class="kpi-item">
                <h3>{analytics_data['total_orders']}</h3>
                <p>Total Orders</p>
            </div>
            <div class="kpi-item">
                <h3>Rp {analytics_data['total_revenue']:,.0f}</h3>
                <p>Total Revenue</p>
            </div>
            <div class="kpi-item">
                <h3>{analytics_data['avg_fulfillment_time']}h</h3>
                <p>Avg Fulfillment</p>
            </div>
            <div class="kpi-item">
                <h3>{analytics_data['total_items_sold']}</h3>
                <p>Items Sold</p>
            </div>
        </div>
        
        <h3>Top Products</h3>
        <table>
            <tr><th>Product</th><th>Quantity</th><th>Revenue</th></tr>
    """
    
    for product in analytics_data['top_products']:
        html_content += f"<tr><td>{product['name']}</td><td>{product['quantity_sold']}</td><td>Rp {product['revenue']:,.0f}</td></tr>"
    
    html_content += """
        </table>
        
        <h3>High Value Orders</h3>
        <table>
            <tr><th>Order</th><th>Customer</th><th>Amount</th></tr>
    """
    
    for order in analytics_data['high_value_orders']:
        html_content += f"<tr><td>{order.order_number}</td><td>{order.customer_name}</td><td>Rp {order.total_amount:,.0f}</td></tr>"
    
    html_content += """
        </table>
    </body>
    </html>
    """
    
    response = make_response(html_content)
    response.headers['Content-Type'] = 'text/html'
    response.headers['Content-Disposition'] = f'attachment; filename=analytics_report_{date_from}_to_{date_to}.html'
    
    return response

@app.errorhandler(404)
def not_found(error):
    return render_template('base.html', error_message="Page not found"), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('base.html', error_message="Internal server error"), 500
