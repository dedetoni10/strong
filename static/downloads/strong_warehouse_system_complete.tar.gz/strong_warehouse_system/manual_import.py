#!/usr/bin/env python3
"""
Manual import script for testing order parsing
"""
from app import app, db
from database_models import Order, OrderItem
import re
from datetime import datetime

def manual_import():
    with app.app_context():
        # Clear existing data
        OrderItem.query.delete()
        Order.query.delete()
        db.session.commit()
        print("Cleared existing data")
        
        # Create test order based on the actual resi you showed
        order = Order(
            order_number='250706DVXVV9VE',
            tracking_number='DPS-508',
            customer_name='Runda Azzura',
            total_amount=47000.0,  # Rp 35,000 + Rp 5,000 + Rp 7,000 = Rp 47,000
            status='pending'
        )
        db.session.add(order)
        db.session.flush()  # Get the ID
        
        # Add the three products from the actual resi
        # Product 1: GEARBOX MESIN CUCI SHARP TIPIS 2 TABUNG 6-7 KG
        item1 = OrderItem(
            order_id=order.id,
            sku='STJ040-REDUCER+PULY SHARP',
            product_name='GEARBOX MESIN CUCI SHARP TIPIS 2 TABUNG 6-7 KG',
            quantity=1,
            price=35000.0
        )
        db.session.add(item1)
        
        # Product 2: SEAL BELOW / KARET PEMBUANGAN SHARP ORIGINAL 2 TABUNG
        item2 = OrderItem(
            order_id=order.id,
            sku='ST1351-SPB NO 23 ORI',
            product_name='SEAL BELOW / KARET PEMBUANGAN SHARP ORIGINAL 2 TABUNG',
            quantity=1,
            price=5000.0
        )
        db.session.add(item2)
        
        # Product 3: SEAL / SIL PEMBUANGAN MESIN CUCI ORIGINAL MERAH UNIVERSAL
        item3 = OrderItem(
            order_id=order.id,
            sku='HME | SRE-162 | MCC | SEAL PEMBUANG MERAH QH022',
            product_name='SEAL / SIL PEMBUANGAN MESIN CUCI ORIGINAL MERAH UNIVERSAL',
            quantity=1,
            price=7000.0
        )
        db.session.add(item3)
        
        db.session.commit()
        print(f"Created order {order.order_number} with 3 products")
        
        # Verify data
        order_count = Order.query.count()
        item_count = OrderItem.query.count()
        print(f"Total orders: {order_count}, Total items: {item_count}")

if __name__ == '__main__':
    manual_import()