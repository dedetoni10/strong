#!/usr/bin/env python3

import os
import sys
import pandas as pd
from io import BytesIO
from werkzeug.datastructures import FileStorage

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import Flask app and dependencies
from app import app
from database_models import Order, OrderItem, Product, db
from routes import process_order_data

def test_excel_import():
    """Test Excel import functionality with real file"""
    
    # Use the Flask app context
    with app.app_context():
        
        # Clear existing orders for clean test
        try:
            db.session.query(OrderItem).delete()
            db.session.query(Order).delete()
            db.session.commit()
            print("✓ Cleared existing orders")
        except Exception as e:
            print(f"Warning: Could not clear orders: {e}")
        
        # Find an Excel file to test with
        excel_files = [
            'attached_assets/Daftar Pesanan.SPX Standard_51_1751951477534.xlsx',
            'attached_assets/Daftar Pesanan.SPX Standard_51_1751952277018.xlsx',
            'attached_assets/Daftar Pesanan.Hemat Kargo_42 (1)_1751900393119.xlsx'
        ]
        
        test_file = None
        for filename in excel_files:
            if os.path.exists(filename):
                test_file = filename
                break
        
        if not test_file:
            print("❌ No Excel file found for testing")
            return False
        
        print(f"📄 Testing with file: {test_file}")
        
        try:
            # Read Excel file using pandas
            df = pd.read_excel(test_file, engine='openpyxl')
            print(f"✓ Successfully read Excel file with {len(df)} rows")
            print(f"✓ Columns: {list(df.columns)}")
            
            # Show first few rows
            print("\n📊 First 3 rows of data:")
            for i, row in df.head(3).iterrows():
                print(f"Row {i}: {dict(row)}")
            
            # Convert to records for processing
            records = df.fillna('').to_dict('records')
            
            # Test the import process
            print(f"\n🔄 Processing {len(records)} records...")
            imported_count = process_order_data(records)
            
            print(f"✅ Successfully imported {imported_count} orders")
            
            # Verify import results
            orders_count = db.session.query(Order).count()
            items_count = db.session.query(OrderItem).count()
            
            print(f"📈 Database results:")
            print(f"   - Orders in database: {orders_count}")
            print(f"   - Order items in database: {items_count}")
            
            if orders_count > 0:
                # Show sample order
                sample_order = db.session.query(Order).first()
                print(f"   - Sample order: {sample_order.order_number} - {sample_order.customer_name}")
                
                # Show items for this order
                items = db.session.query(OrderItem).filter_by(order_id=sample_order.id).all()
                print(f"   - Items in sample order: {len(items)}")
                for item in items:
                    print(f"     * {item.product_name} x{item.quantity} - Rp {item.price}")
            
            return True
            
        except Exception as e:
            print(f"❌ Error during testing: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

if __name__ == "__main__":
    success = test_excel_import()
    if success:
        print("\n🎉 Test completed successfully!")
    else:
        print("\n💥 Test failed!")