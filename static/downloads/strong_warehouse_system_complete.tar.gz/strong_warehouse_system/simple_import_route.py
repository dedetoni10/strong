"""
Simple import route to replace the complex one
"""
from flask import request, jsonify, render_template
import logging
import tempfile
import os

def simple_import_orders():
    """Simple import with progress interface"""
    if request.method == 'POST':
        # Handle AJAX file upload
        uploaded_files = request.files.getlist('order_files')
        
        if not uploaded_files or all(f.filename == '' for f in uploaded_files):
            return jsonify({'success': False, 'message': 'Tidak ada file yang dipilih'})
        
        # Process single file
        file = uploaded_files[0]
        
        if file.filename == '':
            return jsonify({'success': False, 'message': 'File tidak valid'})
            
        # Check file extension
        if not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({'success': False, 'message': 'Format file tidak valid. Gunakan .xlsx atau .xls'})
        
        try:
            # Save file temporarily
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, file.filename)
            file.save(temp_file_path)
            
            # Import using bulk import function
            from bulk_import_final import bulk_import_single_file
            logging.info(f"Starting bulk import for file: {file.filename}")
            result = bulk_import_single_file(temp_file_path)
            logging.info(f"Bulk import result: {result}")
            
            # Clean up temp file
            os.remove(temp_file_path)
            
            if isinstance(result, dict) and result.get('success'):
                return jsonify({
                    'success': True,
                    'imported_count': result['imported_count'],
                    'skipped_count': result.get('skipped_count', 0),
                    'message': f'Berhasil import {result["imported_count"]} pesanan dari {file.filename}'
                })
            else:
                error_msg = result.get('message', 'unknown error') if isinstance(result, dict) else str(result)
                return jsonify({
                    'success': False,
                    'imported_count': 0,
                    'message': f'Error: {error_msg}'
                })
                
        except Exception as e:
            logging.error(f"Error processing file {file.filename}: {str(e)}")
            import traceback
            error_details = traceback.format_exc()
            logging.error(f"Full traceback: {error_details}")
            return jsonify({
                'success': False,
                'imported_count': 0,
                'message': f'Error processing file: {str(e)}',
                'error_details': error_details
            })
    
    return render_template('import_orders_progress.html')