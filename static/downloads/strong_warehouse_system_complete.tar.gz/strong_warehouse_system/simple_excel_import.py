#!/usr/bin/env python3
"""
Simple Excel Import - Clean and Direct Approach
"""

import pandas as pd
import logging
from app import app
from database_models import Order, OrderItem, db
import re

def clean_text(text):
    """Clean and validate text fields"""
    if pd.isna(text) or text is None:
        return ""
    return str(text).strip()

def simple_import_excel(file_path):
    """Simple Excel import with direct processing"""
    try:
        # Read Excel file
        df = pd.read_excel(file_path)
        logging.info(f"Reading Excel file: {file_path}")
        logging.info(f"Columns found: {list(df.columns)}")
        
        # Clean data
        df = df.fillna("")
        
        imported_count = 0
        errors = []
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Get order number
                order_number = clean_text(row.get('order_sn', ''))
                if not order_number:
                    continue
                
                # Check if order already exists
                try:
                    # Safe query with proper encoding handling
                    existing_order = db.session.query(Order).filter(Order.order_number == order_number).first()
                    if existing_order:
                        logging.info(f"Order {order_number} already exists, skipping")
                        continue
                except Exception as query_error:
                    logging.error(f"Database query error for order {order_number}: {query_error}")
                    continue
                
                # Get customer info
                customer_name = clean_text(row.get('order_receiver_name', '')) or clean_text(row.get('buyer_user_name', '')) or 'Unknown'
                tracking_number = clean_text(row.get('tracking_number', ''))
                
                # Handle duplicate tracking numbers
                if tracking_number:
                    try:
                        # Safe query with proper encoding handling
                        existing_tracking = db.session.query(Order).filter(Order.tracking_number == tracking_number).first()
                        if existing_tracking:
                            tracking_number = f"{tracking_number}_{order_number}"
                    except Exception as tracking_error:
                        logging.error(f"Error checking tracking number {tracking_number}: {tracking_error}")
                        tracking_number = f"{tracking_number}_{order_number}"
                
                # Calculate total from product info
                product_info = clean_text(row.get('product_info', ''))
                total_amount = 0.0
                
                if product_info:
                    try:
                        # Extract prices and quantities
                        price_matches = re.findall(r'Harga:\s*Rp\s*([\d,\.]+)', product_info)
                        qty_matches = re.findall(r'Jumlah:\s*(\d+)', product_info)
                        
                        for i, price_str in enumerate(price_matches):
                            price = float(price_str.replace(',', '').replace('.', ''))
                            qty = int(qty_matches[i]) if i < len(qty_matches) else 1
                            total_amount += price * qty
                    except:
                        total_amount = 0.0
                
                # Create order
                try:
                    new_order = Order(
                        order_number=order_number,
                        tracking_number=tracking_number if tracking_number else None,
                        customer_name=customer_name,
                        total_amount=total_amount,
                        status='pending'
                    )
                    
                    db.session.add(new_order)
                    db.session.flush()
                    
                    # Create order items from product info
                    if product_info:
                        items_created = 0
                        lines = product_info.split('\n')
                        
                        for line in lines:
                            if '[' in line and 'Nama Produk:' in line:
                                try:
                                    # Extract product name
                                    name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                                    if name_match:
                                        product_name = name_match.group(1).strip()
                                        product_name = re.sub(r'^\[BAYAR DI TEMPAT\]\s*', '', product_name)
                                        
                                        # Extract price
                                        price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                                        price = 0.0
                                        if price_match:
                                            price = float(price_match.group(1).replace(',', '').replace('.', ''))
                                        
                                        # Extract quantity
                                        qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                                        quantity = 1
                                        if qty_match:
                                            quantity = int(qty_match.group(1))
                                        
                                        # Create item
                                        order_item = OrderItem(
                                            order_id=new_order.id,
                                            sku=f'SKU-{order_number}-{items_created + 1}',
                                            product_name=product_name,
                                            quantity=quantity,
                                            price=price
                                        )
                                        
                                        db.session.add(order_item)
                                        items_created += 1
                                except Exception as item_error:
                                    logging.error(f"Error creating item for order {order_number}: {item_error}")
                                    continue
                    
                    # Commit individual order
                    db.session.commit()
                    imported_count += 1
                    
                    if imported_count % 10 == 0:
                        logging.info(f"Imported {imported_count} orders...")
                        
                except Exception as order_error:
                    db.session.rollback()
                    logging.error(f"Error creating order {order_number}: {order_error}")
                    errors.append(f"Order {order_number}: {str(order_error)}")
                    continue
                    
            except Exception as row_error:
                db.session.rollback()
                error_msg = f"Error processing row {index}: {str(row_error)}"
                logging.error(error_msg)
                errors.append(error_msg)
                continue
        
        return {
            'success': True,
            'imported': imported_count,
            'errors': errors,
            'total_rows': len(df)
        }
        
    except Exception as e:
        logging.error(f"Excel import error: {str(e)}")
        return {
            'success': False,
            'error': str(e),
            'imported': 0
        }

if __name__ == "__main__":
    with app.app_context():
        # Test with available file
        result = simple_import_excel('attached_assets/Daftar Pesanan.Hemat Kargo_200.xlsx')
        print(f"Import result: {result}")