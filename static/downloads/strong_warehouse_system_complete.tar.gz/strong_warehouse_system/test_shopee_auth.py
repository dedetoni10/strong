#!/usr/bin/env python3
"""
Test Shopee authorization flow untuk debugging
"""
import logging
import time
import hmac
import hashlib
import requests
from shopee_api import ShopeeAPI

logging.basicConfig(level=logging.DEBUG)

def test_authorization_flow():
    """Test full authorization flow"""
    print("=== Testing Shopee Authorization Flow ===")
    
    # Test 1: Generate auth URL
    shopee_api = ShopeeAPI()
    auth_url = shopee_api.get_auth_url()
    print(f"1. Auth URL: {auth_url}")
    
    # Test 2: Test auth URL manually
    try:
        response = requests.get(auth_url, timeout=10, allow_redirects=False)
        print(f"2. Auth URL Status: {response.status_code}")
        if response.status_code == 302:
            print(f"   Redirect to: {response.headers.get('Location')}")
        else:
            print(f"   Response: {response.text[:200]}...")
    except Exception as e:
        print(f"2. Auth URL Error: {e}")
    
    # Test 3: Simulate callback
    print("\n3. Testing callback simulation...")
    
    # This is what Shopee sends back
    test_code = "test_code_123"
    test_shop_id = "1420428877"
    
    # Test callback function
    result = shopee_api.get_access_token_from_code(test_code, test_shop_id)
    print(f"   Callback result: {result}")
    
    print("\n=== Summary ===")
    print("- Authorization URL is generated correctly")
    print("- Callback handler is configured")
    print("- Need to test with real authorization code from Shopee")

if __name__ == "__main__":
    test_authorization_flow()