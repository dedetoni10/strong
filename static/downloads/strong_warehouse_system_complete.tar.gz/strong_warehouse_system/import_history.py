#!/usr/bin/env python3
"""
Import History and Testing Tool
"""
from app import app, db
from database_models import Order, OrderItem
from datetime import datetime
import json

def show_import_history():
    """Show all imported orders with details"""
    with app.app_context():
        orders = Order.query.all()
        
        print("=" * 80)
        print("HISTORY IMPORT ORDER")
        print("=" * 80)
        
        if not orders:
            print("Tidak ada order yang diimpor")
            return
            
        for order in orders:
            print(f"\nOrder: {order.order_number}")
            print(f"Customer: {order.customer_name}")
            print(f"Total: Rp {order.total_amount:,.0f}")
            print(f"Status: {order.status}")
            print(f"Created: {order.created_at}")
            
            items = OrderItem.query.filter_by(order_id=order.id).all()
            print(f"Items ({len(items)}):")
            for i, item in enumerate(items, 1):
                print(f"  {i}. {item.product_name}")
                print(f"     SKU: {item.sku}")
                print(f"     Qty: {item.quantity} | Price: Rp {item.price:,.0f}")
                if item.is_picked:
                    print(f"     ✓ Picked: {item.picked_quantity} at {item.picked_at}")
                else:
                    print(f"     ○ Not picked yet")
            print("-" * 60)

def clear_all_data():
    """Clear all order data for fresh import"""
    with app.app_context():
        # Clear in correct order due to foreign key constraints
        OrderItem.query.delete()
        Order.query.delete()
        
        # Also clear picking sessions
        from database_models import PickingSession
        PickingSession.query.delete()
        
        db.session.commit()
        print("✓ All data cleared successfully")

def prepare_for_fresh_import():
    """Prepare system for fresh Excel import"""
    with app.app_context():
        clear_all_data()
        print("\n" + "=" * 50)
        print("SISTEM SIAP UNTUK IMPORT ULANG")
        print("=" * 50)
        print("1. Semua data order dan item sudah dihapus")
        print("2. Database sudah bersih")
        print("3. Siap untuk upload file Excel baru")
        print("\nSilakan upload file Excel melalui:")
        print("→ Halaman Orders > Upload Excel")
        print("→ Atau gunakan tombol 'Import Orders' di dashboard")

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'clear':
        prepare_for_fresh_import()
    else:
        show_import_history()