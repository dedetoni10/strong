#!/usr/bin/env python3
"""
Bulk import remaining orders quickly
"""

import pandas as pd
import psycopg2
import os
import re
import time
from psycopg2.extras import execute_batch

def get_db_connection():
    """Get direct database connection"""
    database_url = os.environ.get('DATABASE_URL')
    return psycopg2.connect(database_url)

def safe_str(value):
    """Convert to safe string"""
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()

def clean_text(text):
    """Clean text to prevent encoding issues"""
    if not text:
        return ""
    
    # Remove problematic characters
    text = str(text).strip()
    text = re.sub(r'[^\x00-\x7F]+', '', text)  # Remove non-ASCII
    text = re.sub(r'\s+', ' ', text)  # Normalize whitespace
    
    return text[:500]  # Limit length

def bulk_import_single_file(file_path):
    """Bulk import from single file"""
    
    # Use the provided file path
    
    try:
        # Read Excel
        df = pd.read_excel(file_path)
        print(f"Total rows in file: {len(df)}")
        
        # Fill NaN
        df = df.fillna("")
        
        # Get database connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get existing order numbers
        cursor.execute("SELECT order_number FROM orders")
        existing_orders = set(row[0] for row in cursor.fetchall())
        print(f"Orders already in database: {len(existing_orders)}")
        
        # Prepare bulk data
        orders_to_insert = []
        items_to_insert = []
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Get order number
                order_number = safe_str(row.get('order_sn', ''))
                if not order_number or order_number in existing_orders:
                    continue
                
                # Get basic info
                customer_name = clean_text(safe_str(row.get('order_receiver_name', '')) or safe_str(row.get('buyer_user_name', '')) or 'Unknown')
                tracking_number = safe_str(row.get('tracking_number', ''))
                if not tracking_number:
                    tracking_number = None
                
                # Process products for this order
                product_info = safe_str(row.get('product_info', ''))
                total_amount = 0.0
                temp_items = []
                
                if product_info:
                    temp_items = prepare_order_data(order_number, product_info)
                    for item in temp_items:
                        _, _, _, quantity, price = item
                        total_amount += quantity * price
                    items_to_insert.extend(temp_items)
                
                # Add to orders list
                orders_to_insert.append((order_number, tracking_number, customer_name, total_amount))
                
                # Commit in batches of 50
                if len(orders_to_insert) >= 50:
                    commit_batch(cursor, conn, orders_to_insert, items_to_insert)
                    orders_to_insert = []
                    items_to_insert = []
                
            except Exception as e:
                print(f"Error processing order {order_number}: {str(e)}")
                continue
        
        # Commit remaining orders
        if orders_to_insert:
            commit_batch(cursor, conn, orders_to_insert, items_to_insert)
        
        # Final count
        cursor.execute("SELECT COUNT(*) FROM orders")
        final_count = cursor.fetchone()[0]
        
        new_orders_count = final_count - len(existing_orders)
        duplicates_skipped = len([order for order in orders_to_insert if order[0] in existing_orders])
        
        cursor.close()
        conn.close()
        
        print(f"\n=== BULK IMPORT COMPLETE ===")
        print(f"Total orders in database: {final_count}")
        print(f"New orders imported: {new_orders_count}")
        print(f"Duplicates skipped: {duplicates_skipped}")
        
        return {
            'success': True, 
            'imported_count': new_orders_count, 
            'skipped_count': duplicates_skipped,
            'message': f'Successfully imported {new_orders_count} new orders, skipped {duplicates_skipped} duplicates'
        }
        
    except Exception as e:
        print(f"Bulk import failed: {str(e)}")
        return {'success': False, 'imported_count': 0, 'message': f'Import failed: {str(e)}'}

def commit_batch(cursor, conn, orders, items):
    """Commit a batch of orders and items"""
    try:
        if not orders:
            return
            
        # Insert orders
        execute_batch(cursor, """
            INSERT INTO orders (order_number, tracking_number, customer_name, total_amount, status, created_at, updated_at)
            VALUES (%s, %s, %s, %s, 'pending', NOW(), NOW())
        """, orders)
        
        # Get order IDs for items
        if items:
            order_numbers = [order[0] for order in orders]
            cursor.execute("""
                SELECT id, order_number FROM orders 
                WHERE order_number = ANY(%s)
            """, (order_numbers,))
            
            order_id_map = {row[1]: row[0] for row in cursor.fetchall()}
            
            # Update items with order IDs
            items_with_ids = []
            for item in items:
                order_number, sku, product_name, quantity, price = item
                if order_number in order_id_map:
                    items_with_ids.append((order_id_map[order_number], sku, product_name, quantity, price))
            
            if items_with_ids:
                execute_batch(cursor, """
                    INSERT INTO order_items (order_id, sku, product_name, quantity, price, picked_quantity, is_picked, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, 0, false, NOW(), NOW())
                """, items_with_ids)
        
        conn.commit()
        print(f"Committed batch of {len(orders)} orders with {len(items)} items")
        
    except Exception as e:
        conn.rollback()
        print(f"Error in batch commit: {str(e)}")

def prepare_order_data(order_number, product_info):
    """Prepare order data for bulk insert"""
    
    items = []
    lines = product_info.split('\n')
    item_num = 0
    
    for line in lines:
        if 'Nama Produk:' in line:
            item_num += 1
            
            # Extract product name
            name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
            product_name = name_match.group(1).strip() if name_match else f'Product {item_num}'
            
            # Clean product name
            product_name = clean_text(product_name)
            product_name = re.sub(r'^\[BAYAR DI TEMPAT\]\s*', '', product_name)
            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
            
            # Extract quantity
            qty_match = re.search(r'Jumlah:\s*(\d+)', line)
            quantity = int(qty_match.group(1)) if qty_match else 1
            
            # Extract price
            price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
            price = 0.0
            if price_match:
                try:
                    price = float(price_match.group(1).replace(',', '').replace('.', ''))
                except:
                    price = 0.0
            
            # Extract SKU from Nomor Referensi SKU
            sku_match = re.search(r'Nomor Referensi SKU:\s*([^;]+)', line)
            if sku_match:
                sku = sku_match.group(1).strip()
                # Clean SKU
                sku = clean_text(sku)
            else:
                # Fallback to auto-generated SKU
                sku = f'SKU-{order_number}-{item_num}'
            
            # Add to items list
            items.append((order_number, sku, product_name, quantity, price))
    
    return items

def bulk_import_remaining():
    """Bulk import remaining orders from default file"""
    
    file_path = "attached_assets/Daftar Pesanan.Hemat Kargo_200_1752036301406.xlsx"
    return bulk_import_single_file(file_path)

if __name__ == "__main__":
    result = bulk_import_remaining()
    print(f"Final result: {result}")