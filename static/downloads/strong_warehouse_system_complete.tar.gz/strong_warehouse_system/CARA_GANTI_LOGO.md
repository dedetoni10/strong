# Cara Mengganti Logo

## Cara Mudah (Lewat Web Interface)

1. **Akses Halaman Pengaturan**
   - Buka website aplikasi
   - Klik menu "Pengaturan" di navbar
   - Pilih "Ganti Logo"

2. **Upload Logo Baru**
   - Klik "Choose File" dan pilih file logo
   - Format yang didukung: SVG, PNG, JPG, GIF
   - Ukuran maksimal: 2MB
   - Atur tinggi logo (20-60 pixel)
   - Klik "Ganti Logo"

## Cara Manual (Upload File)

1. **Siapkan File Logo**
   - Format: SVG (paling baik), PNG, JPG, atau GIF
   - Ukuran: sebaiknya persegi atau landscape
   - Resolusi: minimal 40x40 pixel

2. **Upload ke Folder yang Tepat**
   - Buka folder `static/img/`
   - Upload file logo dengan nama:
     - `logo.svg` (untuk SVG)
     - `logo.png` (untuk PNG)
     - `logo.jpg` (untuk JPG)

3. **Update Template (Jika Perlu)**
   - File yang perlu diubah: `templates/base.html`
   - Cari baris: `<img src="{{ url_for('static', filename='img/logo.svg') }}"`
   - Ganti `logo.svg` dengan nama file Anda

## Tips Logo yang Baik

- **Ukuran**: 40x40 pixel atau 200x50 pixel
- **Format**: SVG lebih baik karena scalable
- **Warna**: Pastikan kontras baik dengan background dark
- **Kesederhanaan**: Logo sederhana lebih baik untuk ukuran kecil

## Troubleshooting

**Logo tidak muncul?**
- Pastikan file ada di folder `static/img/`
- Cek nama file sudah benar
- Refresh browser (Ctrl+F5)

**Logo terlalu besar/kecil?**
- Ubah nilai `height` di CSS
- Atau gunakan fitur resize di halaman pengaturan

**Logo tidak jelas?**
- Gunakan format SVG
- Atau PNG dengan resolusi tinggi