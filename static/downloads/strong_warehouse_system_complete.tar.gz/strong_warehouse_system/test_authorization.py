#!/usr/bin/env python3
"""
Test authorization dengan berbagai kredensial dari screenshot
"""

import os
import sys
import requests
import time
import hmac
import hashlib

def test_authorization_with_credentials():
    """Test authorization dengan kredensial yang berbeda"""
    
    # Dari screenshot - ada 2 set kredensial
    credentials = [
        {
            "name": "Live Credentials",
            "partner_id": "201911",
            "api_key": "shpk634a47494b726d1537068786c456c6c76637673416e68725179597050050",
            "shop_id": "1420428877"
        },
        {
            "name": "Test Credentials", 
            "partner_id": "1280843",
            "api_key": "557259736965575042424d78636e6574748545056569674a5a41f52697a61746647",
            "shop_id": "1420428877"
        }
    ]
    
    base_url = "https://partner.shopeemobile.com"
    redirect_url = "https://strongofficial.site/shopee-callback"
    
    for cred in credentials:
        print(f"\n=== Testing {cred['name']} ===")
        print(f"Partner ID: {cred['partner_id']}")
        print(f"API Key: {cred['api_key'][:20]}...")
        
        # Generate authorization URL
        timestamp = int(time.time())
        path = "/api/v2/shop/auth_partner"
        
        # Create signature
        base_string = f"{cred['partner_id']}{path}{timestamp}"
        signature = hmac.new(
            cred['api_key'].encode('utf-8'),
            base_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        auth_url = f"{base_url}{path}?partner_id={cred['partner_id']}&timestamp={timestamp}&sign={signature}&redirect={redirect_url}"
        
        print(f"Auth URL: {auth_url}")
        
        # Test if URL is accessible (just check response code)
        try:
            response = requests.get(auth_url, timeout=10, allow_redirects=False)
            print(f"Response Status: {response.status_code}")
            if response.status_code == 200:
                print("✅ Authorization URL is accessible!")
            elif response.status_code == 302:
                print("✅ Redirect response - likely good!")
                print(f"Location: {response.headers.get('Location', 'No location header')}")
            else:
                print(f"❌ Unexpected status: {response.status_code}")
                print(f"Response: {response.text[:200]}...")
        except Exception as e:
            print(f"❌ Error testing URL: {str(e)}")
            
        print("-" * 50)

if __name__ == "__main__":
    test_authorization_with_credentials()