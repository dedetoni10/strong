#!/usr/bin/env python3
"""
Fix redirect URL untuk Shopee authorization
"""
import time
import hmac
import hashlib
import urllib.parse
import requests

def test_redirect_urls():
    """Test berbagai redirect URL untuk menemukan yang valid"""
    
    partner_id = 2011911
    api_key = 'shpk634a47494b726d41537068786c456c6c76637673416e6872517959705050'
    timestamp = int(time.time())
    path = '/api/v2/shop/auth_partner'
    
    # Berdasarkan error message, kita perlu menggunakan domain yang terdaftar
    redirect_urls = [
        'https://strongofficial.site/shopee-callback',
        'https://strongdksai.site/shopee-callback', 
        'https://localhost/shopee-callback',
        'http://localhost/shopee-callback',
        'https://strongofficial.site/callback',
        'https://strongofficial.site/auth/shopee',
        'https://strongofficial.site/api/shopee/callback'
    ]
    
    print("=== Testing Redirect URLs ===")
    
    for redirect_url in redirect_urls:
        print(f"\n🔍 Testing: {redirect_url}")
        
        # Generate signature
        base_string = f'{partner_id}{path}{timestamp}'
        signature = hmac.new(api_key.encode('utf-8'), base_string.encode('utf-8'), hashlib.sha256).hexdigest()
        
        # Create URL
        encoded_redirect = urllib.parse.quote(redirect_url)
        test_url = f'https://partner.shopeemobile.com{path}?partner_id={partner_id}&timestamp={timestamp}&sign={signature}&redirect={encoded_redirect}'
        
        # Test URL
        try:
            response = requests.get(test_url, timeout=10, allow_redirects=False)
            
            if response.status_code == 302:
                location = response.headers.get('Location', '')
                if 'oauth2/login' in location:
                    print(f"✅ SUCCESS: Redirect URL valid")
                    print(f"   Authorization page: {location}")
                else:
                    print(f"❌ FAIL: Unexpected redirect to {location}")
            else:
                print(f"❌ FAIL: Status {response.status_code}")
                print(f"   Response: {response.text[:100]}...")
                
        except Exception as e:
            print(f"❌ ERROR: {e}")
    
    # Suggest solution
    print("\n💡 SOLUSI:")
    print("1. Periksa Shopee Developer Console untuk melihat Redirect URL yang terdaftar")
    print("2. Pastikan domain yang digunakan sudah diverifikasi")
    print("3. Gunakan URL yang tepat sesuai dengan yang terdaftar di console")

if __name__ == "__main__":
    test_redirect_urls()