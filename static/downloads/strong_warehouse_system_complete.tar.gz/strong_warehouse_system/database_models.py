from app import db
from datetime import datetime
from sqlalchemy import String, Integer, Float, DateTime, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional

class Order(db.Model):
    __tablename__ = 'orders'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_number: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    tracking_number: Mapped[Optional[str]] = mapped_column(String(100), unique=True)
    customer_name: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_phone: Mapped[Optional[str]] = mapped_column(String(50))
    customer_address: Mapped[Optional[str]] = mapped_column(Text)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    order_date: Mapped[Optional[datetime]] = mapped_column(DateTime)
    
    # Status workflow: pending -> picking -> picked -> packing -> packed -> ready_for_pickup
    status: Mapped[str] = mapped_column(String(50), default='pending')
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Workflow timestamps
    picking_started_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    picking_completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    packing_started_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    packing_completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    ready_for_pickup_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(Integer, db.ForeignKey('orders.id'), nullable=False)
    sku: Mapped[str] = mapped_column(String(100), nullable=False)
    product_name: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    price: Mapped[float] = mapped_column(Float, default=0.0)
    
    # Picking status for each item
    picked_quantity: Mapped[int] = mapped_column(Integer, default=0)
    is_picked: Mapped[bool] = mapped_column(Boolean, default=False)
    picked_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Product(db.Model):
    __tablename__ = 'products'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sku: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(500), nullable=False)
    barcode: Mapped[Optional[str]] = mapped_column(String(100))
    quantity: Mapped[int] = mapped_column(Integer, default=0)
    price: Mapped[float] = mapped_column(Float, default=0.0)
    minimum_stock: Mapped[int] = mapped_column(Integer, default=10)
    location: Mapped[Optional[str]] = mapped_column(String(100))  # Warehouse location
    image_url: Mapped[Optional[str]] = mapped_column(Text)  # Product image URL or data URL
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PickingSession(db.Model):
    __tablename__ = 'picking_sessions'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(Integer, db.ForeignKey('orders.id'), nullable=False)
    current_item_index: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    
class StockMovement(db.Model):
    __tablename__ = 'stock_movements'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int] = mapped_column(Integer, db.ForeignKey('products.id'), nullable=False)
    order_id: Mapped[Optional[int]] = mapped_column(Integer, db.ForeignKey('orders.id'))
    movement_type: Mapped[str] = mapped_column(String(50), nullable=False)  # 'in', 'out', 'adjustment'
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ScanHistory(db.Model):
    __tablename__ = 'scan_history'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    barcode: Mapped[str] = mapped_column(String(100), nullable=False)
    order_id: Mapped[int] = mapped_column(Integer, db.ForeignKey('orders.id'), nullable=False)
    scan_type: Mapped[str] = mapped_column(String(50), nullable=False)  # 'picking', 'packing', 'ready_pickup'
    success: Mapped[bool] = mapped_column(Boolean, default=True)
    message: Mapped[str] = mapped_column(String(500), nullable=False)
    order_number: Mapped[str] = mapped_column(String(100), nullable=False)
    customer_name: Mapped[str] = mapped_column(String(200), nullable=False)
    scanned_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)