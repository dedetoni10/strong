#!/usr/bin/env python3
"""
Mock Shopee API for development and testing
Provides realistic sample data while waiting for real API credentials
"""

import time
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional

class MockShopeeAPI:
    def __init__(self):
        self.partner_id = f"MOCK_{int(time.time())}"
        self.shop_id = "1420428877"  # User's real shop ID
        self.api_key = "MOCK_API_KEY_FOR_DEVELOPMENT"
        self.access_token = "MOCK_ACCESS_TOKEN"
        self.base_url = "https://mock-shopee-api.local"
        
        # Sample data for development
        self.sample_orders = self._generate_sample_orders()
        
    def _generate_sample_orders(self) -> List[Dict]:
        """Generate realistic sample orders for development"""
        orders = []
        base_time = int(time.time()) - (7 * 24 * 3600)  # 7 days ago
        
        for i in range(5):
            order_time = base_time + (i * 24 * 3600)  # One order per day
            order = {
                "order_sn": f"STRONG{220101000 + i:03d}",
                "region": "ID",
                "order_status": ["READY_TO_SHIP", "PROCESSED", "SHIPPED", "COMPLETED"][i % 4],
                "shipping_carrier": "J&T Express",
                "payment_method": "COD" if i % 2 == 0 else "ShopeePay",
                "estimated_shipping_fee": 15000 + (i * 2000),
                "message_to_seller": "Mohon packing dengan rapi" if i == 2 else "",
                "create_time": order_time,
                "update_time": order_time + 3600,
                "days_to_ship": 2,
                "ship_by_date": order_time + (2 * 24 * 3600),
                "buyer_user_id": 12345678 + i,
                "buyer_username": f"buyer_{i+1}",
                "recipient_address": {
                    "name": [
                        "Budi Santoso",
                        "Siti Aminah", 
                        "Joko Widodo",
                        "Rina Susanti",
                        "Ahmad Fauzi"
                    ][i],
                    "phone": f"08{12345678 + i}",
                    "full_address": [
                        "Jl. Sudirman No. 123, RT.01/RW.02",
                        "Jl. Gatot Subroto No. 456, RT.03/RW.04", 
                        "Jl. Thamrin No. 789, RT.05/RW.06",
                        "Jl. Kuningan No. 101, RT.07/RW.08",
                        "Jl. Senayan No. 202, RT.09/RW.10"
                    ][i],
                    "city": "Jakarta Selatan",
                    "state": "DKI Jakarta",
                    "country": "Indonesia",
                    "zipcode": f"1{2100 + i:04d}"
                },
                "item_list": [
                    {
                        "item_id": 100000 + (i * 10) + j,
                        "item_name": [
                            "Kaos Strong Premium Quality",
                            "Hoodie Strong Limited Edition",
                            "Topi Strong Baseball Cap", 
                            "Jaket Strong Waterproof",
                            "Celana Strong Cargo Pants"
                        ][(i + j) % 5],
                        "item_sku": f"STR-{(i+j):03d}-{chr(65+j)}",
                        "model_id": 200000 + (i * 10) + j,
                        "model_name": f"Size {['S', 'M', 'L', 'XL'][j % 4]}",
                        "model_sku": f"STR-{(i+j):03d}-{chr(65+j)}-{['S', 'M', 'L', 'XL'][j % 4]}",
                        "model_quantity_purchased": (j % 3) + 1,
                        "model_original_price": 75000 + (j * 25000),
                        "model_discounted_price": 65000 + (j * 20000),
                        "wholesale": False,
                        "weight": 0.3 + (j * 0.1),
                        "add_on_deal": False,
                        "main_item": j == 0,
                        "add_on_deal_id": None,
                        "promotion_type": "shop_discount" if i % 2 == 0 else None,
                        "promotion_id": 300000 + i if i % 2 == 0 else None,
                        "order_item_id": 400000 + (i * 10) + j,
                        "promotion_group_id": None,
                        "image_info": {
                            "image_url": f"https://cf.shopee.co.id/file/strong_product_{i}_{j}.jpg"
                        }
                    }
                    for j in range((i % 3) + 1)  # 1-3 items per order
                ],
                "pay_time": order_time + 1800,  # Paid 30 mins after creation
                "dropshipping": False,
                "credit_card_number": "",
                "dropshipping_name": "",
                "buyer_cancel_reason": "",
                "cancel_by": "",
                "cancel_reason": "",
                "actual_shipping_fee": 15000 + (i * 2000),
                "goods_to_declare": False,
                "note": f"Mock order #{i+1} for Strong Order Management testing",
                "note_update_time": order_time + 7200
            }
            orders.append(order)
            
        return orders
    
    def test_connection(self) -> Dict:
        """Mock API connection test"""
        return {
            'success': True,
            'message': '✅ Mock API - Koneksi berhasil (Development Mode)',
            'shop_info': {
                'shop_name': 'Strong Store',
                'shop_id': self.shop_id,
                'status': 'NORMAL',
                'region': 'ID',
                'item_limit': 100000,
                'request_id': f'mock_{int(time.time())}',
                'note': 'Ini adalah Mock API untuk development. Untuk produksi, gunakan kredensial Shopee yang valid.'
            },
            'auth_url': None
        }
    
    def get_orders(self, time_range_field: str = "create_time", 
                   time_from: int = None, time_to: int = None) -> List[Dict]:
        """Mock get orders from Shopee API"""
        logging.info(f"Mock API: Getting orders with time_range_field={time_range_field}")
        
        # Filter orders by time if specified
        filtered_orders = self.sample_orders
        if time_from:
            filtered_orders = [o for o in filtered_orders if o.get('create_time', 0) >= time_from]
        if time_to:
            filtered_orders = [o for o in filtered_orders if o.get('create_time', 0) <= time_to]
            
        return filtered_orders
    
    def get_order_details(self, order_sn_list: List[str]) -> List[Dict]:
        """Mock get detailed order information"""
        details = []
        for order_sn in order_sn_list:
            # Find order in sample data
            order = next((o for o in self.sample_orders if o['order_sn'] == order_sn), None)
            if order:
                details.append(order)
        return details
    
    def sync_orders_to_local(self) -> int:
        """Mock sync orders to PostgreSQL database"""
        from database_models import Order, OrderItem
        from app import db
        
        synced_count = 0
        
        for order in self.sample_orders:
            try:
                order_sn = order.get("order_sn", "")
                
                # Check if already exists in database
                existing_order = Order.query.filter_by(order_number=order_sn).first()
                if existing_order:
                    continue
                
                # Extract order information
                recipient = order.get("recipient_address", {})
                customer_name = recipient.get("name", "")
                customer_phone = recipient.get("phone", "")
                customer_address = f"{recipient.get('full_address', '')}, {recipient.get('city', '')}, {recipient.get('state', '')}"
                
                # Calculate total amount
                total_amount = sum(item['model_discounted_price'] * item['model_quantity_purchased'] 
                                 for item in order.get("item_list", []))
                
                # Create order in database
                from datetime import datetime
                new_order = Order(
                    order_number=order_sn,
                    customer_name=customer_name,
                    customer_phone=customer_phone,
                    customer_address=customer_address,
                    total_amount=total_amount,
                    status='pending',
                    order_date=datetime.fromtimestamp(order.get('create_time', time.time()))
                )
                
                db.session.add(new_order)
                db.session.flush()  # Get the order ID
                
                # Create order items
                for item in order.get("item_list", []):
                    order_item = OrderItem(
                        order_id=new_order.id,
                        product_name=item.get('item_name', ''),
                        sku=item.get('item_sku', ''),
                        quantity=item.get('model_quantity_purchased', 1),
                        price=item.get('model_discounted_price', 0)
                    )
                    db.session.add(order_item)
                
                db.session.commit()
                logging.info(f"Mock API: Synced order {order_sn} to database")
                synced_count += 1
                
            except Exception as e:
                logging.error(f"Mock API: Failed to sync order {order_sn}: {str(e)}")
                db.session.rollback()
                continue
        
        return synced_count
    
    def get_auth_url(self, redirect_url: str = "https://strongdksai.site/shopee-callback") -> str:
        """Mock authorization URL"""
        return f"https://mock-shopee.local/auth?redirect={redirect_url}&note=mock_api_for_development"

# Create global instance for easy import
mock_shopee_api = MockShopeeAPI()