"""
Helper untuk menangani authorization Shopee API
"""
import os
import logging
from flask import flash, request, session

def simulate_authorization_process():
    """
    Simulasi proses authorization untuk development
    Mengembalikan access token yang valid untuk testing
    """
    # Dalam real environment, ini akan didapat dari callback Shopee
    # Untuk development, kita simulasikan proses yang berhasil
    simulated_access_token = "simulated_access_token_for_development_12345"
    
    # Set environment variables untuk session ini
    os.environ['SHOPEE_ACCESS_TOKEN'] = simulated_access_token
    
    return {
        'success': True,
        'access_token': simulated_access_token,
        'message': 'Authorization simulasi berhasil untuk development'
    }

def attempt_real_authorization(shop_id, partner_id, api_key):
    """
    Mencoba real authorization dengan kredensial yang diberikan
    """
    try:
        from shopee_api import ShopeeAPI
        
        # Temporary set credentials
        original_shop_id = os.environ.get('SHOPEE_SHOP_ID', '')
        original_partner_id = os.environ.get('SHOPEE_PARTNER_ID', '')
        original_api_key = os.environ.get('SHOPEE_API_KEY', '')
        
        # Set new credentials
        os.environ['SHOPEE_SHOP_ID'] = str(shop_id)
        os.environ['SHOPEE_PARTNER_ID'] = str(partner_id)
        os.environ['SHOPEE_API_KEY'] = api_key
        
        # Test connection
        shopee_api = ShopeeAPI()
        test_result = shopee_api.test_connection()
        
        if test_result.get('success'):
            return {
                'success': True,
                'message': 'Real API connection successful',
                'api_mode': 'real'
            }
        else:
            # If real API fails, restore original and use mock
            os.environ['SHOPEE_SHOP_ID'] = original_shop_id
            os.environ['SHOPEE_PARTNER_ID'] = original_partner_id
            os.environ['SHOPEE_API_KEY'] = original_api_key
            
            return {
                'success': False,
                'message': f'Real API failed: {test_result.get("message", "Unknown error")}',
                'api_mode': 'mock'
            }
            
    except Exception as e:
        logging.error(f"Error in real authorization: {str(e)}")
        return {
            'success': False,
            'message': f'Authorization error: {str(e)}',
            'api_mode': 'mock'
        }

def get_authorization_status():
    """
    Mendapatkan status authorization saat ini
    """
    access_token = os.environ.get('SHOPEE_ACCESS_TOKEN', '')
    shop_id = os.environ.get('SHOPEE_SHOP_ID', '')
    partner_id = os.environ.get('SHOPEE_PARTNER_ID', '')
    
    if access_token and shop_id and partner_id:
        return {
            'authorized': True,
            'shop_id': shop_id,
            'partner_id': partner_id,
            'has_access_token': True
        }
    else:
        return {
            'authorized': False,
            'shop_id': shop_id,
            'partner_id': partner_id,
            'has_access_token': bool(access_token)
        }

def clear_authorization():
    """
    Menghapus semua data authorization
    """
    env_vars = ['SHOPEE_ACCESS_TOKEN', 'SHOPEE_REFRESH_TOKEN']
    for var in env_vars:
        if var in os.environ:
            del os.environ[var]
    
    return {'success': True, 'message': 'Authorization cleared'}