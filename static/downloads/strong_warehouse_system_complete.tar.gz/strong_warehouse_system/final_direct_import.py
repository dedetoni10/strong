"""
Final Direct Import - Langsung import tanpa kompleksitas
"""

import pandas as pd
import logging
import re
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def safe_str(value):
    """Convert any value to safe string"""
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()

def direct_import_all(db_session):
    """Direct import from Excel file - all orders"""
    
    # Read the Excel file directly
    file_path = "attached_assets/Daftar Pesanan.Hemat Kargo_200_1752036301406.xlsx"
    
    try:
        # Read Excel
        df = pd.read_excel(file_path)
        logging.info(f"Loaded {len(df)} rows from Excel file")
        
        # Fill NaN values
        df = df.fillna("")
        
        imported_count = 0
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Get order number
                order_number = safe_str(row.get('order_sn', ''))
                if not order_number:
                    continue
                
                # Skip if already exists
                from sqlalchemy import text
                existing = db_session.execute(
                    text("SELECT COUNT(*) FROM orders WHERE order_number = :order_num"),
                    {'order_num': order_number}
                ).scalar()
                
                if existing > 0:
                    logging.info(f"Order {order_number} already exists, skipping")
                    continue
                
                # Get basic info
                customer_name = safe_str(row.get('order_receiver_name', '')) or safe_str(row.get('buyer_user_name', '')) or 'Unknown'
                tracking_number = safe_str(row.get('tracking_number', ''))
                
                # Insert order directly
                db_session.execute(
                    text("""
                        INSERT INTO orders (order_number, tracking_number, customer_name, total_amount, status, created_at, updated_at)
                        VALUES (:order_number, :tracking_number, :customer_name, 0.0, 'pending', NOW(), NOW())
                    """),
                    {
                        'order_number': order_number,
                        'tracking_number': tracking_number if tracking_number else None,
                        'customer_name': customer_name
                    }
                )
                
                # Get order ID
                order_id = db_session.execute(
                    text("SELECT id FROM orders WHERE order_number = :order_num"),
                    {'order_num': order_number}
                ).scalar()
                
                # Process products
                product_info = safe_str(row.get('product_info', ''))
                if product_info and order_id:
                    lines = product_info.split('\n')
                    item_num = 0
                    
                    for line in lines:
                        if 'Nama Produk:' in line:
                            item_num += 1
                            
                            # Extract product name
                            name_match = re.search(r'Nama Produk:(.+?)(?:;|$)', line)
                            product_name = name_match.group(1).strip() if name_match else f'Product {item_num}'
                            
                            # Clean product name
                            product_name = re.sub(r'^\[BAYAR DI TEMPAT\]\s*', '', product_name)
                            product_name = re.sub(r'^\[BAYAR DITEMPAT\]\s*', '', product_name)
                            
                            # Extract quantity
                            qty_match = re.search(r'Jumlah:\s*(\d+)', line)
                            quantity = int(qty_match.group(1)) if qty_match else 1
                            
                            # Extract price
                            price_match = re.search(r'Harga:\s*Rp\s*([\d,\.]+)', line)
                            price = 0.0
                            if price_match:
                                try:
                                    price = float(price_match.group(1).replace(',', '').replace('.', ''))
                                except:
                                    price = 0.0
                            
                            # Insert order item
                            db_session.execute(
                                text("""
                                    INSERT INTO order_items (order_id, sku, product_name, quantity, price, picked_quantity, is_picked, created_at, updated_at)
                                    VALUES (:order_id, :sku, :product_name, :quantity, :price, 0, false, NOW(), NOW())
                                """),
                                {
                                    'order_id': order_id,
                                    'sku': f'SKU-{order_number}-{item_num}',
                                    'product_name': product_name,
                                    'quantity': quantity,
                                    'price': price
                                }
                            )
                
                # Commit each order
                db_session.commit()
                imported_count += 1
                
                # Log progress
                if imported_count % 10 == 0:
                    logging.info(f"Imported {imported_count} orders...")
                
            except Exception as e:
                db_session.rollback()
                logging.error(f"Error importing order {order_number}: {str(e)}")
                continue
        
        logging.info(f"Successfully imported {imported_count} orders")
        return {'success': True, 'imported': imported_count, 'message': f'Successfully imported {imported_count} orders'}
        
    except Exception as e:
        logging.error(f"Import failed: {str(e)}")
        return {'success': False, 'imported': 0, 'message': f'Import failed: {str(e)}'}

if __name__ == "__main__":
    # Run import directly
    from app import app, db
    
    with app.app_context():
        result = direct_import_all(db.session)
        print(f"Import result: {result}")